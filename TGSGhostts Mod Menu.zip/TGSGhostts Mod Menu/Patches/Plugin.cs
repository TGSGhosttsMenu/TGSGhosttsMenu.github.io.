﻿using BepInEx;
using System.ComponentModel;

namespace TGSGhostt.Patches
{
    [Description(MenuPluginInfo.MenuInfo.Description)]
    [BepInPlugin(MenuPluginInfo.MenuInfo.GUID, MenuPluginInfo.MenuInfo.Name, MenuPluginInfo.MenuInfo.Version)]
    public class HarmonyPatches : BaseUnityPlugin
    {
        private void OnEnable()
        {
            Menu.ApplyHarmonyPatches();
        }

        private void OnDisable()
        {
            Menu.RemoveHarmonyPatches();
        }
    }
}
