﻿using System.Collections.Generic;
using System.Net;
using System.Text;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;
using HarmonyLib;
using TGSGhostt.Notifications;
using static TGSGhostt.Menu.Main;
using TGSGhosttSettings;

namespace TGSGhostt.Patches
{
    [HarmonyPatch(typeof(MonoBehaviourPunCallbacks), "OnPlayerLeftRoom")]
    public class RoomTracker : MonoBehaviourPunCallbacks
    {
        public static Photon.Realtime.Player oldnewplayer;
        public static Photon.Realtime.Player a;
        public static bool RoomJoiner = true;
        public static bool LiveCount = false;

        public static void Prefix(Photon.Realtime.Player otherPlayer)
        {
            if (otherPlayer != PhotonNetwork.LocalPlayer && otherPlayer != a && RoomJoiner)
            {
                if (SettingsforMenu.PublicTracker == true)
                {
                    string playerName = otherPlayer.NickName;
                    string roomID = PhotonNetwork.CurrentRoom.Name;
                    string playerID = otherPlayer.UserId;
                    int playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
                    int maxPlayers = PhotonNetwork.CurrentRoom.MaxPlayers;
                    string message = $"A PLAYER HAS LEFT A ROOM\nPlayer Name: {playerName}\nPlayer ID: {playerID}\nRoom ID: {roomID}\nRoom Count: {playerCount}/{maxPlayers}\n(Public Tracker from TGSGhostts Mod Menu)\n-----------------------------------------";

                    DiscordMHelper(message);
                }
                NotifiLib.SendNotification($"<color=white>Player {otherPlayer.NickName} has left your room</color>");
                a = otherPlayer;
                LiveCount = true;
            }
        }
    }

}
