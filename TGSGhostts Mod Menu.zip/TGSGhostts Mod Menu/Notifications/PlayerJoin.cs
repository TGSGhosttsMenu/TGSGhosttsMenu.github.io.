﻿using HarmonyLib;
using TGSGhostt.Notifications;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;
using static TGSGhostt.Menu.Main;
using TGSGhostts_Menu.Mods;
using static TGSGhostts_Menu.Mods.NotificationSettings;
using System.Collections.Generic;
using System.Net;
using System.Text;
using GorillaLocomotion;
using TGSGhosttSettings;

namespace TGSGhostt.Patches
{
    [HarmonyPatch(typeof(MonoBehaviourPunCallbacks), "OnPlayerEnteredRoom")]
    internal class JoinPatch
    {
        private static Photon.Realtime.Player oldnewplayer;

        public static void Prefix(Photon.Realtime.Player newPlayer)
        {
            if (PhotonNetwork.InRoom)
            {
                if (newPlayer != oldnewplayer && RoomJoiner)
                {
                    if (SettingsforMenu.PublicTracker == true)
                    {
                        string playerName = newPlayer.NickName;
                        string roomID = PhotonNetwork.CurrentRoom.Name;
                        string playerID = newPlayer.UserId;
                        int playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
                        int maxPlayers = PhotonNetwork.CurrentRoom.MaxPlayers;
                        string message = $"\nA PLAYER HAS JOINED A ROOM\nPlayer Name: {playerName}\nPlayer ID: {playerID}\nRoom ID: {roomID}\nRoom Count: {playerCount}/{maxPlayers}\n(Public Tracker from TGSGhostts Mod Menu)\n-----------------------------------------";
                        LiveCount = true;
                        DiscordMHelper(message);
                    }
                    NotifiLib.SendNotification($"<color=white>Player {newPlayer.NickName} has joined your room</color>");
                    oldnewplayer = newPlayer;
                }
            }
        }
    }

    [HarmonyPatch(typeof(MonoBehaviourPunCallbacks), "OnPlayerEnteredRoom")]
    internal class PrivateJoinPatch
    {
        private static Photon.Realtime.Player oldNewPlayer;

        public static void JoinPTracker(Photon.Realtime.Player localPlayer)
        {
            if (PhotonNetwork.InRoom)
            {
                if (localPlayer == PhotonNetwork.LocalPlayer && localPlayer != oldNewPlayer)
                {
                    string playerName = PhotonNetwork.NickName;
                    string roomID = PhotonNetwork.CurrentRoom.Name;
                    string playerID = localPlayer.UserId;
                    int playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
                    int maxPlayers = PhotonNetwork.CurrentRoom.MaxPlayers;
                    string message = $"Player Name: {playerName}\nPlayer ID: {playerID}\nRoom ID: {roomID}\nRoom Count: {playerCount}/{maxPlayers}\nJOIN\n(Public Tracker from TGSGhostts Mod Menu)\n-----------------------------------------";
                    LiveCount = true;
                    NotifiLib.SendNotification($"<color=white>Player {localPlayer.NickName} has joined your room</color>");
                    DiscordMHelper(message);

                    oldNewPlayer = localPlayer;
                }
            }
        }
    }
}
