﻿using TGSGhostt.Classes;
using static TGSGhosttSettings.SettingsforMenu;
using static TGSGhostt.Mods.SettingsMods;
using UnityEngine.XR;
using UnityEngine;
using GorillaLocomotion;
using static TGSGhostt.Mods.SafetySettings;
using TGSGhostt.Mods;
using static TGSGhostts_Menu.Mods.VisualMods;
using static TGSGhostts_Menu.Mods.Holdables;
using static TGSGhostts_Menu.Mods.NameChangers;
using static TGSGhostt.Mods.Configuration;
using static TGSGhostt.Mods.SettingsMods.Hide;
using static TGSGhostts_Menu.Mods.CheatMods;
using static TGSGhostts_Menu.Mods.SpamMods;
using TGSGhostts_Menu.Mods;
using static TGSGhostts_Menu.Mods.YoutubeChannels;
using static TGSGhostts_Menu.Mods.RoomMods;
using static TGSGhostt.Mods.RigMods;
using TGSGhostt.Notifications;
using static TGSGhostt.Notifications.NotifiLib;
using static TGSGhostt.Patches.RoomTracker;

namespace TGSGhostt.Menu
{
    internal class Buttons
    {
        public static ButtonInfo[][] buttons = new ButtonInfo[][]
        {
            new ButtonInfo[] // Main 0
            {
                new ButtonInfo { buttonText = "settings", method =() => Settings(), isTogglable = false},
                new ButtonInfo { buttonText = "fun mods", method =() => FunMods(), isTogglable = false},
                new ButtonInfo { buttonText = "rig mods", method =() => RigMods(), isTogglable = false},
                new ButtonInfo { buttonText = "visual mods", method =() => VisualMods(), isTogglable = false},
                new ButtonInfo { buttonText = "holdable mods", method =() => HoldableMods(), isTogglable = false},
                new ButtonInfo { buttonText = "name mods", method =() => NameMods(), isTogglable = false},
                new ButtonInfo { buttonText = "cheat mods", method =() => CheatMods(), isTogglable = false},
                new ButtonInfo { buttonText = "spam mods [nw]", method =() => SpamMods(), isTogglable = false},
                new ButtonInfo { buttonText = "room mods", method =() => RoomMods(), isTogglable = false},
                new ButtonInfo { buttonText = "join discord", method =() => JoinDiscord(), isTogglable = false},
                new ButtonInfo { buttonText = "clear notifications", method =() => ClearAllNotifications(), isTogglable = false},
                new ButtonInfo { buttonText = "hide self", method =() => HideSelf(), isTogglable = false},
            },

            new ButtonInfo[] // Settings 1
            {
                new ButtonInfo { buttonText = "exit settings", method =() => Home(), isTogglable = false},
                new ButtonInfo { buttonText = "menu settings", method =() => MenuSettings(), isTogglable = false},
                new ButtonInfo { buttonText = "safety settings", method =() => SafetySettings(), isTogglable = false},
                new ButtonInfo { buttonText = "configuration settings", method =() => ConfigurationSettings(), isTogglable = false},
                new ButtonInfo { buttonText = "notification settings", method =() => NotificationSettingsTab(), isTogglable = false},
            },

            new ButtonInfo[] // Menu Settings 2
            {
                new ButtonInfo { buttonText = "exit menu settings", method =() => Settings(), isTogglable = false},
                new ButtonInfo { buttonText = "save mods", enableMethod =() => SavePreferences(),},
                new ButtonInfo { buttonText = "load mods", enableMethod =() => LoadPreferences(),},
                new ButtonInfo { buttonText = "restart game", enableMethod =() => RestartGame(),},
                new ButtonInfo { buttonText = "right hand", enableMethod =() => RightHand(), disableMethod =() => LeftHand(),},
                new ButtonInfo { buttonText = "menu ui", enableMethod =() => OnUI(), disableMethod =() => OffUI(), enabled = ShowUIOn},
                new ButtonInfo { buttonText = "fps counter", enableMethod =() => EnableFPSCounter(), disableMethod =() => DisableFPSCounter(), enabled = fpsCounter},
                new ButtonInfo { buttonText = "disconnect button", enableMethod =() => EnableDisconnectButton(), disableMethod =() => DisableDisconnectButton(), enabled = disconnectButton},
                new ButtonInfo { buttonText = "custom boards", enableMethod =() => TGSGhosttsBoards(),}, // fully fixed
                new ButtonInfo { buttonText = "no afk kick", enableMethod =() => NoAfkKick()},
                new ButtonInfo { buttonText = "disable quitbox", enableMethod =() => NoAfkKick()},
                new ButtonInfo { buttonText = "low fps", enableMethod =() => FPSLow(), disableMethod =() => FPSNormal()},
                new ButtonInfo { buttonText = "public tracker", enableMethod =() => RoomTrackerOn(), disableMethod =() => RoomTrackerOff()},
                new ButtonInfo { buttonText = "page buttons top", enableMethod =() => PageButtonTop(), disableMethod =() => PageButtonTopDisable()},
            },

            new ButtonInfo[] // Safety Settings 3
            {
                new ButtonInfo { buttonText = "exit safety settings", method =() => Settings(), isTogglable = false},
                new ButtonInfo { buttonText = "antireport", method =() => AntiReport()},
                new ButtonInfo { buttonText = "antireport reconnect", method =() => AntiReportReconnect()},
                new ButtonInfo { buttonText = "flush rpcs", method =() => FlushRPCs(),},
                new ButtonInfo { buttonText = "anti moderator", method =() => AntiModerator()},
                new ButtonInfo { buttonText = "anti mod checker", method =() => AntiModChecker()},
            },
            
            new ButtonInfo[] // Configuration Settings 4
            {
                new ButtonInfo { buttonText = "exit configuration settings", method =() => Settings(), isTogglable = false},
                new ButtonInfo { buttonText = "change menu theme", method =() => ChangeMenuTheme(), isTogglable = false},
                new ButtonInfo { buttonText = "change menu color", method =() => ChangeMenuColor(), isTogglable = false}, 
                new ButtonInfo { buttonText = "change border color", method =() => ChangeBorderColor(), isTogglable = false},
                new ButtonInfo { buttonText = "change off button color", method =() => ChangeOffButtonColor(), isTogglable = false}, 
                new ButtonInfo { buttonText = "change on button color", method =() => ChangeOnButtonColor(), isTogglable = false},
                new ButtonInfo { buttonText = "change off text color", method =() => ChangeOffTextColor(), isTogglable = false}, 
                new ButtonInfo { buttonText = "change on text color", method =() => ChangeOnTextColor(), isTogglable = false},  
                new ButtonInfo { buttonText = "change headspin speed", method =() => ChangeHeadSpinSpeed(), isTogglable = false}, 
                new ButtonInfo { buttonText = "change tag distance", method =() => ChangeTagAuraDistance(), isTogglable = false},
                new ButtonInfo { buttonText = "change fly speed", method =() => ChangeFlySpeed(), isTogglable = false},
                new ButtonInfo { buttonText = "change longarm size", method =() => ChangeArmSize(), isTogglable = false},
                new ButtonInfo { buttonText = "change wall walk", method =() => ChangeWallWalk(), isTogglable = false},
                new ButtonInfo { buttonText = "change handtaps", method =() => ChangeHandTap(), isTogglable = false},
                new ButtonInfo { buttonText = "change disconnect pos", method =() => ChangeDisconnectPosition(), isTogglable = false},
                new ButtonInfo { buttonText = "change tracer pos", method =() => ChangeTrcaerPos(), isTogglable = false},
            },

            new ButtonInfo[] // Fun Mods 5
            {
                new ButtonInfo { buttonText = "exit fun mods", method =() => Home(), isTogglable = false},
                new ButtonInfo { buttonText = "platforms [g]", method =() => FunMods.Platforms()},
                new ButtonInfo { buttonText = "disable network triggers", method =() => FunMods.DisableNetworkTriggers(), isTogglable = false},
                new ButtonInfo { buttonText = "enable network triggers", method =() => FunMods.EnabledNetworkTriggers(), isTogglable = false},
                new ButtonInfo { buttonText = "splash right [rt]", method =() => FunMods.SplashR()},
                new ButtonInfo { buttonText = "splash left [lt]", method =() => FunMods.SplashL()},
                new ButtonInfo { buttonText = "splash self [rt]", method =() => FunMods.WaterSelf()},
                new ButtonInfo { buttonText = "splash aura [rt]", method =() => FunMods.SplashAura()},
                new ButtonInfo { buttonText = "mat spam gun [M]", method =() => FunMods.MatSpamGun(),},
                new ButtonInfo { buttonText = "grab id gun", method =() => FunMods.GetIDGun()},
                new ButtonInfo { buttonText = "tag gun [rg]", method =() => FunMods.TagGun()},
                new ButtonInfo { buttonText = "tag aura", method =() => FunMods.TagAura()},
                new ButtonInfo { buttonText = "tag self", method =() => FunMods.TagSelf()},
                new ButtonInfo { buttonText = "grab own id", method =() => FunMods.GetOwnId(), isTogglable = false},
                new ButtonInfo { buttonText = "tp stump [A]", method =() => FunMods.TpToStump()},
                new ButtonInfo { buttonText = "tp gun [rg]", method =() => FunMods.TPGun()},
                new ButtonInfo { buttonText = "punch mod", method =() => FunMods.PunchMod()},
                new ButtonInfo { buttonText = "zero gravity", method =() => FunMods.ZeroGravity()},
                new ButtonInfo { buttonText = "car monke [rt] [rg]", method =() => FunMods.CarMonke()},
                new ButtonInfo { buttonText = "remove trees [rg]", method =() => FunMods.RemoveAllTrees(),},
                new ButtonInfo { buttonText = "region: eu", method =() => FunMods.ConnectToRegion("eu"), isTogglable = false},
                new ButtonInfo { buttonText = "region: us", method =() => FunMods.ConnectToRegion("us"), isTogglable = false},
                new ButtonInfo { buttonText = "region usw", method =() => FunMods.ConnectToRegion("usw"), isTogglable = false},
                new ButtonInfo { buttonText = "unlock comp", method =() => FunMods.UnlockComp(), isTogglable = false},
                new ButtonInfo { buttonText = "hard water", method =() => FunMods.SolidWater(), disableMethod =() => FunMods.UnSolidWater()}, // new
                new ButtonInfo { buttonText = "fast water swim", method =() => FunMods.SolidWater(), disableMethod =() => FunMods.UnSolidWater()}, // new 
            },

            new ButtonInfo[] // Rig Mods 6
            {
                new ButtonInfo { buttonText = "exit rig mods", method =() => Home(), isTogglable = false},
                new ButtonInfo { buttonText = "spin head", method =() => Mods.RigMods.SpinHead(), disableMethod =() => Mods.RigMods.FixHead()},
                new ButtonInfo { buttonText = "fly [A]", method =() => Mods.RigMods.Fly()},
                new ButtonInfo { buttonText = "noclip [rt]", method =() => Mods.RigMods.Noclip()},
                new ButtonInfo { buttonText = "ghostmonke [A]", method =() => Mods.RigMods.GhostMonke()},
                new ButtonInfo { buttonText = "invismonke [rt]", method =() => Mods.RigMods.InvisMonke()},
                new ButtonInfo { buttonText = "rig gun [rg]", method =() => Mods.RigMods.RigGun()},
                new ButtonInfo { buttonText = "iron monke [g]", method =() => Mods.RigMods.IronMonke()},
                new ButtonInfo { buttonText = "short arms", method =() => Mods.RigMods.LongArmsSub(0.5f, 0.5f, 0.5f), disableMethod =() => Mods.RigMods.LongArmsSub(1f, 1f, 1f)},
                new ButtonInfo { buttonText = "long arms", method =() => Mods.RigMods.LongArmsSub(1.2f, 1.2f, 1.2f), disableMethod =() => Mods.RigMods.LongArmsSub(1f, 1f, 1f)},
                new ButtonInfo { buttonText = "extreme long arms", method =() => Mods.RigMods.LongArmsSub(2f, 2f, 2f), disableMethod =() => Mods.RigMods.LongArmsSub(1f, 1f, 1f)},
                new ButtonInfo { buttonText = "normal boost", method =() => Mods.RigMods.NormalSpeed()},
                new ButtonInfo { buttonText = "fast boost", method =() => Mods.RigMods.FastSpeed()},
                new ButtonInfo { buttonText = "faster boost", method =() => Mods.RigMods.FasterSpeed()},
                new ButtonInfo { buttonText = "insane boost", method =() => Mods.RigMods.InsaneSpeed()},
                new ButtonInfo { buttonText = "no tag freeze", method =() => Mods.RigMods.NoTagFreeze()},
                new ButtonInfo { buttonText = "checkpoint [rg] [rt]", method =() => Mods.RigMods.Checkpoint()},
                new ButtonInfo { buttonText = "wall walk [rg]", method =() => Mods.RigMods.WallWalk()},
                new ButtonInfo { buttonText = "hand taps", method =() => Mods.RigMods.HandTaps()},
                new ButtonInfo { buttonText = "wasd movement", method =() => Mods.RigMods.WASDMovementButton()},
            },

            new ButtonInfo[] // Visual Mods 7
            {
                new ButtonInfo { buttonText = "exit visual mods", method =() => Home(), isTogglable = false},
                new ButtonInfo { buttonText = "esp", method =() => ESP(), disableMethod =() => UndoESP()},
                new ButtonInfo { buttonText = "bone esp", method =() => BoneESP(), disableMethod =() => EndSkeleEsp()},
                new ButtonInfo { buttonText = "box esp", method =() => BoxESP()}, 
                new ButtonInfo { buttonText = "beacons", method =() => Beacons()},
                new ButtonInfo { buttonText = "tracers", method =() => Tracers()},
                new ButtonInfo { buttonText = "day time", method =() => DayTime()},
                new ButtonInfo { buttonText = "night time", method =() => NightTime()},
                new ButtonInfo { buttonText = "rain", method =() => Rain(), disableMethod =() => NoRain()}, 
            },

            new ButtonInfo[] // Holdable Mods 8
            {
                new ButtonInfo { buttonText = "exit holdable mods", method =() => Home(), isTogglable = false},
                new ButtonInfo { buttonText = "grab bug [rg]", method =() => GrabBug()},
                new ButtonInfo { buttonText = "grab bat [rg]", method =() => GrabBat()},
                new ButtonInfo { buttonText = "grab ball [rg]", method =() => GrabBeachBall()},
                new ButtonInfo { buttonText = "grab monsters [rg]", method =() => GrabMonsters()},
                new ButtonInfo { buttonText = "bug gun [rg]", method =() => BugGun()},
                new ButtonInfo { buttonText = "bat gun [rg]", method =() => BatGun()},
                new ButtonInfo { buttonText = "ball gun [rg]", method =() => BeachBallGun()},
                new ButtonInfo { buttonText = "orbit bug", method =() => OrbitBug()},
                new ButtonInfo { buttonText = "orbit bat", method =() => OrbitBat()},
                new ButtonInfo { buttonText = "orbit monsters", method =() => OrbitMonster()},
            },

            new ButtonInfo[] // Name Mods 9
            {
                new ButtonInfo { buttonText = "exit name mods", method =() => Home(), isTogglable = false},
                new ButtonInfo { buttonText = "no name", method =() => NoName()},
                new ButtonInfo { buttonText = "wqsu", method =() => WqsuName()},
                new ButtonInfo { buttonText = "sub to ghost", method =() => SubToMe()},
                new ButtonInfo { buttonText = "subscribe", method =() => Subscribe()},
                new ButtonInfo { buttonText = "pbbv", method =() => PBBVName()},
                new ButtonInfo { buttonText = "echo", method =() => EchoName()},
                new ButtonInfo { buttonText = "daisy", method =() => DaisyName()},
                new ButtonInfo { buttonText = "run", method =() => RunName()},
                new ButtonInfo { buttonText = "banshee", method =() => BanSheeName()},
                new ButtonInfo { buttonText = "ryzr3", method =() => Ryzr3Name()},
                new ButtonInfo { buttonText = "apexgtag", method =() => ApexGtagName()},
                new ButtonInfo { buttonText = "cooked4listed", method =() => CookedForListedName()},
                new ButtonInfo { buttonText = "averagegorilla", method =() => AverageGorillaName()},
                new ButtonInfo { buttonText = "toxic", method =() => ToxicName()},
                new ButtonInfo { buttonText = "brandon", method =() => BrandonName()},
            },

            new ButtonInfo[] // Cheat Mods 10
            {
                new ButtonInfo { buttonText = "exit cheat mods", method =() => Home(), isTogglable = false},
                new ButtonInfo { buttonText = "give water splash [rg]", method =() => GiveWater()},
                new ButtonInfo { buttonText = "give snowball spam [rg]", method =() => GiveSnowballSpam()},
                new ButtonInfo { buttonText = "give waterballon spam [rg]" , method =() => GiveWaterSpam()},
                new ButtonInfo { buttonText = "give lava spam [rg]", method =() => GiveLavaSpam()},
                new ButtonInfo { buttonText = "give gift spam [rg]", method =() => GiveGiftSpam()},
                new ButtonInfo { buttonText = "give candy spam [rg]", method =() => GiveCandySpam()},
                new ButtonInfo { buttonText = "give fish spam [rg]", method =() => GiveFishSpam()},
                new ButtonInfo { buttonText = "give bug [rg]", method =() => GiveBug()},
                new ButtonInfo { buttonText = "give bat [rg]", method =() => GiveBat()},
                new ButtonInfo { buttonText = "give ball [rg]", method =() => GiveBall()},
                new ButtonInfo { buttonText = "give monsters [rg]", method =() => GiveMonsters()},
            },

            new ButtonInfo[] // Spam Mods 11
            {
                new ButtonInfo { buttonText = "exit spam mods [nw]", method =() => Home(), isTogglable = false},
                new ButtonInfo { buttonText = "snowball spammer [rg]", method =() => SnowballSpammer()},
                new ButtonInfo { buttonText = "waterballoon spammer [rg]", method =() => WaterSpammer()},
                new ButtonInfo { buttonText = "lava spammer [rg]", method =() => LavaSpammer()},
                new ButtonInfo { buttonText = "gift spammer [rg]", method =() => GiftSpammer()},
                new ButtonInfo { buttonText = "candy spammer [rg]", method =() => CandySpammer()},
                new ButtonInfo { buttonText = "fish spammer [rg]", method =() => FishSpammer()},
                new ButtonInfo { buttonText = "snowball gun [rg]", method =() => SnowBallGun()},
                new ButtonInfo { buttonText = "waterballoon gun [rg]", method =() => WaterGun()},
                new ButtonInfo { buttonText = "lava gun [rg]", method =() => LavaGun()},
                new ButtonInfo { buttonText = "gift gun [rg]", method =() => GiftGun()},
                new ButtonInfo { buttonText = "candy gun [rg]", method =() => CandyGun()},
                new ButtonInfo { buttonText = "fish gun [rg]", method =() => FishGun()},
            },
            
            new ButtonInfo[] // Notification Settings 12
            {
                new ButtonInfo { buttonText = "exit notification settings", method =() => Settings(), isTogglable = false},
                new ButtonInfo { buttonText = "enable notifications", enableMethod =() => SettingsMods.EnableNotifications(), disableMethod =() => SettingsMods.DisableNotifications(), enabled = !disableNotifications,},
                new ButtonInfo { buttonText = "player count on join", method =() => TGSGhostts_Menu.Mods.NotificationSettings.PlayerCount(),},
                new ButtonInfo { buttonText = "player count live/people leave or join", method =() => TGSGhostts_Menu.Mods.NotificationSettings.LivePlayerCount(),},
                new ButtonInfo { buttonText = "room joiner notification", method =() => TGSGhostts_Menu.Mods.NotificationSettings.RoomJoinerNotification(), disableMethod =() => NotificationSettings.RoomJoinerNotificationOff(),enabled = roomjoinernoti,},
                new ButtonInfo { buttonText = "get ping", method =() => TGSGhostts_Menu.Mods.NotificationSettings.GetPing(), isTogglable = false},
                new ButtonInfo { buttonText = "room full notifications", method =() => FunMods.RoomFullNotification(),},
                new ButtonInfo { buttonText = "who is master client", method =() => TGSGhostts_Menu.Mods.NotificationSettings.WhoIsMaster(), isTogglable = false,},
            },


             new ButtonInfo[] // Room Mods 14
            {
                new ButtonInfo{ buttonText = "exit room mods", method =() => Home(), isTogglable = false},
                new ButtonInfo{ buttonText = "mute all", method =() => MuteallPlayers(), isTogglable = false}, 
                new ButtonInfo{ buttonText = "report all", method =() => ReportAllForToxicity(), isTogglable = false},
                new ButtonInfo{ buttonText = "mute all music", method =() => MuteAllMusic(), isTogglable = false},
                new ButtonInfo{ buttonText = "vibrate all [M]", method =() => FunMods.VibrateAll()},
                new ButtonInfo{ buttonText = "slow all [M]", method =() => FunMods.SlowAll()},
                new ButtonInfo{ buttonText = "untag all [M]", method =() => FunMods.UnTagAll(), isTogglable = false},
                new ButtonInfo{ buttonText = "mat spam all [M]", method =() => FunMods.MatSpam(), isTogglable = true},
                new ButtonInfo{ buttonText = "tag all [rg]", method =() => FunMods.TagAll()},
                new ButtonInfo{ buttonText = "grab all ids", method =() => FunMods.GetAllIDs(), isTogglable = false},
            },
            // MOD COUNT: 125

        };
    }
}
