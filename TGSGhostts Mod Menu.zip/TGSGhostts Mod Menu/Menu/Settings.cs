﻿using TGSGhostt.Classes;
using UnityEngine;
using UnityEngine.InputSystem;
using static TGSGhostt.Menu.Main;
using static TGSGhostt.Mods.SettingsMods;

namespace TGSGhosttSettings
{
    internal class SettingsforMenu
    {
        public static Color32 buttonColorsOn = Color.grey;
        public static Color32 buttonColorsOff = Color.black;
        public static Color32 TextColorOn = Color.white;
        public static Color32 TextColorOff = Color.white;
        public static Color32 MenuColor = Color.blue;
        public static Color32 BorderColor = Color.black;
        public static Color32 GunPointerColor = MenuColor;
        public static string MenuTitle = "TGSGhostt's Menu";
        public static Font currentFont = Font.CreateDynamicFontFromOSFont("Agency YB", 24);
        public static bool fpsCounter = true;
        public static bool disconnectButton = true;
        public static bool rightHanded = false;
        public static bool disableNotifications = false;
        public static bool disconnectbuttonTop = true;
        public static bool disconnectbuttonBottom = false;
        public static bool disconnectbuttonLeft = false;
        public static bool disconnectbuttonRight = false;
        public static bool PageButtonsBottom = true;
        public static bool roomjoinernoti = true;
        public static bool ShowUIOn = true;
        public static bool BorderOn = true;
        public static bool PublicTracker = false;
        public static KeyCode keyboardButton = KeyCode.Q;
        public static float Width = 0.1f; // thickness??
        public static float Height = 1.3f; // side to side
        public static float Size = 1.14f; // up down
        public static Vector3 menuSize = new Vector3(Width, Height, Size);
        public static int buttonsPerPage = 8;
    }
}