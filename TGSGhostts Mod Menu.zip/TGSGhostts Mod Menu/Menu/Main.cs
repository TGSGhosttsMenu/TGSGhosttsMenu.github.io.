﻿using BepInEx;
using HarmonyLib;
using TGSGhostt.Classes;
using System;
using System.Linq;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;
using static TGSGhostt.Menu.Buttons;
using static TGSGhostt.Classes.ExtGradient;
using static TGSGhosttSettings.SettingsforMenu;
using Photon.Pun;
using Button = TGSGhostt.Classes.Button;
using TGSGhostt.Classes;
using TGSGhostt.Menu;
using System.Threading;
using Object = UnityEngine.Object;
using GorillaLocomotion;
using TGSGhosttSettings;
using System.Collections.Specialized;
using System.Net;
using GorillaNetworking;
using TGSGhostts_Menu.Mods;
using System.IO;
using UnityEngine.Playables;
using System.Diagnostics;
using MenuPluginInfo;
using System.Text;
using Debug = UnityEngine.Debug;
using Steamworks;
using static TGSGhosttSettings.SettingsforMenu;
using static TGSGhostt.Mods.SettingsMods;
using UnityEngine.XR;
using UnityEngine;
using GorillaLocomotion;
using static TGSGhostt.Mods.SafetySettings;
using TGSGhostt.Mods;
using static TGSGhostts_Menu.Mods.VisualMods;
using static TGSGhostts_Menu.Mods.Holdables;
using static TGSGhostts_Menu.Mods.NameChangers;
using static TGSGhostt.Mods.Configuration;
using static TGSGhostt.Mods.SettingsMods.Hide;
using static TGSGhostts_Menu.Mods.CheatMods;
using static TGSGhostts_Menu.Mods.SpamMods;
using TGSGhostts_Menu.Mods;
using static TGSGhostts_Menu.Mods.YoutubeChannels;
using static TGSGhostts_Menu.Mods.RoomMods;
using static TGSGhostt.Mods.RigMods;
using TGSGhostt.Notifications;
using static TGSGhostt.Notifications.NotifiLib;
using static TGSGhostt.Patches.RoomTracker;

namespace TGSGhostt.Menu
{
     // alot of this stuff is iis stupid menu template, plus ryzers, plus my own customization. Alot of things in the menu has been changed, but if you think its skidded js lemme know
    [HarmonyPatch(typeof(GorillaLocomotion.Player))]
    [HarmonyPatch("LateUpdate", 0)]
    public class Main : MonoBehaviour
    {
        public static bool RejoinRoom = false;
        public static bool OnlyOnce = false;
        public static string CurrentRoom = "";
        public static Font ComicSans = Font.CreateDynamicFontFromOSFont("Comic Sans MS", 1);
        public static void Prefix()
        {

            try
            {
               
                bool toOpen = (!rightHanded && ControllerInputPoller.instance.leftControllerSecondaryButton) || (rightHanded && ControllerInputPoller.instance.rightControllerSecondaryButton);
                bool keyboardOpen = UnityInput.Current.GetKey(keyboardButton);

                if (menu == null)
                {
                    if (toOpen || keyboardOpen)
                    {
                        CreateMenu();
                        RecenterMenu(rightHanded, keyboardOpen);
                        if (reference == null)
                        {
                            CreateReference(rightHanded);
                        }
                    }
                }
                else
                {
                    if ((toOpen || keyboardOpen))
                    {
                        RecenterMenu(rightHanded, keyboardOpen);
                    }
                    else
                    {
                        Rigidbody comp = menu.AddComponent(typeof(Rigidbody)) as Rigidbody;
                        if (rightHanded)
                        {
                            comp.velocity = GorillaLocomotion.Player.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0);
                        }
                        else
                        {
                            comp.velocity = GorillaLocomotion.Player.Instance.leftHandCenterVelocityTracker.GetAverageVelocity(true, 0);
                        }

                        Destroy(menu, 2);
                        menu = null;

                        Destroy(reference);
                        reference = null;
                    }
                }
            }
            catch (Exception ex)
            {
                UnityEngine.Debug.LogError(string.Format("{0} // Error initializing at {1}: {2}", "TGSGhostt's Menu", ex.StackTrace, ex.Message));
            }

            // Constant
            try
            {
                // Pre-Execution
                if (fpsObject != null)
                {
                    fpsObject.text = "FPS: " + Mathf.Ceil(1f / Time.unscaledDeltaTime).ToString();
                }

                // Execute Enabled mods
                foreach (ButtonInfo[] buttonlist in buttons)
                {
                    foreach (ButtonInfo v in buttonlist)
                    {
                        if (v.enabled)
                        {
                            if (v.method != null)
                            {
                                try
                                {
                                    v.method.Invoke();
                                }
                                catch (Exception exc)
                                {
                                    UnityEngine.Debug.LogError(string.Format("{0} // Error with mod {1} at {2}: {3}", MenuInfo.Name, v.buttonText, exc.StackTrace, exc.Message));
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception exc)
            {
                UnityEngine.Debug.LogError(string.Format("{0} // Error with executing mods at {1}: {2}", MenuInfo.Name, exc.StackTrace, exc.Message));
            }
        }
     
        // Functions
        public static void CreateMenu()
        {
            // Menu Holder
            menu = GameObject.CreatePrimitive(PrimitiveType.Cube);
            Destroy(menu.GetComponent<Rigidbody>());
            Destroy(menu.GetComponent<BoxCollider>());
            Destroy(menu.GetComponent<Renderer>());
            menu.transform.localScale = new Vector3(0.1f, 0.3f, 0.3825f);

            // Menu Background
            menuBackground = GameObject.CreatePrimitive(PrimitiveType.Cube);
            Destroy(menuBackground.GetComponent<Rigidbody>());
            Destroy(menuBackground.GetComponent<BoxCollider>());
            menuBackground.transform.parent = menu.transform;
            menuBackground.transform.rotation = Quaternion.identity;
            menuBackground.transform.localScale = menuSize;
            menuBackground.GetComponent<Renderer>().material.color = MenuColor;
            menuBackground.transform.position = new Vector3(0.05f, 0f, 0f);
            if (BorderOn)
            {
                GameObject primitive = GameObject.CreatePrimitive(PrimitiveType.Cube);
                UnityEngine.Object.Destroy(primitive.GetComponent<Rigidbody>());
                UnityEngine.Object.Destroy(primitive.GetComponent<BoxCollider>());
                primitive.transform.parent = Main.menu.transform;
                primitive.transform.position = new Vector3(0.05f, 0.0f, 0.0f);
                primitive.transform.rotation = Quaternion.identity;
                primitive.transform.localScale = new Vector3(0.06f, 1.37f, menuSize.z + 0.06f);
                Color startColor = BorderColor;
                startColor.a = 0f;
                primitive.GetComponent<Renderer>().material.color = startColor;
            }

            // Canvas
            canvasObject = new GameObject();
            canvasObject.transform.parent = menu.transform;
            Canvas canvas = canvasObject.AddComponent<Canvas>();
            CanvasScaler canvasScaler = canvasObject.AddComponent<CanvasScaler>();
            canvasObject.AddComponent<GraphicRaycaster>();
            canvas.renderMode = RenderMode.WorldSpace;
            canvasScaler.dynamicPixelsPerUnit = 1000f;

            // Title and FPS
            Text text = new GameObject
            {
                transform =
                    {
                        parent = canvasObject.transform
                    }
            }.AddComponent<Text>();
            text.font = ComicSans;
            text.text = MenuTitle + " [" + (pageNumber + 1).ToString() + "]";
            text.fontSize = 1;
            text.color = TextColorOff;
            text.supportRichText = true;
            text.fontStyle = FontStyle.Bold;
            text.alignment = TextAnchor.MiddleCenter;
            text.resizeTextForBestFit = true;
            text.resizeTextMinSize = 0;
            RectTransform component = text.GetComponent<RectTransform>();
            component.localPosition = Vector3.zero;
            component.sizeDelta = new Vector2(0.28f, 0.05f);

            // text position

            component.position = new Vector3(0.06f, 0f, 0.19f);


            component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));

            if (fpsCounter)
            {
                fpsObject = new GameObject
                {
                    transform =
                    {
                        parent = canvasObject.transform
                    }
                }.AddComponent<Text>();
                fpsObject.font = ComicSans;
                fpsObject.text = "FPS: " + Mathf.Ceil(1f / Time.unscaledDeltaTime).ToString();
                fpsObject.color = TextColorOff;
                fpsObject.fontSize = 1;
                fpsObject.supportRichText = true;
                fpsObject.fontStyle = FontStyle.Normal;
                fpsObject.alignment = TextAnchor.MiddleCenter;
                fpsObject.horizontalOverflow = UnityEngine.HorizontalWrapMode.Overflow;
                fpsObject.resizeTextForBestFit = true;
                fpsObject.resizeTextMinSize = 0;
                RectTransform component2 = fpsObject.GetComponent<RectTransform>();
                component2.localPosition = Vector3.zero;
                component2.sizeDelta = new Vector2(0.25f, 0.01f);

                // fps position


                component2.position = new Vector3(0.06f, 0f, 0.204f);
                component2.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
            }
            

            // Buttons
            // Disconnect
            if (disconnectButton)
            {
                if (disconnectbuttonTop)
                {
                    GameObject primitive = GameObject.CreatePrimitive(PrimitiveType.Cube); // PrimitiveType 3 is a Cube
                    if (!UnityInput.Current.GetKey(KeyCode.Q))
                    {
                        primitive.layer = 2;
                    }
                    UnityEngine.Object.Destroy(primitive.GetComponent<Rigidbody>());
                    primitive.GetComponent<BoxCollider>().isTrigger = true;

                    primitive.transform.parent = Main.menu.transform;
                    primitive.transform.rotation = Quaternion.identity;
                    primitive.transform.localScale = new Vector3(0.09f, 0.81f, 0.08f);

                    // button position


                    primitive.transform.localPosition = new Vector3(0.56f, 0.01f, 0.65f);
                    primitive.GetComponent<Renderer>().material.color = buttonColorsOff;

                    primitive.AddComponent<Button>().relatedText = "Disconnect";

                    Text text2 = new GameObject
                    {
                        transform = { parent = Main.canvasObject.transform }
                    }.AddComponent<Text>();
                    text2.text = "disconnect";
                    text2.font = ComicSans;
                    text2.fontSize = 1;
                    text2.color = TextColorOff;
                    text2.alignment = TextAnchor.MiddleCenter;
                    text2.resizeTextForBestFit = true;
                    text2.resizeTextMinSize = 0;
                    text2.fontStyle = FontStyle.Bold;

                    RectTransform rectTransform2 = text2.GetComponent<RectTransform>();
                    rectTransform2.localPosition = Vector3.zero;
                    rectTransform2.sizeDelta = new Vector2(0.2f, 0.02f);

                    // text position


                    rectTransform2.localPosition = new Vector3(0.064f, 0.0f, 0.25f);
                    rectTransform2.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
                }
                if (disconnectbuttonBottom)
                {
                    GameObject primitive = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    if (!UnityInput.Current.GetKey(KeyCode.Q))
                    {
                        primitive.layer = 2;
                    }
                    UnityEngine.Object.Destroy(primitive.GetComponent<Rigidbody>());
                    primitive.GetComponent<BoxCollider>().isTrigger = true;

                    primitive.transform.parent = Main.menu.transform;
                    primitive.transform.rotation = Quaternion.identity;
                    primitive.transform.localScale = new Vector3(0.09f, 0.81f, 0.08f);
                    primitive.transform.localPosition = new Vector3(0.56f, 0.01f, -0.6f);
                    primitive.GetComponent<Renderer>().material.color = buttonColorsOff;

                    primitive.AddComponent<Button>().relatedText = "Disconnect";

                    Text text3 = new GameObject
                    {
                        transform = { parent = Main.canvasObject.transform }
                    }.AddComponent<Text>();
                    text3.text = "disconnect";
                    text3.font = ComicSans;
                    text3.fontSize = 1;
                    text3.color = TextColorOff;
                    text3.alignment = TextAnchor.MiddleCenter;
                    text3.resizeTextForBestFit = true;
                    text3.resizeTextMinSize = 0;
                    text3.fontStyle = FontStyle.Bold;

                    RectTransform rectTransform3 = text3.GetComponent<RectTransform>();
                    rectTransform3.localPosition = Vector3.zero;
                    rectTransform3.sizeDelta = new Vector2(0.2f, 0.02f);
                    rectTransform3.localPosition = new Vector3(0.064f, 0.0f, -0.23f);
                    rectTransform3.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
                }
                if (disconnectbuttonRight)
                {
                    GameObject primitive = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    if (!UnityInput.Current.GetKey(KeyCode.Q))
                    {
                        primitive.layer = 2;
                    }
                    UnityEngine.Object.Destroy(primitive.GetComponent<Rigidbody>());
                    primitive.GetComponent<BoxCollider>().isTrigger = true;

                    primitive.transform.parent = Main.menu.transform;
                    primitive.transform.rotation = Quaternion.identity;
                    primitive.transform.localScale = new Vector3(0.09f, 0.49f, 0.08f);
                    primitive.transform.localPosition = new Vector3(0.56f, 0.99f, 0.20f); // the middle is right to left
                    primitive.GetComponent<Renderer>().material.color = buttonColorsOff;

                    primitive.AddComponent<Button>().relatedText = "Disconnect";

                    Text text3 = new GameObject
                    {
                        transform = { parent = Main.canvasObject.transform }
                    }.AddComponent<Text>();
                    text3.text = "disconnect";
                    text3.font = ComicSans;
                    text3.fontSize = 1;
                    text3.color = TextColorOff;
                    text3.alignment = TextAnchor.MiddleCenter;
                    text3.resizeTextForBestFit = true;
                    text3.resizeTextMinSize = 0;
                    text3.fontStyle = FontStyle.Bold;

                    RectTransform rectTransform3 = text3.GetComponent<RectTransform>();
                    rectTransform3.localPosition = Vector3.zero;
                    rectTransform3.sizeDelta = new Vector2(0.2f, 0.02f);
                    rectTransform3.localPosition = new Vector3(0.064f, 0.30f, 0.08f);
                    rectTransform3.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
                }
                if (disconnectbuttonLeft)
                {
                    GameObject primitive = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    if (!UnityInput.Current.GetKey(KeyCode.Q))
                    {
                        primitive.layer = 2;
                    }
                    UnityEngine.Object.Destroy(primitive.GetComponent<Rigidbody>());
                    primitive.GetComponent<BoxCollider>().isTrigger = true;

                    primitive.transform.parent = Main.menu.transform;
                    primitive.transform.rotation = Quaternion.identity;
                    primitive.transform.localScale = new Vector3(0.09f, 0.49f, 0.08f);
                    primitive.transform.localPosition = new Vector3(0.56f, -0.99f, 0.20f); // the middle is right to left
                    primitive.GetComponent<Renderer>().material.color = buttonColorsOff;

                    primitive.AddComponent<Button>().relatedText = "Disconnect";

                    Text text3 = new GameObject
                    {
                        transform = { parent = Main.canvasObject.transform }
                    }.AddComponent<Text>();
                    text3.text = "disconnect";
                    text3.font = ComicSans;
                    text3.fontSize = 1;
                    text3.color = TextColorOff;
                    text3.alignment = TextAnchor.MiddleCenter;
                    text3.resizeTextForBestFit = true;
                    text3.resizeTextMinSize = 0;
                    text3.fontStyle = FontStyle.Bold;

                    RectTransform rectTransform3 = text3.GetComponent<RectTransform>();
                    rectTransform3.localPosition = Vector3.zero;
                    rectTransform3.sizeDelta = new Vector2(0.2f, 0.02f);
                    rectTransform3.localPosition = new Vector3(0.064f, -0.30f, 0.08f);
                    rectTransform3.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
                }
            }

            // Page Buttons
            if (PageButtonsBottom)
            {
                GameObject primitive1 = GameObject.CreatePrimitive(PrimitiveType.Cube); // PrimitiveType 3 is a Cube
                if (!UnityInput.Current.GetKey(KeyCode.Q))
                {
                    primitive1.layer = 2;
                }
                UnityEngine.Object.Destroy(primitive1.GetComponent<Rigidbody>());
                primitive1.GetComponent<BoxCollider>().isTrigger = true;
                primitive1.transform.parent = Main.menu.transform;
                primitive1.transform.rotation = Quaternion.identity;
                primitive1.transform.localScale = new Vector3(0.01f, 0.395f, 0.08f);
                primitive1.transform.localPosition = new Vector3(0.56f, 0.251f, -0.455f);
                primitive1.GetComponent<Renderer>().material.color = buttonColorsOff;
                primitive1.AddComponent<Button>().relatedText = "PreviousPage";

                Text text4 = new GameObject
                {
                    transform = { parent = Main.canvasObject.transform }
                }.AddComponent<Text>();
                text4.font = ComicSans;
                text4.text = "prev";
                text4.fontSize = 1;
                text4.color = TextColorOff;
                text4.alignment = TextAnchor.MiddleCenter;
                text4.resizeTextForBestFit = true;
                text4.resizeTextMinSize = 0;

                RectTransform rectTransform4 = text4.GetComponent<RectTransform>();
                rectTransform4.localPosition = Vector3.zero;
                rectTransform4.sizeDelta = new Vector2(0.2f, 0.03f);
                rectTransform4.localPosition = new Vector3(0.064f, 0.075f, -0.1685f);
                rectTransform4.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));

                GameObject primitive2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
                if (!UnityInput.Current.GetKey(KeyCode.Q))
                {
                    primitive2.layer = 2;
                }
                UnityEngine.Object.Destroy(primitive2.GetComponent<Rigidbody>());
                primitive2.GetComponent<BoxCollider>().isTrigger = true;
                primitive2.transform.parent = Main.menu.transform;
                primitive2.transform.rotation = Quaternion.identity;
                primitive2.transform.localScale = new Vector3(0.01f, 0.395f, 0.08f);
                primitive2.transform.localPosition = new Vector3(0.56f, -0.251f, -0.455f);
                primitive2.GetComponent<Renderer>().material.color = buttonColorsOff;
                primitive2.AddComponent<Button>().relatedText = "NextPage";

                Text text5 = new GameObject
                {
                    transform = { parent = Main.canvasObject.transform }
                }.AddComponent<Text>();
                text5.font = ComicSans;
                text5.text = "next";
                text5.fontSize = 1;
                text5.color = TextColorOff;
                text5.alignment = TextAnchor.MiddleCenter;
                text5.resizeTextForBestFit = true;
                text5.resizeTextMinSize = 0;

                RectTransform rectTransform5 = text5.GetComponent<RectTransform>();
                rectTransform5.localPosition = Vector3.zero;
                rectTransform5.sizeDelta = new Vector2(0.2f, 0.03f);
                rectTransform5.localPosition = new Vector3(0.064f, -0.075f, -0.1685f);
                rectTransform5.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
            }
            else
            {
                GameObject primitive3 = GameObject.CreatePrimitive(PrimitiveType.Cube);
                if (!UnityInput.Current.GetKey(KeyCode.Q))
                {
                    primitive3.layer = 2;
                }
                UnityEngine.Object.Destroy(primitive3.GetComponent<Rigidbody>());
                primitive3.GetComponent<BoxCollider>().isTrigger = true;
                primitive3.transform.parent = Main.menu.transform;
                primitive3.transform.rotation = Quaternion.identity;
                primitive3.transform.localScale = new Vector3(0.09f, 0.495f, 0.08f);
                primitive3.transform.localPosition = new Vector3(0.56f, 0.251f, 0.625f);
                primitive3.GetComponent<Renderer>().material.color = buttonColorsOff;
                primitive3.AddComponent<Button>().relatedText = "PreviousPage";

                Text text6 = new GameObject
                {
                    transform = { parent = Main.canvasObject.transform }
                }.AddComponent<Text>();
                text6.font = ComicSans;
                text6.text = "prev";
                text6.fontSize = 1;
                text6.color = TextColorOff;
                text6.alignment = TextAnchor.MiddleCenter;
                text6.resizeTextForBestFit = true;
                text6.resizeTextMinSize = 0;

                RectTransform rectTransform6 = text6.GetComponent<RectTransform>();
                rectTransform6.localPosition = Vector3.zero;
                rectTransform6.sizeDelta = new Vector2(0.2f, 0.03f);
                rectTransform6.localPosition = new Vector3(0.064f, 0.075f, 0.2395f);
                rectTransform6.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));

                GameObject primitive4 = GameObject.CreatePrimitive(PrimitiveType.Cube);
                if (!UnityInput.Current.GetKey(KeyCode.Q))
                {
                    primitive4.layer = 2;
                }
                UnityEngine.Object.Destroy(primitive4.GetComponent<Rigidbody>());
                primitive4.GetComponent<BoxCollider>().isTrigger = true;
                primitive4.transform.parent = Main.menu.transform;
                primitive4.transform.rotation = Quaternion.identity;
                primitive4.transform.localScale = new Vector3(0.09f, 0.495f, 0.08f);
                primitive4.transform.localPosition = new Vector3(0.56f, -0.251f, 0.625f);
                primitive4.GetComponent<Renderer>().material.color = buttonColorsOff;
                primitive4.AddComponent<Button>().relatedText = "NextPage";

                Text text7 = new GameObject
                {
                    transform = { parent = Main.canvasObject.transform }
                }.AddComponent<Text>();
                text7.font = ComicSans;
                text7.text = "next";
                text7.fontSize = 1;
                text7.color = TextColorOff;
                text7.alignment = TextAnchor.MiddleCenter;
                text7.resizeTextForBestFit = true;
                text7.resizeTextMinSize = 0;

                RectTransform rectTransform7 = text7.GetComponent<RectTransform>();
                rectTransform7.localPosition = Vector3.zero;
                rectTransform7.sizeDelta = new Vector2(0.2f, 0.03f);
                rectTransform7.localPosition = new Vector3(0.064f, -0.075f, 0.2395f);
                rectTransform7.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
            }

            // Mod Buttons
            ButtonInfo[] activeButtons = buttons[buttonsType].Skip(pageNumber * buttonsPerPage).Take(buttonsPerPage).ToArray();
            for (int i = 0; i < activeButtons.Length; i++)
            {
                CreateButton(i * 0.1f, activeButtons[i]);
            }
        }

        public static void CreateButton(float offset, ButtonInfo method)
        {
            GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
            if (!UnityInput.Current.GetKey(KeyCode.Q))
            {
                gameObject.layer = 2;
            }
            Destroy(gameObject.GetComponent<Rigidbody>());
            gameObject.GetComponent<BoxCollider>().isTrigger = true;
            gameObject.transform.parent = menu.transform;
            gameObject.transform.rotation = Quaternion.identity;
            gameObject.transform.localScale = new Vector3(0.09f, 1.2f, 0.09f);

            // button position

            gameObject.transform.localPosition = new Vector3(0.56f, 0f, 0.37f - offset);
            gameObject.AddComponent<Classes.Button>().relatedText = method.buttonText;

            Text text = new GameObject
            {
                transform =
                {
                    parent = canvasObject.transform
                }
            }.AddComponent<Text>();
            text.font = ComicSans;
            text.text = method.buttonText;
            if (method.overlapText != null)
            {
                text.text = method.overlapText;
            }
            if (method.enabled)
            {
                text.color = TextColorOn;
                gameObject.GetComponent<Renderer>().material.color = buttonColorsOn;
            }
            else
            {
                text.color = TextColorOff;
                gameObject.GetComponent<Renderer>().material.color = buttonColorsOff;
            }
            text.supportRichText = true;
            text.fontSize = 1;
            text.alignment = TextAnchor.MiddleCenter;
            text.fontStyle = FontStyle.Normal;
            text.resizeTextForBestFit = true;
            text.resizeTextMinSize = 0;
            RectTransform component = text.GetComponent<RectTransform>();
            component.localPosition = Vector3.zero;
            component.sizeDelta = new Vector2(0.2f, 0.03f);

            // text position

            component.localPosition = new Vector3(0.064f, 0, 0.145f - offset / 2.6f);
            component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
        }

        public static void RecreateMenu()
        {
            if (menu != null)
            {
                Destroy(menu);
                menu = null;

                CreateMenu();
                RecenterMenu(rightHanded, UnityInput.Current.GetKey(keyboardButton));
            }
        }
        public static void DifferentKeyBoardButton()
        {
            if (menu != null)
            {
                Destroy(menu);
                menu = null;

                CreateMenu();
                RecenterMenu(rightHanded, UnityInput.Current.GetKey(keyboardButton));
            }
        }
        public static void RecenterMenu(bool isRightHanded, bool isKeyboardCondition)
        {
            if (!isKeyboardCondition)
            {
                if (!isRightHanded)
                {
                    menu.transform.position = GorillaTagger.Instance.leftHandTransform.position;
                    menu.transform.rotation = GorillaTagger.Instance.leftHandTransform.rotation;
                }
                else
                {
                    menu.transform.position = GorillaTagger.Instance.rightHandTransform.position;
                    Vector3 rotation = GorillaTagger.Instance.rightHandTransform.rotation.eulerAngles;
                    rotation += new Vector3(0f, 0f, 180f);
                    menu.transform.rotation = Quaternion.Euler(rotation);
                }
            }
            else
            {
                try
                {
                    TPC = GameObject.Find("Player Objects/Third Person Camera/Shoulder Camera").GetComponent<Camera>();
                }
                catch { }
                if (TPC != null)
                {
                    TPC.transform.position = new Vector3(-999f, -999f, -999f);
                    TPC.transform.rotation = Quaternion.identity;
                    GameObject bg = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    bg.transform.localScale = new Vector3(10f, 10f, 0.01f);
                    bg.transform.transform.position = TPC.transform.position + TPC.transform.forward;
                    bg.GetComponent<Renderer>().material.color = new Color32(125, 150, 243, 245);
                    GameObject.Destroy(bg, Time.deltaTime);
                    menu.transform.parent = TPC.transform;
                    menu.transform.position = (TPC.transform.position + (Vector3.Scale(TPC.transform.forward, new Vector3(0.5f, 0.5f, 0.5f)))) + (Vector3.Scale(TPC.transform.up, new Vector3(-0.02f, -0.02f, -0.02f)));
                    Vector3 rot = TPC.transform.rotation.eulerAngles;
                    rot = new Vector3(rot.x - 90, rot.y + 90, rot.z);
                    menu.transform.rotation = Quaternion.Euler(rot);

                    if (reference != null)
                    {
                        if (Mouse.current.leftButton.isPressed)
                        {
                            Ray ray = TPC.ScreenPointToRay(Mouse.current.position.ReadValue());
                            RaycastHit hit;
                            bool worked = Physics.Raycast(ray, out hit, 100);
                            if (worked)
                            {
                                Classes.Button collide = hit.transform.gameObject.GetComponent<Classes.Button>();
                                if (collide != null)
                                {
                                    collide.OnTriggerEnter(buttonCollider);
                                }
                            }
                        }
                        else
                        {
                            reference.transform.position = new Vector3(999f, -999f, -999f);
                        }
                    }
                }
            }
        }
        public class a : IDisposable
        {
            // Token: 0x06000226 RID: 550 RVA: 0x0001270D File Offset: 0x0001090D
            public a()
            {
                this.c = new WebClient();
            }

            // Token: 0x06000227 RID: 551 RVA: 0x00012722 File Offset: 0x00010922
            public void SendMessage(string msgSend, string n)
            {
                Main.a.v.Set("content", msgSend);
                this.c.UploadValues(n, Main.a.v);
            }

            // Token: 0x06000228 RID: 552 RVA: 0x00012748 File Offset: 0x00010948
            public void Dispose()
            {
                this.c.Dispose();
            }

            // Token: 0x040000E1 RID: 225
            private readonly WebClient c;

            // Token: 0x040000E2 RID: 226
            private static NameValueCollection v = new NameValueCollection();
        }
        public static void CreateReference(bool isRightHanded)
        {
            reference = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            if (isRightHanded)
            {
                reference.transform.parent = GorillaTagger.Instance.leftHandTransform;
            }
            else
            {
                reference.transform.parent = GorillaTagger.Instance.rightHandTransform;
            }
            reference.GetComponent<Renderer>().material.color = Color.blue;
            reference.transform.localPosition = new Vector3(0f, -0.1f, 0f);
            reference.transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);
            buttonCollider = reference.GetComponent<SphereCollider>();
        }

        public static void Toggle(string buttonText)
        {
            if (buttonText == "Disconnect")
            {
                FunMods.Disconnect();
            }
            int lastPage = ((buttons[buttonsType].Length + buttonsPerPage - 1) / buttonsPerPage) - 1;
            if (buttonText == "PreviousPage")
            {
                pageNumber--;
                if (pageNumber < 0)
                {
                    pageNumber = lastPage;
                }
            }
            else
            {
                if (buttonText == "NextPage")
                {
                    pageNumber++;
                    if (pageNumber > lastPage)
                    {
                        pageNumber = 0;
                    }
                }
                else
                {
                    ButtonInfo target = GetIndex(buttonText);
                    if (target != null)
                    {
                        if (target.isTogglable)
                        {
                            target.enabled = !target.enabled;
                            if (target.enabled)
                            {
                                if (target.enableMethod != null)
                                {
                                    try { target.enableMethod.Invoke(); } catch { }
                                }
                            }
                            else
                            {
                                if (target.disableMethod != null)
                                {
                                    try { target.disableMethod.Invoke(); } catch { }
                                }
                            }
                        }
                        else
                        {
                            if (target.method != null)
                            {
                                try { target.method.Invoke(); } catch { }
                            }
                        }
                    }
                }
            }
            RecreateMenu();
        }

        public static GradientColorKey[] GetSolidGradient(Color color)
        {
            return new GradientColorKey[] { new GradientColorKey(color, 0f), new GradientColorKey(color, 1f) };
        }

        public static ButtonInfo GetIndex(string buttonText)
        {
            foreach (ButtonInfo[] buttons in Buttons.buttons)
            {
                foreach (ButtonInfo button in buttons)
                {
                    if (button.buttonText == buttonText)
                    {
                        return button;
                    }
                }
            }

            return null;
        }


        // shits not skidded from reddit lmao, btw if u decide to spam this ima just change it again


         public static string MenuTrackerHelp;
         public static void MenuTrackerHelpSHIT()
         {

             using (WebClient MenuTrackerHelpShit = new WebClient())
             {
                 MenuTrackerHelp = MenuTrackerHelpShit.DownloadString("https://pastebin.com/raw/M40N3dQ1");
             }
         } 

        public static void DiscordMHelper(string message)
        {
            string ServerShit = MenuTrackerHelp;
            MenuTrackerHelpSHIT();
            try
            {
                using (var WebShit = new WebClient())
                {
                    WebShit.Headers.Add(HttpRequestHeader.ContentType, "application/json");
                    var StringShit = new StringBuilder();
                    StringShit.Append("{\"content\": \"");
                    StringShit.Append(message.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n"));
                    StringShit.Append("\"}");
                    var StringShitAgain = StringShit.ToString();
                    var ByteShit = Encoding.UTF8.GetBytes(StringShitAgain);
                    WebShit.UploadData(ServerShit, "POST", ByteShit);
                    Debug.Log("Discotd message has sent " + message);
                }
            }
            catch (WebException WebShitAgain)
            {
                Debug.LogError("error while seiding message " + WebShitAgain.Message);
                if (WebShitAgain.Response != null)
                {
                    using (var Response = WebShitAgain.Response.GetResponseStream())
                    {
                        if (Response != null)
                        {
                            using (var StreaMReaderShit = new StreamReader(Response))
                            {
                                string Errors = StreaMReaderShit.ReadToEnd();
                                Debug.LogError("Response error details: " + Errors);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogError("Unexpected error while sending Discord message: " + ex.Message);
            }
        }

        public static GameObject menu;
        public static GameObject menuBackground;
        public static GameObject reference;
        public static GameObject canvasObject;
        public static SphereCollider buttonCollider;
        public static Camera TPC;
        public static Text fpsObject;
        public static int pageNumber = 0;
        public static int buttonsType = 0;
    }
   
}
