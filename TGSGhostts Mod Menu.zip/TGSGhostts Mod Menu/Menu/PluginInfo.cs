﻿namespace MenuPluginInfo
{
    internal class MenuInfo
    {
        public const string GUID = "org.ghost.gorillatag.tgsghosttsmenu";
        public const string Name = "TGSGhostt's Menu";
        public const string Description = "tgsghostt has aura fr";
        public const string Version = "2.1.0";
    }
}
