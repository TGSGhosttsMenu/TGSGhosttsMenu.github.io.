﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine.InputSystem;

namespace ControllerInput
{
    public class Input
    {
        public static bool AButton()
        {
            return ControllerInputPoller.instance.rightControllerPrimaryButton || Mouse.current.forwardButton.isPressed;
        }
        public static bool BButton()
        {
            return ControllerInputPoller.instance.rightControllerSecondaryButton || Mouse.current.backButton.isPressed;
        }
        public static bool XButton()
        {
            return ControllerInputPoller.instance.leftControllerPrimaryButton || Keyboard.current.tKey.isPressed;
        }
        public static bool YButton()
        {
            return ControllerInputPoller.instance.leftControllerSecondaryButton || Keyboard.current.fKey.isPressed;
        }
        public static bool LT()
        {
            return ControllerInputPoller.instance.leftControllerIndexFloat == 1 || Mouse.current.leftButton.isPressed;
        }
        public static bool RT()
        {
            return ControllerInputPoller.instance.rightControllerIndexFloat == 1 || Keyboard.current.eKey.isPressed;
        }
        public static bool LG()
        {
            return ControllerInputPoller.instance.leftGrab || Keyboard.current.gKey.isPressed;
        }
        public static bool RG()
        {
            return ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed;
        }
    }
}