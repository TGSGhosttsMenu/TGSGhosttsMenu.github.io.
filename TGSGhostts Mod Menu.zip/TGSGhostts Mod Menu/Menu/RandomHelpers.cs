﻿using GorillaNetworking;
using Photon.Pun;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using UnityEngine;

namespace MenuHelpers
{
    public class RandomHelpers
    {
        public static void CreateFolder(string name, bool CreateFileWithIt, string filename = "")
        {
            if (!Directory.Exists(name))
            {
                Directory.CreateDirectory(name);
            }
            if (CreateFileWithIt)
            {
                if (!File.Exists(filename + ".txt") && filename != "")
                {
                    File.CreateText(filename + ".txt");
                }
            }
        } 
        public static bool FileContainsTrue = false;
        public static void IfFileContains(string FileName, string Contains)
        {
            if (File.Exists(FileName))
            {
                if (File.ReadAllText(FileName).Contains(Contains))
                {
                    FileContainsTrue = true;
                }
                else
                {
                    FileContainsTrue = false;
                }
            }
        }
        public static void OpenLink(string Url = "")
        {
            if (Url == "")
            {
                Process.Start("https://www.google.com");
            }
            else if (Url.Length > 3)
            {
                Process.Start(Url);
            }
        }
        public static void CreateFile(string name = "null", string Path = "")
        {
            if (Path == "")
            {
                if (!File.Exists(name + ".txt"))
                {
                    File.CreateText(name + ".txt");
                }
            }
            else
            {
                if (!File.Exists(Path + "/" + name + ".txt"))
                {
                    File.CreateText(Path + "/" + name + ".txt");
                }
            }
        }
        public static bool CheckName(string name)
        {
            return PhotonNetwork.LocalPlayer.NickName == name;
        }
        public static bool InSpecificRoom(string RoomName)
        {
            return PhotonNetwork.CurrentRoom.Name == RoomName;
        }
        public static void JoinCode(string c)
        {
            c.ToUpper();
            PhotonNetworkController.Instance.AttemptToJoinSpecificRoom("", JoinType.Solo);
        }
        public static void CosmeticShit(string Location, bool IsActive)
        {
            GameObject.Find(Location).SetActive(IsActive);
        }
    }
}
