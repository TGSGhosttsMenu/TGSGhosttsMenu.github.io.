﻿using ExitGames.Client.Photon;
using Photon.Pun;
using Photon.Realtime;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using TGSGhostt.Menu;
using GorillaNetworking;
using static TGSGhostt.Menu.Main;
using TGSGhostts_Menu.Mods;
using TGSGhostt.Notifications;

namespace TGSGhostt.Mods
{
    internal class SafetySettings
    {
        public static List<GorillaScoreBoard> currentboards = new List<GorillaScoreBoard>();
        public static GorillaScoreBoard[] boards = (GorillaScoreBoard[])null;

        public static void AntiReport()
        {
            VRRig[] riglist = UnityEngine.Object.FindObjectsOfType<VRRig>();
            foreach (GorillaPlayerScoreboardLine line in UnityEngine.Object.FindObjectsOfType<GorillaPlayerScoreboardLine>())
            {
                if (line.linePlayer.ActorNumber == PhotonNetwork.LocalPlayer.ActorNumber)
                {
                    foreach (VRRig rig in riglist)
                    {
                        if (rig != GorillaTagger.Instance.offlineVRRig)
                        {
                            float lefthand = Vector3.Distance(line.reportButton.transform.position, rig.leftHandTransform.position);
                            float righthand = Vector3.Distance(line.reportButton.transform.position, rig.rightHandTransform.position);
                            if (lefthand < 1.2f || righthand < 1.2f)
                            {
                                PhotonNetwork.Disconnect();
                                NotifiLib.SendNotification("Anti Report Has benn Activiated, You were closley reported. Please turn on safety settings incase! ");
                            }
                        }
                    }
                }
            }
        }

        public static void AntiReportReconnect()
        {
            try
            {
                if (SafetySettings.boards == null)
                {
                    SafetySettings.boards = UnityEngine.Object.FindObjectsOfType<GorillaScoreBoard>();
                    foreach (var board in SafetySettings.boards)
                    {
                        try
                        {
                            Debug.Log("Found board");
                            if (!SafetySettings.currentboards.Contains(board))
                            {
                                SafetySettings.currentboards.Add(board);
                                Debug.Log("Added to list");
                            }
                            else
                            {
                                Debug.Log("Board is already on the list");
                            }
                        }
                        catch (Exception e)
                        {
                            Debug.LogError("Failed to process board: " + e.Message);
                            if (!SafetySettings.currentboards.Contains(board))
                            {
                                SafetySettings.currentboards.Add(board);
                                Debug.Log("Added to list despite the error");
                            }
                        }
                    }
                }
                foreach (var LeaderBoardShit in SafetySettings.currentboards)
                {
                    foreach (var line in LeaderBoardShit.lines)
                    {
                        if (line.linePlayer == NetworkSystem.Instance.LocalPlayer)
                        {
                            var ReporButtonShits = line.reportButton.gameObject.transform;
                            foreach (var vrrig in GorillaParent.instance.vrrigs)
                            {
                                if (vrrig != GorillaTagger.Instance.offlineVRRig)
                                {
                                    float RightHand = Vector3.Distance(vrrig.rightHandTransform.position, ReporButtonShits.position);
                                    float LeftHand = Vector3.Distance(vrrig.leftHandTransform.position, ReporButtonShits.position);
                                    float MaxHandDistance = 0.55f;

                                    if (RightHand < MaxHandDistance || LeftHand < MaxHandDistance)
                                    {
                                        PhotonNetwork.Disconnect();
                                        SafetySettings.FlushRPCs();
                                        NotifiLib.SendNotification("<color=grey>[</color><color=red>Menu</color><color=grey>]</color> <color=white>Someone tried to report you, you have been disconnected</color>");
                                        if (!PhotonNetwork.InRoom && Main.CurrentRoom != "")
                                        {
                                            CheatMods.JoinLastRoom();
                                            NotifiLib.SendNotification("<color=white>SOME HAS ATTEMPTED TO REPORT YOU! REJOINING!</color>");
                                        }
                                        else
                                        {
                                            NotifiLib.SendNotification("<color=white>ERROR WHILE REJOINING. UNKNOWN ERROR!</color>");
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogError("An error occurred in AntiReport: " + ex.Message);
            }
        }



        public static void FlushRPCs()
        {
            try
            {
                RaiseEventOptions raiseEventOptions = new RaiseEventOptions
                {
                    CachingOption = EventCaching.RemoveFromRoomCache,
                    TargetActors = new int[] { PhotonNetwork.LocalPlayer.ActorNumber }
                };
                PhotonNetwork.NetworkingClient.OpRaiseEvent((byte)200, null, raiseEventOptions, SendOptions.SendReliable);
                GorillaNot.instance.rpcErrorMax = int.MaxValue;
                GorillaNot.instance.rpcCallLimit = int.MaxValue;
                GorillaNot.instance.logErrorMax = int.MaxValue;
                PhotonNetwork.RemoveRPCs(PhotonNetwork.LocalPlayer);
                PhotonNetwork.OpCleanRpcBuffer(PhotonNetwork.GetPhotonView(GorillaTagger.Instance.myVRRig.ViewID));
                PhotonNetwork.RemoveBufferedRPCs(GorillaTagger.Instance.myVRRig.ViewID, null, null);
                PhotonNetwork.RemoveRPCsInGroup(int.MaxValue);
                PhotonNetwork.SendAllOutgoingCommands();
                GorillaNot.instance.OnPlayerLeftRoom(PhotonNetwork.LocalPlayer);
            }
            catch (Exception ex)
            {
                Debug.LogError($"Failed to flush RPCs: {ex.Message}");
            }
        }


        public static void AntiModerator()
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                if (!vrrig.isOfflineVRRig && vrrig.concatStringOfCosmeticsAllowed.Contains("LBAAK"))
                {
                    PhotonNetwork.Disconnect();
                    NotifiLib.SendNotification("<color=grey>[</color><color=red>Menu</color><color=grey>]</color> <color=white>A moderator has joined, you have been disconnected</color>");
                }
            }
        }

        public static void AntiModChecker()
        {
            try
            {
                Hashtable properties = new Hashtable
        {
            { "mods", null }
        };
                PhotonNetwork.LocalPlayer.SetCustomProperties(properties);
                Debug.Log("AntiModChecker: Successfully set player properties to null.");
            }
            catch (Exception ex)
            {
                Debug.LogError($"An error occurred in AntiModChecker: {ex.Message}");
            }
        }


    }
}
