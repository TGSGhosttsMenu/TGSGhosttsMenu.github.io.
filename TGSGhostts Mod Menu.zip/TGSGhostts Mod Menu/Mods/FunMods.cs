﻿using GorillaNetworking;
using Photon.Pun;
using Photon.Realtime;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using TGSGhostt.Menu;
using UnityEngine;
using UnityEngine.XR;
using TGSGhosttSettings;
using TGSGhostt.Mods;
using Object = UnityEngine.Object;
using Player = GorillaLocomotion.Player;
using TGSGhostt.Classes;
using PlayFab.ProfilesModels;
using HarmonyLib;
using TGSGhostts_Menu.Mods;
using TGSGhostt.Notifications;
using Photon.Pun;
using static TGSGhostts_Menu.Classes.GunLib;
using TGSGhostts_Menu.Classes;
using GorillaLocomotion.Swimming;
using UnityEngine.XR.Interaction.Toolkit;

internal class FunMods
{
    public static void Disconnect()
    {
        if (PhotonNetwork.InRoom)
        {
            PhotonNetwork.Disconnect();
            NotifiLib.SendNotification("YOU HAVE BEEN DISCONNECTED");
        }
        else
        {
            NotifiLib.SendNotification("<color=white> NOT IN A ROOM!</color>");
        }
    }
    public static void ConnectToRegion(string d)
    {
        PhotonNetwork.ConnectToRegion(d);
    }
    public static float TagChanger = 6f;
    public static GameObject PltformL;
    public static bool PltformLEnabled = false;
    public static GameObject PlatformR;
    public static bool PlatformREnabled = false;
    public bool PlatL = false;
    public bool PlatR = false;
    private static Color startColor = SettingsforMenu.MenuColor;
    private static Color endColor = SettingsforMenu.buttonColorsOff;
    private static float DurationShit = 3f;
    private static float TimeShit = 0.0f;
    private static ControllerInputPoller input;
    public static Vector3[] lastLeft = new Vector3[10]
    {
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero
    };
    public static Vector3[] lastRight = new Vector3[10]
    {
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero
    };


    public static void DisableNetworkTriggers()
    {
        GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab").SetActive(false);
    }

    public static void EnabledNetworkTriggers()
    {
        GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab").SetActive(true);
    }
    public static void SplashR()
    {
        if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.0f)
        {
            GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlaySplashEffect", RpcTarget.All,
                GorillaTagger.Instance.rightHandTransform.position,
                GorillaTagger.Instance.rightHandTransform.rotation,
                4f,
                100f,
                true,
                false
            );
        }
    }


    public static void SplashL()
    {
        if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.0f)
        {
            GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlaySplashEffect", RpcTarget.All,
                GorillaTagger.Instance.leftHandTransform.position,
                GorillaTagger.Instance.leftHandTransform.rotation,
                4f,
                100f,
                true,
                false
            );
        }
    }

    private static bool CanUse = true;
    public static void SplashAura()
    {
        if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.0)
        {
            if (CanUse)
            {
                CanUse = false;
                float x = UnityEngine.Random.Range(-1f, 1f);
                float y = UnityEngine.Random.Range(-1f, 1f);
                float z = UnityEngine.Random.Range(-1f, 1f);

                GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlaySplashEffect", NetworkSystem.Instance.LocalPlayer, new object[] { GorillaTagger.Instance.transform.position + new Vector3(x, y, z), Quaternion.identity, 1f, 0.5f, true, false });
                DelayWater();
            }

        }
    }

    private static async void DelayWater()
    {
        await System.Threading.Tasks.Task.Delay(250);
        CanUse = true;
    }

    public static void SplashSelf()
    {
        if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.0f)
        {
            GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlaySplashEffect", RpcTarget.All,
                GorillaTagger.Instance.headCollider.transform.position,
                GorillaTagger.Instance.headCollider.transform.rotation,
                4f,
                100f,
                true,
                false
            );
        }
    } 

  

    public static void TagAll()
    {
        if (ControllerInputPoller.instance.rightGrab)
        {
            VRRig component = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.PlayerListOthers[UnityEngine.Random.Range(0, 10)]).gameObject.GetComponent<VRRig>();
            if (!component.mainSkin.material.name.Contains("fected"))
            {
                if (!GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected"))
                    return;

                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.transform.position = component.headMesh.transform.position + new Vector3(0.0f, 1f, 0.0f);
                GorillaLocomotion.Player.Instance.rightControllerTransform.position = component.headMesh.transform.position;
                GorillaLocomotion.Player.Instance.leftControllerTransform.position = component.headMesh.transform.position;
                GorillaTagger.Instance.offlineVRRig.rightHandTransform.position = component.headMesh.transform.position;
                GorillaTagger.Instance.offlineVRRig.leftHandTransform.position = component.headMesh.transform.position;
                SafetySettings.FlushRPCs();
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }
        else
        {
            GorillaTagger.Instance.offlineVRRig.enabled = true;
        }
    }

    public static void TagAura()
    {
        float Shit = 6f;
        VRRig vrRig = null;
        foreach (VRRig VRShit in GorillaParent.instance.vrrigs)
        {
            if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected") &&
                VRShit != GorillaTagger.Instance.offlineVRRig &&
                Vector3.Distance(GorillaTagger.Instance.bodyCollider.transform.position, VRShit.transform.position) < Shit &&
                !VRShit.mainSkin.material.name.Contains("fected"))
            {
                Shit = Vector3.Distance(GorillaTagger.Instance.bodyCollider.transform.position, VRShit.transform.position) * 4f;
                vrRig = VRShit;
            }
        }
        if (vrRig != null)
        {
            GorillaTagger.Instance.rightHandTransform.position = vrRig.transform.position;
        }
    }

    public static void UnTagAll()
    {
        if (PhotonNetwork.LocalPlayer != PhotonNetwork.MasterClient)
            return;

        foreach (GorillaTagManager GorillaTagShit in Object.FindObjectsOfType<GorillaTagManager>())
        {
            foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerList)
            {
                GorillaTagShit.currentInfected.Remove(player);
                GorillaTagShit.UpdateState();
            }
        }
    }
    public static void MatSpam()
    {
        float Delay1 = -1f;
        if (PhotonNetwork.LocalPlayer.IsMasterClient)
        {
            foreach (GorillaTagManager G in Object.FindObjectsOfType<GorillaTagManager>())
            {
                foreach (Photon.Realtime.Player P in PhotonNetwork.PlayerList)
                {
                    if (Time.time > Delay1 + 0.1f)
                    {
                        if (G.currentInfected.Contains(P))
                        {
                            G.currentInfected.Remove(P);
                            G.ClearInfectionState();
                            G.UpdateState();
                        }
                        if (!G.currentInfected.Contains(P))
                        {
                            G.currentInfected.Add(P);
                            G.AddInfectedPlayer(P);
                            G.IsInfected(P);
                            G.UpdateState();
                        }
                    }
                }
            }
        }
        else
        {
            Main.GetIndex("Mat Spam All [M]").enabled = false;
            NotifiLib.SendNotification("<color=white>ERROR! NOT MASTER CLIENT</color>");
            Main.RecreateMenu();
        }
    }



   
    public static void TagGun()
    {
        RaycastHit raycastHit;
        if (!ControllerInputPoller.instance.rightGrab ||
            !Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position,
                             -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit))
        {
            return;
        }
        if (GunLibShit.GunMain != null)
            Object.Destroy(GunLibShit.GunMain);
        if (GunLibShit.LineMain != null)
            Object.Destroy(GunLibShit.LineMain.gameObject);
        GunLibShit.GunMain = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        GunLibShit.GunMain.GetComponent<Renderer>().material.color = Color.blue;
        GunLibShit.GunMain.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
        GunLibShit.GunMain.transform.position = raycastHit.point;
        Object.Destroy(GunLibShit.GunMain.GetComponent<Collider>());
        Object.Destroy(GunLibShit.GunMain.GetComponent<Rigidbody>());
        GunLibShit.LineMain = new GameObject("Line").AddComponent<LineRenderer>();
        GunLibShit.LineMain.startColor = Color.blue;
        GunLibShit.LineMain.endColor = Color.blue;
        GunLibShit.LineMain.startWidth = 0.025f;
        GunLibShit.LineMain.endWidth = 0.025f;
        GunLibShit.LineMain.positionCount = 2;
        GunLibShit.LineMain.useWorldSpace = true;
        Transform handTransform = GorillaLocomotion.Player.Instance.rightControllerTransform;
        GunLibShit.LineMain.SetPosition(0, handTransform.position);
        GunLibShit.LineMain.SetPosition(1, raycastHit.point);
        Material lineMaterial = new Material(Shader.Find("GUI/Text Shader"));
        lineMaterial.color = Color.blue;
        GunLibShit.LineMain.material = lineMaterial;
        if (ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.0f && GunLibShit.GunMain != null)
        {
            VRRig hitVRRig = raycastHit.collider?.GetComponentInParent<VRRig>();
            if (hitVRRig != null)
            {
                if (!PhotonNetwork.IsMasterClient)
                {
                    GorillaLocomotion.Player.Instance.rightControllerTransform.position = hitVRRig.transform.position;
                    GorillaTagger.Instance.offlineVRRig.enabled = false;
                    GorillaTagger.Instance.offlineVRRig.transform.position = hitVRRig.transform.position;
                }
                else
                {
                    GameObject.Find("Gorilla Tag Manager").GetComponent<GorillaTagManager>().AddInfectedPlayer(hitVRRig.Creator);
                }

                GunLibShit.GunPointerShit = true;
            }
        }
        else
        {
            GunLibShit.GunPointerShit = false;
            GorillaTagger.Instance.offlineVRRig.enabled = true;
        }
            Player.Instance.StartCoroutine(DestroyAfterDelay());
    }




    public static void PunchMod()
    {
        int index = -1;
        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
        {
            if (vrrig != GorillaTagger.Instance.offlineVRRig)
            {
                ++index;
                Vector3 position1 = vrrig.rightHandTransform.position;
                Vector3 position2 = GorillaTagger.Instance.offlineVRRig.head.rigTarget.position;
                if (Vector3.Distance(position1, position2) < 0.25f)
                {
                    Rigidbody component = GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>();
                    component.velocity += Vector3.Normalize(vrrig.rightHandTransform.position - lastRight[index]) * 10f;
                }
                lastRight[index] = vrrig.rightHandTransform.position;
                if (Vector3.Distance(vrrig.leftHandTransform.position, position2) < 0.25f)
                {
                    Rigidbody component = GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>();
                    component.velocity += Vector3.Normalize(vrrig.leftHandTransform.position - lastLeft[index]) * 10f;
                }
                lastLeft[index] = vrrig.leftHandTransform.position;
            }
        }
    }

    public static void TpToStump()
    {
        input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
        if (!GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom").activeSelf)
            return;
        if (ControllerInputPoller.instance.rightControllerPrimaryButton)
        {
            foreach (Collider collider in Resources.FindObjectsOfTypeAll<MeshCollider>())
                collider.enabled = false;
            GorillaLocomotion.Player.Instance.transform.position = new Vector3(-66.4848f, 11.8871f, -82.6619f);
        }
        else
        {
            foreach (Collider collider in Resources.FindObjectsOfTypeAll<MeshCollider>())
                collider.enabled = true;
        }
    }

    public static void ZeroGravity()
    {
        GorillaLocomotion.Player.Instance.bodyCollider.attachedRigidbody.AddForce(Vector3.up * (9.81f), ForceMode.Acceleration);
    }


    public static void CarMonke()
    {
        if (ControllerInputPoller.instance.rightControllerIndexFloat >= 0.3)
        {
            Transform transform = GorillaLocomotion.Player.Instance.transform;
            transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * 5f;
        }
        if (!ControllerInputPoller.instance.rightGrab)
            return;
        Transform transform1 = GorillaLocomotion.Player.Instance.transform;
        transform1.position -= GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * 3f;
    }

    public static void TPGun()
    {
        RaycastHit raycastHit;
        if (!ControllerInputPoller.instance.rightGrab ||
            !Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position,
                             -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit))
        {
            return;
        }
        if (GunLibShit.GunMain != null)
            Object.Destroy(GunLibShit.GunMain);
        if (GunLibShit.LineMain != null)
            Object.Destroy(GunLibShit.LineMain.gameObject);
        GunLibShit.GunMain = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        GunLibShit.GunMain.GetComponent<Renderer>().material.color = Color.blue;
        GunLibShit.GunMain.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
        GunLibShit.GunMain.transform.position = raycastHit.point;
        Object.Destroy(GunLibShit.GunMain.GetComponent<Collider>());
        Object.Destroy(GunLibShit.GunMain.GetComponent<Rigidbody>());
        GunLibShit.LineMain = new GameObject("Line").AddComponent<LineRenderer>();
        GunLibShit.LineMain.startColor = Color.blue;
        GunLibShit.LineMain.endColor = Color.blue;
        GunLibShit.LineMain.startWidth = 0.025f;
        GunLibShit.LineMain.endWidth = 0.025f;
        GunLibShit.LineMain.positionCount = 2;
        GunLibShit.LineMain.useWorldSpace = true;
        Transform handTransform = GorillaLocomotion.Player.Instance.rightControllerTransform;
        GunLibShit.LineMain.SetPosition(0, handTransform.position);
        GunLibShit.LineMain.SetPosition(1, raycastHit.point);
        Material lineMaterial = new Material(Shader.Find("GUI/Text Shader"));
        lineMaterial.color = Color.blue;
        GunLibShit.LineMain.material = lineMaterial;
        if (ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.5f && Time.time > Delay)
        {
            Delay = Time.time + 0.55f;
            GorillaLocomotion.Player.Instance.transform.position = GunLibShit.GunMain.transform.position;
            GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
        }
        if (raycastHit.collider != null && raycastHit.collider.GetComponentInParent<VRRig>() != null)
        {
            GunLibShit.GunShitLock = raycastHit.collider.GetComponentInParent<VRRig>();
        }
        Player.Instance.StartCoroutine(DestroyAfterDelay());
    }

    private static IEnumerator DestroyAfterDelay()
    {
        yield return new WaitForSeconds(0.5f);
        if (GunLibShit.GunMain != null)
            Object.Destroy(GunLibShit.GunMain);
        if (GunLibShit.LineMain != null)
            Object.Destroy(GunLibShit.LineMain.gameObject);
    }
    static bool sendonce = true;
    public static void UnlockComp() => GorillaComputer.instance.CompQueueUnlockButtonPress();
    public static void RoomFullNotification()
    {
        if (GorillaComputer.instance.roomFull == true)
        {
            if (sendonce)
            {
                NotifiLib.SendNotification("<color=white>ERROR! ROOM FULL</color>");
                sendonce = false;
            }
        }
        else if (GorillaComputer.instance.roomFull == false || PhotonNetwork.InRoom)
        {
            if (!sendonce)
            {
                sendonce = true;
            }
        }
    }
    public static void RemoveAllTrees()
    {
        if (ControllerInputPoller.instance.rightGrab)
        {
            GameObject.Find("Environment Objects/LocalObjects_Prefab/Forest/Terrain/SmallTrees/").SetActive(false);
        }
        else
        {
            GameObject.Find("Environment Objects/LocalObjects_Prefab/Forest/Terrain/SmallTrees/").SetActive(true);
        }
    }
    public static void GetOwnId()
    {
        if (!Directory.Exists("TGSGhostt"))
        {
            Directory.CreateDirectory("TGSGhostt");
        }
        if (!Directory.Exists("TGSGhostt/PlayerIDs"))
        {
            Directory.CreateDirectory("TGSGhostt/PlayerIDs");
        }
        if (!File.Exists("TGSGhostt/PlayerIDs/OwnPlayerId.txt"))
        {
            File.CreateText("TGSGhostt/PlayerIDs/OwnPlayerId.txt");
        }
        if (!File.ReadAllText("TGSGhostt/PlayerIDs/OwnPlayerId.txt").Contains(PhotonNetwork.LocalPlayer.UserId))
        {
            File.WriteAllText("TGSGhostt/PlayerIDs/OwnPlayerId.txt", PhotonNetwork.LocalPlayer.UserId);
        }
        else if (File.ReadAllText("TGSGhostt/PlayerIDs/OwnPlayerId.txt").Contains(PhotonNetwork.LocalPlayer.UserId))
        {
            NotifiLib.SendNotification("<color=white>ERROR! ALREADY GRABBED OWN ID</color>");
        }
    }
    public static void GetIDGun()
    {
        RaycastHit raycastHit;

        if (!ControllerInputPoller.instance.rightGrab ||
            !Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position,
                             -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit))
        {
            return;
        }
        if (GunLibShit.GunMain != null)
        {
            Object.Destroy(GunLibShit.GunMain);
            GunLibShit.GunMain = null;
        }
        if (GunLibShit.LineMain != null)
        {
            Object.Destroy(GunLibShit.LineMain.gameObject);
            GunLibShit.LineMain = null;
        }
        GunLibShit.GunMain = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        GunLibShit.GunMain.GetComponent<Renderer>().material.color = Color.blue;
        GunLibShit.GunMain.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
        GunLibShit.GunMain.transform.position = raycastHit.point;
        Object.Destroy(GunLibShit.GunMain.GetComponent<Collider>());
        Object.Destroy(GunLibShit.GunMain.GetComponent<Rigidbody>());
        GunLibShit.LineMain = new GameObject("Line").AddComponent<LineRenderer>();
        GunLibShit.LineMain.startColor = Color.blue;
        GunLibShit.LineMain.endColor = Color.blue;
        GunLibShit.LineMain.startWidth = 0.025f;
        GunLibShit.LineMain.endWidth = 0.025f;
        GunLibShit.LineMain.positionCount = 2;
        GunLibShit.LineMain.useWorldSpace = true;

        Transform handTransform = GorillaLocomotion.Player.Instance.rightControllerTransform;
        GunLibShit.LineMain.SetPosition(0, handTransform.position);
        GunLibShit.LineMain.SetPosition(1, raycastHit.point);
        Material lineMaterial = new Material(Shader.Find("GUI/Text Shader"));
        lineMaterial.color = Color.blue;
        GunLibShit.LineMain.material = lineMaterial;
        if (ControllerInputPoller.TriggerFloat(XRNode.RightHand) <= 0.0f || GunLibShit.GunPointerShit)
        {
            return;
        }
        VRRig componentInParent = raycastHit.collider?.GetComponentInParent<VRRig>();
        if (componentInParent != null)
        {

            if (PhotonNetwork.InRoom)
            {
                string dirPath = "TGSGhostt/PlayerIDs";
                if (!Directory.Exists(dirPath))
                {
                    Directory.CreateDirectory(dirPath);
                }

                string filePath = $"{dirPath}/{PhotonNetwork.CurrentRoom.Name} PlayerID {RigManager.GetPlayerFromVRRig(componentInParent).NickName}.txt";
                string playerId = RigManager.GetPlayerFromVRRig(componentInParent).UserId;

                if (!File.Exists(filePath) || !File.ReadAllText(filePath).Contains(playerId))
                {
                    File.WriteAllText(filePath, playerId);;
                    NotifiLib.SendNotification($"{RigManager.GetPlayerFromVRRig(componentInParent).NickName}<color=white> PLAYER ID: </color>{playerId}");
                }
                else
                {
                    NotifiLib.SendNotification($"<color=white>ERROR! ALREADY GRABBED </color>{RigManager.GetPlayerFromVRRig(componentInParent).NickName}<color=purple> PLAYER ID IN TEXT FILE</color>");
                }
            }
            else
            {
                NotifiLib.SendNotification("<color=white>ERROR! NOT IN ROOM.</color>");
            }
            GunLibShit.GunPointerShit = true;
        }
        else
        {
            GunLibShit.GunPointerShit = false;
        }
        Player.Instance.StartCoroutine(DestroyAfterDelay());
    }





    public static void GetAllIDs()
    {
        if (!Directory.Exists("TGSGhostt/PlayerIDs"))
        {
            Directory.CreateDirectory("TGSGhostt/PlayerIDs");
        }
        string contents = "";
        foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerList)
            contents += "Player Name: " + player.NickName + " Player ID: " + player.UserId + "\n";
        File.WriteAllText("TGSGhostt/PlayerIDs/" + PhotonNetwork.CurrentRoom.Name+"IDS.txt", contents);
    }

    public static void TagSelf()
    {
        if (!PhotonNetwork.LocalPlayer.IsMasterClient)
        {
            foreach (GorillaTagManager gorillaTagManager in Object.FindObjectsOfType<GorillaTagManager>())
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig.mainSkin.material.name.Contains("fected"))
                    {
                        if (!gorillaTagManager.currentInfected.Contains(PhotonNetwork.LocalPlayer))
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.rightHandTransform.position;
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                }
            }
        }
        else
        {
            foreach (GorillaTagManager gorillaTagManager in Object.FindObjectsOfType<GorillaTagManager>())
            {
                gorillaTagManager.currentInfected.Add(PhotonNetwork.LocalPlayer);
                Main.GetIndex("Tag Self").enabled = false;
            }
        }
    }


    public static void Platforms()
    {
        if (ControllerInputPoller.instance.leftGrab)
        {
            if (!PltformLEnabled)
            {
                PltformL = GameObject.CreatePrimitive(PrimitiveType.Cube);
                PltformL.GetComponent<Renderer>().material.color = Color.Lerp(startColor, endColor, TimeShit / DurationShit);
                PltformL.transform.localScale = new Vector3(0.28f, 0.015f, 0.38f);
                PltformL.transform.position = Player.Instance.leftControllerTransform.position + new Vector3(0.0f, -0.02f, 0.0f);
                PltformL.transform.rotation = Player.Instance.leftControllerTransform.rotation * Quaternion.Euler(0.0f, 0.0f, -90f);
                PltformLEnabled = true;
            }

            if (TimeShit < DurationShit)
            {
                PltformL.GetComponent<Renderer>().material.color = Color.Lerp(startColor, endColor, TimeShit / DurationShit);
                TimeShit += Time.deltaTime;
                if (TimeShit >= DurationShit)
                    TimeShit = 0.0f;
            }
        }
        else if (PltformLEnabled)
        {
            Object.Destroy(PltformL);
            PltformLEnabled = false;
        }

        if (ControllerInputPoller.instance.rightGrab)
        {
            if (!PlatformREnabled)
            {
                PlatformR = GameObject.CreatePrimitive(PrimitiveType.Cube);
                PlatformR.GetComponent<Renderer>().material.color = Color.Lerp(startColor, endColor, TimeShit / DurationShit);
                PlatformR.transform.localScale = new Vector3(0.28f, 0.015f, 0.38f);
                PlatformR.transform.position = Player.Instance.rightControllerTransform.position + new Vector3(0.0f, -0.02f, 0.0f);
                PlatformR.transform.rotation = Player.Instance.rightControllerTransform.rotation * Quaternion.Euler(0.0f, 0.0f, -90f);
                PlatformREnabled = true;
            }

            if (TimeShit < DurationShit)
            {
                PlatformR.GetComponent<Renderer>().material.color = Color.Lerp(startColor, endColor, TimeShit / DurationShit);
                TimeShit += Time.deltaTime;
                if (TimeShit >= DurationShit)
                    TimeShit = 0.0f;
            }
        }
        else if (PlatformREnabled)
        {
            Object.Destroy(PlatformR);
            PlatformREnabled = false;
        }

        if (!ControllerInputPoller.instance.leftGrab)
            Object.Destroy(PltformL);

        if (!ControllerInputPoller.instance.rightGrab)
            Object.Destroy(PlatformR);
    }

    public static void SolidWater()
    {
        foreach (WaterVolume WaterShit in Object.FindObjectsOfType<WaterVolume>())
        {
            GameObject v = WaterShit.gameObject;
            v.layer = LayerMask.NameToLayer("Default");
        }
    }

    public static void UnSolidWater()
    {
        foreach (WaterVolume WaterShit in Object.FindObjectsOfType<WaterVolume>())
        {
            GameObject v = WaterShit.gameObject;
            v.layer = LayerMask.NameToLayer("Water");
        }
    }

    public static void SuperSwim()
    {
        if (Player.Instance.InWater)
        {
            Player.Instance.gameObject.GetComponent<Rigidbody>().velocity *= 2f;
        }
    }

    public static void BubblesSpam()
    {
        GameObject bubbles = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer/TurnParent/Main Camera/UnderwaterVisualEffects/UnderwaterParticleEffects/UnderwaterBubbles");
        if (ControllerInputPoller.instance.rightGrab)
        {
            for (int i = 0; i < 5; i++)
            {
                GameObject newBubble = GameObject.Instantiate(bubbles);
                newBubble.SetActive(true);
                newBubble.transform.localScale = new Vector3(1f, 1f, 1f);

                newBubble.transform.position = GorillaLocomotion.Player.Instance.rightControllerTransform.position;

                GameObject.Destroy(newBubble, 2f);
            }
        }
    }

    public static void OldRamp()
    {
        GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/tree/stubbranch").SetActive(true);
    }

    public static void FixOldRamp()
    {
        GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/tree/stubbranch").SetActive(false);
    }

    public static void DivingBoardSpeed()
    {
        GameObject.Find("Beach/Beach_Gameplay_V6/B_Divingboard_1/DivingBoard_board").GetComponent<GorillaSurfaceOverride>().extraVelMaxMultiplier = 50f;
        GameObject.Find("Beach/Beach_Gameplay_V6/B_Divingboard_1/DivingBoard_board").GetComponent<GorillaSurfaceOverride>().extraVelMultiplier = 50f;
    }

    public static void FasterTurnSpeed()
    {
        foreach (GorillaSnapTurn gorillaSnapTurn in (GorillaSnapTurn[])Object.FindObjectsOfType(typeof(GorillaSnapTurn)))
        {
            gorillaSnapTurn.ChangeTurnMode("SMOOTH", 275);
            gorillaSnapTurn.turnAmount = 275f;
        }
    }

    public static void FixTurnSpeed()
    {
        foreach (GorillaSnapTurn gorillaSnapTurn in Object.FindObjectsOfType<GorillaSnapTurn>())
        {
            gorillaSnapTurn.ChangeTurnMode("SMOOTH", 5);
            gorillaSnapTurn.turnAmount = 5f;
        }
    }

    public static void InfShinyRocks()
    {
        CosmeticsController.instance.numShinyRocksToBuy = 9999999;
        CosmeticsController.instance.numShinyRocksToBuy = 9999999;
        CosmeticsController.instance.currencyBalance = 9999999;
    }

    public static void LaunchRocket()
    {
        GameObject.Find("Environment Objects/05Maze_PersistentObjects/RocketShip_Prefab").GetComponent<ScheduledTimelinePlayer>().timeline.Stop();
        GameObject.Find("Environment Objects/05Maze_PersistentObjects/RocketShip_Prefab").GetComponent<ScheduledTimelinePlayer>().timeline.Play();
    }

    public static void IllustratorBadge()
    {
        GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/LBAGS.").SetActive(true);
    }

    public static void DisableIllustratorBadge()
    {
        GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/LBAGS.").SetActive(false);
    }

    public static GameObject Plat { get; private set; }

  public static float Delay { get; private set; }
}
