﻿using GorillaNetworking;
using Photon.Pun;
using Photon.Realtime;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using TGSGhostt.Menu;
using UnityEngine;
using UnityEngine.XR;
using TGSGhosttSettings;
using TGSGhostt.Mods;
using Object = UnityEngine.Object;
using Player = GorillaLocomotion.Player;
using TGSGhostt.Classes;
using Fusion.StatsInternal;
using PlayFab.ProfilesModels;
using HarmonyLib;
using TGSGhostts_Menu.Mods;
using TGSGhostt.Notifications;
using Photon.Pun;
using static TGSGhostts_Menu.Classes.GunLib;
using TGSGhostts_Menu.Classes;
using GorillaLocomotion.Swimming;

internal class FunMods
{
    public static void Disconnect()
    {
        if (PhotonNetwork.InRoom)
        {
            PhotonNetwork.Disconnect();
        }
        else
        {
             NotifiLib.SendNotification("<color=white> NOT IN A ROOM!</color>");
        }
    }
    public static void ConnectToRegion(string d)
    {
        PhotonNetwork.ConnectToRegion(d);
    }
  public static float TagChanger = 6f;
  public static GameObject PltformL;
  public static bool PltformLEnabled = false;
  public static GameObject PlatformR;
  public static bool PlatformREnabled = false;
  public bool PlatL = false;
  public bool PlatR = false;
  private static Color startColor = SettingsforMenu.MenuColor;
  private static Color endColor = SettingsforMenu.buttonColorsOff;   
  private static float DurationShit = 3f;  
  private static float TimeShit = 0.0f;
  private static ControllerInputPoller input;
  public static Vector3[] lastLeft = new Vector3[10]
  {
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero
  };
  public static Vector3[] lastRight = new Vector3[10]
  {
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero,
    Vector3.zero
  };


  public static void DisableNetworkTriggers()
  {
    GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab").SetActive(false);
  }

  public static void EnabledNetworkTriggers()
  {
    GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab").SetActive(true);
  }
    public static void SplashR()
    {
        if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.0f)
        {
            GorillaTagger.Instance.myVRRig.RPC("PlaySplashEffect", RpcTarget.All,
                GorillaTagger.Instance.rightHandTransform.position,
                GorillaTagger.Instance.rightHandTransform.rotation,
                4f,
                100f,
                true,
                false
            );
        }
    }


    public static void SplashL()
    {
        if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.0f)
        {
            GorillaTagger.Instance.myVRRig.RPC("PlaySplashEffect", RpcTarget.All,
                GorillaTagger.Instance.leftHandTransform.position,
                GorillaTagger.Instance.leftHandTransform.rotation,
                4f,
                100f,
                true,
                false
            );
        }
    }


    public static void SplashAura()
    {
       if (ControllerInputPoller.instance.rightControllerIndexFloat <= 0.0)
       {
         foreach (VRRig RigShit in GorillaParent.instance.vrrigs)
         {
           Vector3 Pos = (RigShit).transform.position;
           Quaternion Rotate = (RigShit).transform.rotation;
           PhotonView.Get(GorillaTagger.Instance.myVRRig).RPC("PlaySplashEffect", (RpcTarget)0, new object[6]
           {
            Pos,
            Rotate,
            125f,
            125f,
            true,
            true
           });
         }
       } 
    }



    public static void WaterSelf()
  {
      if (ControllerInputPoller.instance.rightControllerIndexFloat <= 0.0)
      return;
      GorillaTagger.Instance.myVRRig.RPC("PlaySplashEffect", (RpcTarget) 0, new object[6]
      {
          (GorillaTagger.Instance.offlineVRRig).transform.position,
          (GorillaTagger.Instance.offlineVRRig).transform.rotation,
          4f,
          100f,
          true,
          false
    });
  }

    public static void VibrateAll()
    {
        if (PhotonNetwork.LocalPlayer == PhotonNetwork.MasterClient)
        {
            Vector3 Pos = GorillaTagger.Instance.transform.position;
            Photon.Realtime.Player[] PlayerShit = PhotonNetwork.PlayerList;
            Photon.Realtime.Player PlayerShit2 = PhotonNetwork.LocalPlayer;
            GorillaGameManager instance = GorillaGameManager.instance;
            foreach(Photon.Realtime.Player player in PlayerShit)
            {
                PhotonView VRRigPlayerShit = instance.FindVRRigForPlayer(player);
                if (VRRigPlayerShit != null)
                {
                    VRRigPlayerShit.RPC("SetJoinTaggedTime", RpcTarget.All, Array.Empty<object>());
                }
            }
        }
        else
        {
            NotifiLib.SendNotification("<color=grey>[</color><color=red>Menu</color><color=grey>]</color> <color=white>You are not master.</color>");
        }
    }

    public static void SlowAll()
    {
        if (!PhotonNetwork.IsMasterClient)
            return;

        GorillaTagger.Instance.myVRRig.RPC("SetTaggedTime", RpcTarget.All, null);
    }

    public static void TagAll()
    {
        if (ControllerInputPoller.instance.rightGrab)
        {
            VRRig component = GorillaGameManager.instance.FindPlayerVRRig(PhotonNetwork.PlayerListOthers[UnityEngine.Random.Range(0, 10)]).gameObject.GetComponent<VRRig>();
            if (!component.mainSkin.material.name.Contains("fected"))
            {
                if (!GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected"))
                    return;

                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.transform.position = component.headMesh.transform.position + new Vector3(0.0f, 1f, 0.0f);
                GorillaLocomotion.Player.Instance.rightControllerTransform.position = component.headMesh.transform.position;
                GorillaLocomotion.Player.Instance.leftControllerTransform.position = component.headMesh.transform.position;
                GorillaTagger.Instance.offlineVRRig.rightHandTransform.position = component.headMesh.transform.position;
                GorillaTagger.Instance.offlineVRRig.leftHandTransform.position = component.headMesh.transform.position;
                SafetySettings.FlushRPCs();
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }
        else
        {
            GorillaTagger.Instance.offlineVRRig.enabled = true;
        }
    }

    public static void TagAura()
    {
        float Shit = 6f;
        VRRig vrRig = null;
        foreach (VRRig VRShit in GorillaParent.instance.vrrigs)
        {
            if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected") &&
                VRShit != GorillaTagger.Instance.offlineVRRig &&
                Vector3.Distance(GorillaTagger.Instance.bodyCollider.transform.position, VRShit.transform.position) < Shit &&
                !VRShit.mainSkin.material.name.Contains("fected"))
            {
                Shit = Vector3.Distance(GorillaTagger.Instance.bodyCollider.transform.position, VRShit.transform.position) * 4f;
                vrRig = VRShit;
            }
        }
        if (vrRig != null)
        {
            GorillaTagger.Instance.rightHandTransform.position = vrRig.transform.position;
        }
    }

    public static void UnTagAll()
    {
        if (PhotonNetwork.LocalPlayer != PhotonNetwork.MasterClient)
            return;

        foreach (GorillaTagManager GorillaTagShit in Object.FindObjectsOfType<GorillaTagManager>())
        {
            foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerList)
            {
                GorillaTagShit.currentInfected.Remove(player);
                GorillaTagShit.UpdateState();
            }
        }
    }
    public static void MatSpam()
    {
        float Delay1 = -1f;
        if (PhotonNetwork.LocalPlayer.IsMasterClient)
        {
            foreach (GorillaTagManager G in Object.FindObjectsOfType<GorillaTagManager>())
            {
                foreach (Photon.Realtime.Player P in PhotonNetwork.PlayerList)
                {
                    if (Time.time > Delay1 + 0.1f)
                    {
                        if (G.currentInfected.Contains(P))
                        {
                            G.currentInfected.Remove(P);
                            G.ClearInfectionState();
                            G.UpdateState();
                        }
                        if (!G.currentInfected.Contains(P))
                        {
                            G.currentInfected.Add(P);
                            G.AddInfectedPlayer(P);
                            G.IsInfected(P);
                            G.UpdateState();
                        }
                    }
                }
            }
        }
        else
        {
            Main.GetIndex("Mat Spam All [M]").enabled = false;
            NotifiLib.SendNotification("<color=white>ERROR! NOT MASTER CLIENT</color>");
            Main.RecreateMenu();
        }
    }
    public static void MatSpamGun()
    {
        RaycastHit raycastHit;
        if (!ControllerInputPoller.instance.rightGrab ||
            !Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up,
                             -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit))
        {
            return;
        }
        if (GunLibShit.GunMain != null)
            GunLibShit.DestroyObject(GunLibShit.GunMain);

        if (GunLibShit.LineMain != null)
            GunLibShit.DestroyObject(GunLibShit.LineMain.gameObject);
        GunLibShit.GunMain = GunLibShit.CreateGun(raycastHit.point, Color.blue, 0.1f);
        GunLibShit.LineMain = GunLibShit.CreateLine(
            GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R").transform.position,
            raycastHit.point,
            Color.blue,
            0.025f
        );

        GunLibShit.LineMain.material.shader = Shader.Find("GUI/Text Shader");

        if (ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.0f)
        {
            if (GunLibShit.GunMain == null)
            {
                GunLibShit.GunMain = GunLibShit.CreateGun(raycastHit.point, Color.blue, 0.2f);
                GunLibShit.GunMain.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
            }

            GunLibShit.GunMain.transform.position = raycastHit.point;
            GameObject tempLine = new GameObject("TempLine");
            LineRenderer tempLineRenderer = tempLine.AddComponent<LineRenderer>();
            tempLineRenderer.startColor = Color.blue;
            tempLineRenderer.endColor = Color.blue;
            tempLineRenderer.startWidth = 0.025f;
            tempLineRenderer.endWidth = 0.025f;
            tempLineRenderer.positionCount = 2;
            tempLineRenderer.useWorldSpace = true;
            tempLineRenderer.SetPosition(0, GorillaLocomotion.Player.Instance.rightControllerTransform.position);
            tempLineRenderer.SetPosition(1, raycastHit.point);
            tempLineRenderer.material.shader = Shader.Find("GorillaTag/UberShader");
            Object.Destroy(tempLine, 0.1f);

            if (!GunLibShit.GunPointerShit)
            {
                if (PhotonNetwork.LocalPlayer.IsMasterClient)
                {
                    GunLibShit.GunMain.GetComponent<Renderer>().material.color = Color.blue;
                    VRRig componentInParent = raycastHit.collider?.GetComponentInParent<VRRig>();
                    if (componentInParent != null)
                    {
                        foreach (GorillaTagManager v in Object.FindObjectsOfType<GorillaTagManager>())
                        {
                            if (Time.time > -1f + 0.1f)
                            {
                                var player = RigManager.GetPlayerFromVRRig(componentInParent);
                                if (!v.currentInfected.Contains(player))
                                {
                                    v.currentInfected.Add(player);
                                    v.AddInfectedPlayer(player);
                                    v.IsInfected(player);
                                    v.UpdateState();
                                    v.FindPlayerVRRig(player);
                                }
                                else
                                {
                                    v.currentInfected.Remove(player);
                                    v.ClearInfectionState();
                                    v.InfectionEnd();
                                    v.UpdateState();
                                }
                            }
                        }
                    }
                }
                else
                {
                    Main.GetIndex("Mat Spam Gun [M]").enabled = false;
                    Main.RecreateMenu();
                    NotifiLib.SendNotification("<color=white>ERROR! NOT MASTER CLIENT</color>");
                }
                GunLibShit.GunPointerShit = true;
            }
        }
        else
        {
            if (GunLibShit.GunMain != null)
            {
                GunLibShit.GunMain.GetComponent<Renderer>().material.color = Color.blue;
            }
            GunLibShit.GunPointerShit = false;
            GorillaTagger.Instance.offlineVRRig.enabled = true;
        }
        GorillaLocomotion.Player.Instance.StartCoroutine(GunLibShit.DestroyAfterDelay(GunLibShit.GunMain, 5f));
    }



    public static void TagGun()
    {
        RaycastHit raycastHit;
        if (!ControllerInputPoller.instance.rightGrab || !Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up,
                             -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit))
        {
            return;
        }

        if (GunLibShit.GunMain != null)
            Object.Destroy(GunLibShit.GunMain);
        if (GunLibShit.LineMain != null)
            Object.Destroy(GunLibShit.LineMain.gameObject);
        GunLibShit.GunMain = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        GunLibShit.GunMain.GetComponent<Renderer>().material.color = Color.blue;
        GunLibShit.GunMain.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
        GunLibShit.GunMain.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
        GunLibShit.GunMain.transform.position = raycastHit.point;
        Object.Destroy(GunLibShit.GunMain.GetComponent<BoxCollider>());
        Object.Destroy(GunLibShit.GunMain.GetComponent<Rigidbody>());
        Object.Destroy(GunLibShit.GunMain.GetComponent<Collider>());
        GunLibShit.LineMain = new GameObject("Line").AddComponent<LineRenderer>();
        GunLibShit.LineMain.startColor = Color.blue;
        GunLibShit.LineMain.endColor = Color.blue;
        GunLibShit.LineMain.startWidth = 0.025f;
        GunLibShit.LineMain.endWidth = 0.025f;
        GunLibShit.LineMain.positionCount = 2;
        GunLibShit.LineMain.useWorldSpace = true;
        GunLibShit.LineMain.SetPosition(0, GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R").transform.position);
        GunLibShit.LineMain.SetPosition(1, raycastHit.point);
        GunLibShit.LineMain.material.shader = Shader.Find("GUI/Text Shader");


        if (ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.0f && GunLibShit.GunMain != null)
        {
            GunLibShit.GunMain.GetComponent<Renderer>().material.color = Color.blue;

            VRRig componentInParent = raycastHit.collider?.GetComponentInParent<VRRig>();
            if (componentInParent != null)
            {
                if (!PhotonNetwork.IsMasterClient)
                {
                    GorillaLocomotion.Player.Instance.rightControllerTransform.position = componentInParent.transform.position;
                    GorillaTagger.Instance.offlineVRRig.enabled = false;
                    GorillaTagger.Instance.offlineVRRig.transform.position = componentInParent.transform.position;
                }
                else
                {
                    GameObject.Find("Gorilla Tag Manager").GetComponent<GorillaTagManager>().AddInfectedPlayer(componentInParent.Creator);
                }
                GunLibShit.GunPointerShit = true;
            }
        }
        else
        {
            GunLibShit.GunPointerShit = false;
            GorillaTagger.Instance.offlineVRRig.enabled = true;
        }
        GorillaLocomotion.Player.Instance.StartCoroutine(DestroyAfterDelay());
    }



    public static void PunchMod()
    {
        int index = -1;
        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
        {
            if (vrrig != GorillaTagger.Instance.offlineVRRig)
            {
                ++index;
                Vector3 position1 = vrrig.rightHandTransform.position;
                Vector3 position2 = GorillaTagger.Instance.offlineVRRig.head.rigTarget.position;
                if (Vector3.Distance(position1, position2) < 0.25f)
                {
                    Rigidbody component = GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>();
                    component.velocity += Vector3.Normalize(vrrig.rightHandTransform.position - lastRight[index]) * 10f;
                }
                lastRight[index] = vrrig.rightHandTransform.position;
                if (Vector3.Distance(vrrig.leftHandTransform.position, position2) < 0.25f)
                {
                    Rigidbody component = GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>();
                    component.velocity += Vector3.Normalize(vrrig.leftHandTransform.position - lastLeft[index]) * 10f;
                }
                lastLeft[index] = vrrig.leftHandTransform.position;
            }
        }
    }

    public static void TpToStump()
    {
        input = GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer").GetComponent<ControllerInputPoller>();
        if (!GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom").activeSelf)
            return;
        if (ControllerInputPoller.instance.rightControllerPrimaryButton)
        {
            foreach (Collider collider in Resources.FindObjectsOfTypeAll<MeshCollider>())
                collider.enabled = false;
            GorillaLocomotion.Player.Instance.transform.position = new Vector3(-66.4848f, 11.8871f, -82.6619f);
        }
        else
        {
            foreach (Collider collider in Resources.FindObjectsOfTypeAll<MeshCollider>())
                collider.enabled = true;
        }
    }

    public static void ZeroGravity()
    {
        GorillaLocomotion.Player.Instance.bodyCollider.attachedRigidbody.AddForce(Vector3.up * (9.81f), ForceMode.Acceleration);
    }


    public static void CarMonke()
    {
        if (ControllerInputPoller.instance.rightControllerIndexFloat >= 0.3)
        {
            Transform transform = GorillaLocomotion.Player.Instance.transform;
            transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * 5f;
        }
        if (!ControllerInputPoller.instance.rightGrab)
            return;
        Transform transform1 = GorillaLocomotion.Player.Instance.transform;
        transform1.position -= GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * 3f;
    }

    public static void TPGun()
    {
        RaycastHit raycastHit;
        if (!ControllerInputPoller.instance.rightGrab || !Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up,
                             -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit))
        {
            return;
        }

        if (GunLibShit.GunMain != null)
            Object.Destroy(GunLibShit.GunMain);
        if (GunLibShit.LineMain != null)
            Object.Destroy(GunLibShit.LineMain.gameObject);
        GunLibShit.GunMain = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        GunLibShit.GunMain.GetComponent<Renderer>().material.color = Color.blue;
        GunLibShit.GunMain.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
        GunLibShit.GunMain.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
        GunLibShit.GunMain.transform.position = raycastHit.point;
        Object.Destroy(GunLibShit.GunMain.GetComponent<BoxCollider>());
        Object.Destroy(GunLibShit.GunMain.GetComponent<Rigidbody>());
        Object.Destroy(GunLibShit.GunMain.GetComponent<Collider>());
        GunLibShit.LineMain = new GameObject("Line").AddComponent<LineRenderer>();
        GunLibShit.LineMain.startColor = Color.blue;
        GunLibShit.LineMain.endColor = Color.blue;
        GunLibShit.LineMain.startWidth = 0.025f;
        GunLibShit.LineMain.endWidth = 0.025f;
        GunLibShit.LineMain.positionCount = 2;
        GunLibShit.LineMain.useWorldSpace = true;
        GunLibShit.LineMain.SetPosition(0, GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R").transform.position);
        GunLibShit.LineMain.SetPosition(1, raycastHit.point);
        GunLibShit.LineMain.material.shader = Shader.Find("GUI/Text Shader");
        if (ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.5f && Time.time > Delay)
        {
            Delay = Time.time + 0.55f;
            GorillaLocomotion.Player.Instance.transform.position = GunLibShit.GunMain.transform.position;
            GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
        }
        if (raycastHit.collider != null && raycastHit.collider.GetComponentInParent<VRRig>() != null)
        {
            GunLibShit.GunShitLock = raycastHit.collider.GetComponentInParent<VRRig>();
        }
        GorillaLocomotion.Player.Instance.StartCoroutine(DestroyAfterDelay());
    }

    private static IEnumerator DestroyAfterDelay()
    {
        yield return new WaitForSeconds(0.5f);
        if (GunLibShit.GunMain != null)
            Object.Destroy(GunLibShit.GunMain);
        if (GunLibShit.LineMain != null)
            Object.Destroy(GunLibShit.LineMain.gameObject);
    }
    static bool sendonce = true;
    public static void UnlockComp() => GorillaComputer.instance.CompQueueUnlockButtonPress();
    public static void RoomFullNotification()
    {
        if (GorillaComputer.instance.roomFull == true)
        {
            if (sendonce)
            {
                NotifiLib.SendNotification("<color=white>ERROR! ROOM FULL</color>");
                sendonce = false;
            }
        }
        else if (GorillaComputer.instance.roomFull == false || PhotonNetwork.InRoom)
        {
            if (!sendonce)
            {
                sendonce = true;
            }
        }
    }
    public static void RemoveAllTrees()
    {
        if (ControllerInputPoller.instance.rightGrab)
        {
            GameObject.Find("Environment Objects/LocalObjects_Prefab/Forest/Terrain/SmallTrees/").SetActive(false);
        }
        else
        {
            GameObject.Find("Environment Objects/LocalObjects_Prefab/Forest/Terrain/SmallTrees/").SetActive(true);
        }
    }
    public static void GetOwnId()
    {
        if (!Directory.Exists("TGSGhostt"))
        {
            Directory.CreateDirectory("TGSGhostt");
        }
        if (!Directory.Exists("TGSGhostt/PlayerIDs"))
        {
            Directory.CreateDirectory("TGSGhostt/PlayerIDs");
        }
        if (!File.Exists("TGSGhostt/PlayerIDs/OwnPlayerId.txt"))
        {
            File.CreateText("TGSGhostt/PlayerIDs/OwnPlayerId.txt");
        }
        if (!File.ReadAllText("TGSGhostt/PlayerIDs/OwnPlayerId.txt").Contains(PhotonNetwork.LocalPlayer.UserId))
        {
            File.WriteAllText("TGSGhostt/PlayerIDs/OwnPlayerId.txt", PhotonNetwork.LocalPlayer.UserId);
        }
        else if (File.ReadAllText("TGSGhostt/PlayerIDs/OwnPlayerId.txt").Contains(PhotonNetwork.LocalPlayer.UserId))
        {
            NotifiLib.SendNotification("<color=white>ERROR! ALREADY GRABBED OWN ID</color>");
        }
    }
    public static void GetIDGun()
    {
        RaycastHit raycastHit;
        if (!ControllerInputPoller.instance.rightGrab || !Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up,
                             -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit))
        {
            return;
        }

        if (GunLibShit.GunMain != null)
            Object.Destroy(GunLibShit.GunMain);
        if (GunLibShit.LineMain != null)
            Object.Destroy(GunLibShit.LineMain.gameObject);
        GunLibShit.GunMain = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        GunLibShit.GunMain.GetComponent<Renderer>().material.color = Color.blue;
        GunLibShit.GunMain.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
        GunLibShit.GunMain.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
        GunLibShit.GunMain.transform.position = raycastHit.point;
        Object.Destroy(GunLibShit.GunMain.GetComponent<BoxCollider>());
        Object.Destroy(GunLibShit.GunMain.GetComponent<Rigidbody>());
        Object.Destroy(GunLibShit.GunMain.GetComponent<Collider>());
        GunLibShit.LineMain = new GameObject("Line").AddComponent<LineRenderer>();
        GunLibShit.LineMain.startColor = Color.blue;
        GunLibShit.LineMain.endColor = Color.blue;
        GunLibShit.LineMain.startWidth = 0.025f;
        GunLibShit.LineMain.endWidth = 0.025f;
        GunLibShit.LineMain.positionCount = 2;
        GunLibShit.LineMain.useWorldSpace = true;
        GunLibShit.LineMain.SetPosition(0, GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R").transform.position);
        GunLibShit.LineMain.SetPosition(1, raycastHit.point);
        GunLibShit.LineMain.material.shader = Shader.Find("GUI/Text Shader");


        if (ControllerInputPoller.TriggerFloat(XRNode.RightHand) <= 0.0f || GunLibShit.GunPointerShit)
            return;
        VRRig componentInParent = raycastHit.collider?.GetComponentInParent<VRRig>();
        if (componentInParent != null)
        {
            if (PhotonNetwork.InRoom)
            {
                if (!Directory.Exists("TGSGhostt/PlayerIDs"))
                {
                    Directory.CreateDirectory("TGSGhostt/PlayerIDs");
                }
                string dirPath = "TGSGhostt/PlayerIDs";
                string filePath = $"{dirPath}/{PhotonNetwork.CurrentRoom.Name} PlayerID {RigManager.GetPlayerFromVRRig(componentInParent).NickName}.txt";
                string playerId = RigManager.GetPlayerFromVRRig(componentInParent).UserId;
                if (!Directory.Exists(dirPath))
                {
                    Directory.CreateDirectory(dirPath);
                }
                if (!File.Exists(filePath) || !File.ReadAllText(filePath).Contains(playerId))
                {
                    File.WriteAllText(filePath, playerId);
                  NotifiLib.SendNotification($"{RigManager.GetPlayerFromVRRig(componentInParent).NickName}<color=white> PLAYER ID: </color>{playerId}");
                }
                else
                {
                   NotifiLib.SendNotification($"<color=white>ERROR! ALREADY GRABBED </color>{RigManager.GetPlayerFromVRRig(componentInParent).NickName}<color=purple> PLAYER ID IN TEXT FILE</color>");
                }
            }
            else
            {
               NotifiLib.SendNotification("<color=white>ERROR! NOT IN ROOM.</color>");
            }
            GunLibShit.GunPointerShit = true;
        }
        else
        {
            GunLibShit.GunPointerShit = false;
        }
        GorillaLocomotion.Player.Instance.StartCoroutine(DestroyAfterDelay());
    }



    public static void GetAllIDs()
    {
        if (!Directory.Exists("TGSGhostt/PlayerIDs"))
        {
            Directory.CreateDirectory("TGSGhostt/PlayerIDs");
        }
        string contents = "";
        foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerList)
            contents += "Player Name: " + player.NickName + " Player ID: " + player.UserId + "\n";
        File.WriteAllText("TGSGhostt/PlayerIDs/" + PhotonNetwork.CurrentRoom.Name+"IDS.txt", contents);
    }

    public static void TagSelf()
    {
        if (!PhotonNetwork.LocalPlayer.IsMasterClient)
        {
            foreach (GorillaTagManager gorillaTagManager in Object.FindObjectsOfType<GorillaTagManager>())
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig.mainSkin.material.name.Contains("fected"))
                    {
                        if (!gorillaTagManager.currentInfected.Contains(PhotonNetwork.LocalPlayer))
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.rightHandTransform.position;
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                }
            }
        }
        else
        {
            foreach (GorillaTagManager gorillaTagManager in Object.FindObjectsOfType<GorillaTagManager>())
            {
                gorillaTagManager.currentInfected.Add(PhotonNetwork.LocalPlayer);
                Main.GetIndex("Tag Self").enabled = false;
            }
        }
    }


    public static void Platforms()
    {
        if (ControllerInputPoller.instance.leftGrab)
        {
            if (!PltformLEnabled)
            {
                PltformL = GameObject.CreatePrimitive(PrimitiveType.Cube);
                PltformL.GetComponent<Renderer>().material.color = Color.Lerp(startColor, endColor, TimeShit / DurationShit);
                PltformL.transform.localScale = new Vector3(0.28f, 0.015f, 0.38f);
                PltformL.transform.position = Player.Instance.leftControllerTransform.position + new Vector3(0.0f, -0.02f, 0.0f);
                PltformL.transform.rotation = Player.Instance.leftControllerTransform.rotation * Quaternion.Euler(0.0f, 0.0f, -90f);
                PltformLEnabled = true;
            }

            if (TimeShit < DurationShit)
            {
                PltformL.GetComponent<Renderer>().material.color = Color.Lerp(startColor, endColor, TimeShit / DurationShit);
                TimeShit += Time.deltaTime;
                if (TimeShit >= DurationShit)
                    TimeShit = 0.0f;
            }
        }
        else if (PltformLEnabled)
        {
            Object.Destroy(PltformL);
            PltformLEnabled = false;
        }

        if (ControllerInputPoller.instance.rightGrab)
        {
            if (!PlatformREnabled)
            {
                PlatformR = GameObject.CreatePrimitive(PrimitiveType.Cube);
                PlatformR.GetComponent<Renderer>().material.color = Color.Lerp(startColor, endColor, TimeShit / DurationShit);
                PlatformR.transform.localScale = new Vector3(0.28f, 0.015f, 0.38f);
                PlatformR.transform.position = Player.Instance.rightControllerTransform.position + new Vector3(0.0f, -0.02f, 0.0f);
                PlatformR.transform.rotation = Player.Instance.rightControllerTransform.rotation * Quaternion.Euler(0.0f, 0.0f, -90f);
                PlatformREnabled = true;
            }

            if (TimeShit < DurationShit)
            {
                PlatformR.GetComponent<Renderer>().material.color = Color.Lerp(startColor, endColor, TimeShit / DurationShit);
                TimeShit += Time.deltaTime;
                if (TimeShit >= DurationShit)
                    TimeShit = 0.0f;
            }
        }
        else if (PlatformREnabled)
        {
            Object.Destroy(PlatformR);
            PlatformREnabled = false;
        }

        if (!ControllerInputPoller.instance.leftGrab)
            Object.Destroy(PltformL);

        if (!ControllerInputPoller.instance.rightGrab)
            Object.Destroy(PlatformR);
    }

    public static void SolidWater()
    {
        foreach (WaterVolume WaterShit in Object.FindObjectsOfType<WaterVolume>())
        {
            GameObject v = WaterShit.gameObject;
            v.layer = LayerMask.NameToLayer("Default");
        }
    }

    public static void UnSolidWater()
    {
        foreach (WaterVolume WaterShit in Object.FindObjectsOfType<WaterVolume>())
        {
            GameObject v = WaterShit.gameObject;
            v.layer = LayerMask.NameToLayer("Water");
        }
    }

    public static void SuperSwim()
    {
        if (Player.Instance.InWater)
        {
            Player.Instance.gameObject.GetComponent<Rigidbody>().velocity *= 2f;
        }
    }

    public static GameObject Plat { get; private set; }

  public static float Delay { get; private set; }
}
