﻿using GorillaNetworking;
using Photon.Pun;
using System;
using System.IO;
using UnityEngine;
using static TGSGhostt.Mods.SafetySettings;

#nullable disable
namespace TGSGhostts_Menu.Mods
{
  internal class NameChangers
  {
    public static bool ValueUpdate = false;
    public static float ValueUpdateDelay = 0.0f;
    public static bool NameChanging = false;
    public static bool ChangeColorShit = false;
    public static string ChangeNameShit = "";
    public static Color ChangeSkin = Color.black;
        public static void ChangeName(string PlayerName)
        {
            try
            {
                PlayerName.ToUpper();
                if (PhotonNetwork.InRoom)
                {
                    GorillaComputer.instance.currentName = PlayerName;
                    PhotonNetwork.LocalPlayer.NickName = PlayerName;
                    GorillaComputer.instance.offlineVRRigNametagText.text = PlayerName;
                    GorillaComputer.instance.savedName = PlayerName;
                    PlayerPrefs.SetString("playerName", PlayerName);
                    PlayerPrefs.Save();
                    NameChangers.ChangeColor(GorillaTagger.Instance.offlineVRRig.playerColor);
                }
                else
                {
                    GorillaComputer.instance.currentName = PlayerName;
                    PhotonNetwork.LocalPlayer.NickName = PlayerName;
                    GorillaComputer.instance.offlineVRRigNametagText.text = PlayerName;
                    GorillaComputer.instance.savedName = PlayerName;
                    PlayerPrefs.SetString("playerName", PlayerName);
                    PlayerPrefs.Save();
                    NameChangers.ChangeColor(GorillaTagger.Instance.offlineVRRig.playerColor);
                }
            }
            catch (Exception ex)
            {
                Debug.LogError((object)string.Format("error", (object)ex.Message, (object)ex.StackTrace));
            }
        }

    public static void ChangeColor(Color color)
    {
      if (PhotonNetwork.InRoom)
      {
        if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
        {
          PlayerPrefs.SetFloat("redValue", Mathf.Clamp(color.r, 0.0f, 1f));
          PlayerPrefs.SetFloat("greenValue", Mathf.Clamp(color.g, 0.0f, 1f));
          PlayerPrefs.SetFloat("blueValue", Mathf.Clamp(color.b, 0.0f, 1f));
          ((Renderer) GorillaTagger.Instance.offlineVRRig.mainSkin).material.color = color;
          GorillaTagger.Instance.UpdateColor(color.r, color.g, color.b);
          PlayerPrefs.Save();
          GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", (RpcTarget) 0, new object[4]
          {
            (object) color.r,
            (object) color.g,
            (object) color.b,
            (object) false
          });
          FlushRPCs();
        }
        else
        {
          NameChangers.ValueUpdate = true;
          NameChangers.ValueUpdateDelay = Time.time + 0.5f;
          NameChangers.ChangeColorShit = true;
          NameChangers.ChangeSkin = color;
        }
      }
      else
      {
        PlayerPrefs.SetFloat("redValue", Mathf.Clamp(color.r, 0.0f, 1f));
        PlayerPrefs.SetFloat("greenValue", Mathf.Clamp(color.g, 0.0f, 1f));
        PlayerPrefs.SetFloat("blueValue", Mathf.Clamp(color.b, 0.0f, 1f));
        ((Renderer) GorillaTagger.Instance.offlineVRRig.mainSkin).material.color = color;
        GorillaTagger.Instance.UpdateColor(color.r, color.g, color.b);
        PlayerPrefs.Save();
        GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", (RpcTarget) 0, new object[4]
        {
          (object) color.r,
          (object) color.g,
          (object) color.b,
          (object) false
        });
        FlushRPCs();
      }
    }
    public static void WqsuName() => NameChangers.ChangeName("WQSU");
    public static void NoName() => NameChangers.ChangeName("________");

    public static void SubToMe() => NameChangers.ChangeName("sub to tgsghost");

    public static void Subscribe() => NameChangers.ChangeName("subbscribe 0:");

    public static void PBBVName() => NameChangers.ChangeName("PBBV");

    public static void EchoName() => NameChangers.ChangeName("ECHO");

    public static void DaisyName() => NameChangers.ChangeName("Daisy09");

    public static void RunName() => NameChangers.ChangeName("RUN");

    public static void BanSheeName() => NameChangers.ChangeName("BANSHEE");

    public static void Ryzr3Name() => NameChangers.ChangeName("RYZR3");

    public static void ApexGtagName() => NameChangers.ChangeName("ApexGtag");

    public static void CookedForListedName() => NameChangers.ChangeName("Cooked4Listed");

    public static void AverageGorillaName() => NameChangers.ChangeName("AverageGorilla");

    public static void ToxicName() => NameChangers.ChangeName("Toxic");

    public static void BrandonName() => NameChangers.ChangeName("504Brandon");
    }
}
