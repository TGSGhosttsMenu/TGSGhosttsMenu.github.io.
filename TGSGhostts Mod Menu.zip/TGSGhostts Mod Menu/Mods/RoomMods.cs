﻿using GorillaNetworking;
using System.Linq;
using UnityEngine;

namespace TGSGhostts_Menu.Mods
{
    internal static class RoomMods
    {
        public static void MuteallPlayers()
        {
            GorillaPlayerScoreboardLine[] ScoreBoardLine = UnityEngine.Object.FindObjectsOfType<GorillaPlayerScoreboardLine>();
            foreach (GorillaPlayerScoreboardLine MuteLine in ScoreBoardLine)
            {
                if (MuteLine.linePlayer != null)
                {
                    MuteLine.PressButton(true, GorillaPlayerLineButton.ButtonType.Mute);
                    MuteLine.muteButton.isOn = true;
                    MuteLine.muteButton.UpdateColor();
                }
            }
        }

        public static void ReportAllForToxicity()
        {
            GorillaPlayerScoreboardLine[] ScoreBoardLine = UnityEngine.Object.FindObjectsOfType<GorillaPlayerScoreboardLine>();
            foreach (GorillaPlayerScoreboardLine ReportLine in ScoreBoardLine)
            {
                if (ReportLine.linePlayer != null)
                {
                    ReportLine.PressButton(true, GorillaPlayerLineButton.ButtonType.Toxicity);
                }
            }
        }

        public static void MuteAllMusic()
        {
            foreach (SoundPostMuteButton muteButton in UnityEngine.Object.FindObjectsOfType<SoundPostMuteButton>())
            {
                muteButton.ButtonActivation();
            }
        }
    }
}
