﻿using BepInEx;
using GorillaLocomotion;
using POpusCodec.Enums;
using TGSGhostt.Mods;
using TGSGhostt.Patches;
using System.Collections;
using System.Reflection;
using UnityEngine;
using UnityEngine.XR;
using HarmonyLib;
using UnityEngine.UI;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Diagnostics;
using MenuHelpers;

#nullable disable
namespace TGSGhostt.Mods
{
    internal class RigMods
    {
        public static float HeadSpeed = 5f;
        public static float FlySpeed = 8.5f;
        public static float LongArmSize = 1.2f;
        public static VRRig WhoCopy;
        public static GameObject GunMain;
        public static LineRenderer lineMain;
        public static Color GunPointerColor1 = Color.magenta;
        public static GameObject CheckPoint = (GameObject)null;
        public static Color bgColorA = Color.blue;
        public static Color buttonDefaultA = Color.cyan;
        public static Vector3 walkPos;
        public static float WallWalkForce = -25f;
        public static Vector3 walkNormal;
        public static float HandTapVolume = 0.1f;

        public static void SpinHead()
        {
            GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.y += RigMods.HeadSpeed;
        }
        static bool idk = false;
        /*
        [HarmonyPatch(typeof(VRRig), "PlayHandTapLocal"), HarmonyWrapSafe]
        class EveryWalkIncreasesSpeed : MonoBehaviour
        {
            static void Postfix(VRRig __instance)
            {
                if (__instance.isOfflineVRRig)
                {
                    if (idk)
                    {
                        GorillaLocomotion.Player.Instance.maxJumpSpeed += 0.2f;
                        GorillaLocomotion.Player.Instance.jumpMultiplier += 0.1f;
                        NotifiLib.SendNotification("Current Jump Speed: " + GorillaLocomotion.Player.Instance.maxJumpSpeed.ToString());
                        NotifiLib.SendNotification("<color=white>Current Jump Multiplier </color>"+GorillaLocomotion.Player.Instance.jumpMultiplier.ToString());
                    }
                }
            }
        }
        // NOT WORKING
        public static void SpeedWalk()
        {
            idk = true;
        }
        public static void SpeedWalkOff()
        {
            GorillaLocomotion.Player.Instance.maxJumpSpeed = 6.5f;
            GorillaLocomotion.Player.Instance.jumpMultiplier = 1.2f;
            idk = false;
        }*/
        public static void FixHead()
        {
            GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.x = 0.0f;
            GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.y = 0.0f;
            GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.z = 0.0f;
        }
        public static void Fly()
        {
            if (!ControllerInputPoller.instance.rightControllerPrimaryButton)
                return;
            Transform transform = Player.Instance.transform;
            transform.position += Player.Instance.headCollider.transform.forward * Time.deltaTime * RigMods.FlySpeed;
            Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
        }
        public static void RestartGame()
        {
            Process.Start("steam://rungameid/1533390");
            Application.Quit();
        }
        public static void Noclip()
    {
      if ((double) ControllerInputPoller.instance.rightControllerIndexFloat > 0.0)
      {
        foreach (Collider collider in Resources.FindObjectsOfTypeAll<MeshCollider>())
          collider.enabled = false;
                FunMods.Platforms();
      }
      else
      {
        foreach (Collider collider in Resources.FindObjectsOfTypeAll<MeshCollider>())
          collider.enabled = true;
      }
    }
        public static void GhostMonke()
        {
            if (ControllerInputPoller.instance.rightControllerSecondaryButton)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = false;

                GameObject primitive1 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                Object.Destroy(primitive1.GetComponent<Rigidbody>());
                Object.Destroy(primitive1.GetComponent<SphereCollider>());
                primitive1.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                primitive1.transform.position = GorillaTagger.Instance.rightHandTransform.position;
                primitive1.GetComponent<Renderer>().material.color = new Color32(56, byte.MaxValue, 244, 251);

                GameObject primitive2 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                Object.Destroy(primitive2.GetComponent<Rigidbody>());
                Object.Destroy(primitive2.GetComponent<SphereCollider>());
                primitive2.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                primitive2.transform.position = GorillaTagger.Instance.leftHandTransform.position;
                primitive2.GetComponent<Renderer>().material.color = new Color32(56, byte.MaxValue, 244, 251);

                Object.Destroy(primitive1, Time.deltaTime);
                Object.Destroy(primitive2, Time.deltaTime);
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }



        public static void InvisMonke()
        {
            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.0)
            {
                GorillaTagger.Instance.offlineVRRig.headBodyOffset.x = 180f;

                GameObject primitive1 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                Object.Destroy(primitive1.GetComponent<Rigidbody>());
                Object.Destroy(primitive1.GetComponent<SphereCollider>());
                primitive1.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                primitive1.transform.position = GorillaTagger.Instance.rightHandTransform.position;
                primitive1.GetComponent<Renderer>().material.color = new Color32(56, byte.MaxValue, 244, 251);
                Object.Destroy(primitive1, Time.deltaTime);

                GameObject primitive2 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                Object.Destroy(primitive2.GetComponent<Rigidbody>());
                Object.Destroy(primitive2.GetComponent<SphereCollider>());
                primitive2.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                primitive2.transform.position = GorillaTagger.Instance.leftHandTransform.position;
                primitive2.GetComponent<Renderer>().material.color = new Color32(56, byte.MaxValue, 244, 251);
                Object.Destroy(primitive2, Time.deltaTime);
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.headBodyOffset.x = 0.0f;
            }
        }


        public static void LongArmsSub(float c, float v, float b)
        {
            GorillaLocomotion.Player.Instance.transform.localScale = new Vector3(c, v, b);
        }
        public static void SpeedBoostSub(float num) => Player.Instance.maxJumpSpeed = num; 
    public static void NormalSpeed()
    {
            SpeedBoostSub(7f);
      SafetySettings.FlushRPCs();
    }

    public static void FastSpeed()
    {
      SpeedBoostSub(13f);
      SafetySettings.FlushRPCs();
    }

    public static void FasterSpeed()
    {
      SpeedBoostSub(15f);
      SafetySettings.FlushRPCs();
    }

    public static void InsaneSpeed()
    {
      SpeedBoostSub(20f);
      SafetySettings.FlushRPCs();
    }

    public static void NoTagFreeze() => Player.Instance.disableMovement = false;

        public static void RigGun()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab || !Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up,
                                 -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit))
            {
                return;
            }
            if (FunMods.GunMain != null)
                Object.Destroy(FunMods.GunMain);
            if (FunMods.LineMain != null)
                Object.Destroy(FunMods.LineMain.gameObject);
            FunMods.GunMain = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            FunMods.GunMain.GetComponent<Renderer>().material.color = Color.blue;
            FunMods.GunMain.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
            FunMods.GunMain.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            FunMods.GunMain.transform.position = raycastHit.point;
            Object.Destroy(FunMods.GunMain.GetComponent<BoxCollider>());
            Object.Destroy(FunMods.GunMain.GetComponent<Rigidbody>());
            Object.Destroy(FunMods.GunMain.GetComponent<Collider>());
            FunMods.LineMain = new GameObject("Line").AddComponent<LineRenderer>();
            FunMods.LineMain.startColor = Color.blue;
            FunMods.LineMain.endColor = Color.blue;
            FunMods.LineMain.startWidth = 0.025f;
            FunMods.LineMain.endWidth = 0.025f;
            FunMods.LineMain.positionCount = 2;
            FunMods.LineMain.useWorldSpace = true;
            FunMods.LineMain.SetPosition(0, GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R").transform.position);
            FunMods.LineMain.SetPosition(1, raycastHit.point);
            FunMods.LineMain.material.shader = Shader.Find("GUI/Text Shader");
            if (ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.5f)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                FunMods.GunMain.GetComponent<Renderer>().material.color = new Color32(56, byte.MaxValue, 244, 251);
                Vector3 newPosition = FunMods.GunMain.transform.position + new Vector3(0.0f, 0.45f, 0.0f);
                GorillaTagger.Instance.offlineVRRig.transform.position = newPosition;
                GorillaTagger.Instance.myVRRig.transform.position = newPosition;
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
            if (raycastHit.collider.GetComponentInParent<VRRig>() != null)
            {
                RigMods.WhoCopy = raycastHit.collider.GetComponentInParent<VRRig>();
            }
            Player.Instance.StartCoroutine(RigMods.DestroyAfterDelay());
        }


        public static IEnumerator DestroyAfterDelay()
        {
            yield return new WaitForSeconds(0.5f);
            if (FunMods.GunMain != null)
                Object.Destroy(FunMods.GunMain);
            if (FunMods.LineMain != null)
                Object.Destroy(FunMods.LineMain.gameObject);
        }

        public static void IronMonke()
        {
            {
                if (ControllerInput.Input.LG())
                {
                    GorillaLocomotion.Player.Instance.AddForce(GorillaLocomotion.Player.Instance.leftControllerTransform.position, ForceMode.Acceleration);
                    GorillaTagger.Instance.StartVibration(false, 1f, 1);
                }
                if (ControllerInput.Input.RG())
                {
                    GorillaLocomotion.Player.Instance.AddForce(GorillaLocomotion.Player.Instance.rightControllerTransform.position, ForceMode.Force);
                    GorillaTagger.Instance.StartVibration(false, 1f, 1);
                }
            }
        }


        public static void Checkpoint()
        {
            if (ControllerInputPoller.instance.rightGrab)
            {
                if (RigMods.CheckPoint == null)
                {
                    RigMods.CheckPoint = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Object.Destroy(RigMods.CheckPoint.GetComponent<Rigidbody>());
                    Object.Destroy(RigMods.CheckPoint.GetComponent<SphereCollider>());
                    RigMods.CheckPoint.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                }
                RigMods.CheckPoint.transform.position = GorillaTagger.Instance.rightHandTransform.position;
            }

            if (RigMods.CheckPoint == null)
                return;

            if (ControllerInputPoller.instance.rightControllerIndexFloat >= 0.3f)
            {
                RigMods.CheckPoint.GetComponent<Renderer>().material.color = RigMods.bgColorA;
                GorillaTagger.Instance.rigidbody.transform.position = RigMods.CheckPoint.transform.position;
                GorillaTagger.Instance.rigidbody.velocity = Vector3.zero;
            }
            else
            {
                RigMods.CheckPoint.GetComponent<Renderer>().material.color = RigMods.buttonDefaultA;
            }
        }

        public static void WASDMovementButton()
        {
            Transform playerTransform = Player.Instance.transform;
            Rigidbody playerRigidbody = Player.Instance.GetComponent<Rigidbody>();

            if (UnityInput.Current.GetKey(KeyCode.W))
            {
                playerTransform.position += Player.Instance.headCollider.transform.forward * Time.deltaTime * 3.5f;
                playerRigidbody.velocity = Vector3.zero;
            }
            if (UnityInput.Current.GetKey(KeyCode.S))
            {
                playerTransform.position += Player.Instance.headCollider.transform.forward * Time.deltaTime * -3.5f;
                playerRigidbody.velocity = Vector3.zero;
            }
            if (UnityInput.Current.GetKey(KeyCode.A))
            {
                playerTransform.position += Player.Instance.headCollider.transform.right * Time.deltaTime * -3.5f;
                playerRigidbody.velocity = Vector3.zero;
            }
            if (UnityInput.Current.GetKey(KeyCode.D))
            {
                playerTransform.position += Player.Instance.headCollider.transform.right * Time.deltaTime * 3.5f;
                playerRigidbody.velocity = Vector3.zero;
            }
            if (UnityInput.Current.GetKey(KeyCode.Space))
            {
                playerTransform.position += Player.Instance.headCollider.transform.up * Time.deltaTime * 3.5f;
                playerRigidbody.velocity = Vector3.zero;
            }
            if (UnityInput.Current.GetKey(KeyCode.LeftShift))
            {
                playerTransform.position += Player.Instance.headCollider.transform.up * Time.deltaTime * -3.5f;
                playerRigidbody.velocity = Vector3.zero;
            }
        }

        public static void WallWalk()
        {
            if ((Player.Instance.wasLeftHandTouching || Player.Instance.wasRightHandTouching) && ControllerInputPoller.instance.rightGrab)
            {
                RaycastHit raycastHit = (RaycastHit)typeof(Player).GetField("lastHitInfoHand", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(Player.Instance);
                RigMods.walkPos = raycastHit.point;
                RigMods.walkNormal = raycastHit.normal;
            }
            else if (!ControllerInputPoller.instance.rightGrab)
            {
                RigMods.walkPos = Vector3.zero;
            }

            if (RigMods.walkPos != Vector3.zero)
            {
                Player.Instance.bodyCollider.attachedRigidbody.AddForce(RigMods.walkNormal * RigMods.WallWalkForce, ForceMode.Impulse);
                FunMods.ZeroGravity();
            }
        }


        public static void HandTaps() => GorillaTagger.Instance.handTapVolume = RigMods.HandTapVolume;
  }
}
