﻿using System;
using System.Collections.Generic;
using System.Text;
using static TGSGhostt.Menu.Main;
using static TGSGhosttSettings.SettingsforMenu;
using UnityEngine.XR;
using UnityEngine;
using GorillaLocomotion;
using POpusCodec.Enums;
using TGSGhostt.Patches;
using BepInEx;
using ExitGames.Client.Photon;
using Photon.Pun;
using GorillaNetworking;
using System.Diagnostics;
using UnityEngine.UI;
using System.IO;
using TGSGhostt.Classes;
using TGSGhostt.Menu;
using System.Xml.Linq;
using UnityEngine.UIElements;
using TGSGhostts_Menu.Mods;
using TGSGhosttSettings;
using System.Net;

namespace TGSGhostt.Mods
{
    internal class SettingsMods
    {
        public static GameObject GunPointer = null;
        public static float Delay = 0;

        public static void Home()
        {
            buttonsType = 0; pageNumber = 0;
        }

        public static void Settings()
        {
            buttonsType = 1; pageNumber = 0;
        }

        public static void MenuSettings()
        {
            buttonsType = 2; pageNumber = 0;
        }

        public static void SafetySettings()
        {
            buttonsType = 3; pageNumber = 0;
        }

        public static void ConfigurationSettings()
        {
            buttonsType = 4; pageNumber = 0;
        }
        public static void NotificationSettingsTab()
        {
            buttonsType = 12; pageNumber = 0;
        }

        public static void FunMods()
        {
            buttonsType = 5; pageNumber = 0;
        }

        public static void RigMods()
        {
            buttonsType = 6; pageNumber = 0;
        }

        public static void VisualMods()
        {
            buttonsType = 7; pageNumber = 0;
        }

        public static void HoldableMods()
        {
            buttonsType = 8; pageNumber = 0;
        }

        public static void NameMods()
        {
            buttonsType = 9; pageNumber = 0;
        }

        public static void CheatMods()
        {
            buttonsType = 10; pageNumber = 0;
        }

        public static void SpamMods()
        {
            buttonsType = 11; pageNumber = 0;
        }

        public static void YoutubeChannels()
        {
            buttonsType = 13;
            pageNumber = 0;
        }

        public static void RoomMods()
        {
            buttonsType = 14; pageNumber = 0;
        }

        public static void RightHand()
        {
            rightHanded = true;
        }

        public static void LeftHand()
        {
            rightHanded = false;
        }


        public static void EnableFPSCounter() => fpsCounter = true;

        public static void DisableFPSCounter() => fpsCounter = false;

        public static void EnableNotifications()
        {
            disableNotifications = false;
        }

        public static void DisableNotifications()
        {
            disableNotifications = true;
        }

        public static void EnableDisconnectButton() => disconnectButton = true;

        public static void DisableDisconnectButton() => disconnectButton = false;

        public static void DisconnectButtonTop() => disconnectbuttonTop = true;

        public static void DisconnectButtonTopDisable() => disconnectbuttonTop = false;

        public static void PageButtonTop()
        {
            PageButtonsBottom = false;
            disconnectbuttonTop = false;
        }

        public static void PageButtonTopDisable()
        {
            PageButtonsBottom = true;
            disconnectbuttonTop = true;
        }

        public static void BordersOn() => BorderOn = true;
        public static void BordersOff() => BorderOn = false;


        private static string MOTDBoardTextLIVE;
        private static string COCBoardTextLIVE;
        public static void MOTDBoardTextHelp()
        {
            using (WebClient MOTDMainTextLIVE = new WebClient())
            {
                MOTDBoardTextLIVE = MOTDMainTextLIVE.DownloadString("https://pastebin.com/raw/xAxDVtxX");
            }
        }

        public static void COCBoardTextHelp()
        {
            using (WebClient COCMainTextLIVE = new WebClient())
            {
                COCBoardTextLIVE = COCMainTextLIVE.DownloadString("https://pastebin.com/xD0p6MZb");
            }
        }

        public static Color BoardColors = Color.blue;

        public static void TGSGhosttsBoards()
        {
            MOTDBoardTextHelp();
            COCBoardTextHelp();
            // board texts
            GameObject.Find("motdtext").GetComponent<Text>().text = MOTDBoardTextLIVE;
            GameObject.Find("COC Text").GetComponent<Text>().text = COCBoardTextLIVE;
            GameObject.Find("CodeOfConduct").GetComponent<Text>().text = "Menu Conduct";
            GameObject.Find("motd").GetComponent<Text>().text = "Menu MOTD";
            // board colors
            GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/GorillaComputerObject/ComputerUI/monitor/monitorScreen").GetComponent<Renderer>().material.color = BoardColors;
            GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/motd").GetComponent<Renderer>().material.color = BoardColors;
            GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/forestatlas").GetComponent<Renderer>().material.color = BoardColors;

        }
        public static void NoAfkKick() => PhotonNetworkController.Instance.disableAFKKick = true;

        public static void FPSNormal() => QualitySettings.globalTextureMipmapLimit = 1;

        public static void FPSLow() => QualitySettings.globalTextureMipmapLimit = 99999;

        public static void DisableQuitBox()
        {
            GameObject.Find("Environment Objects/TriggerZones_Prefab/ZoneTransitions_Prefab/QuitBox").SetActive(false);
        }

        public static void JoinDiscord()
        {
            Process.Start("discord.gg/tgsghosttsmenu");
        }

        public static void RoomTrackerOn()
        {
            SettingsforMenu.PublicTracker = true;
        }

        public static void RoomTrackerOff()
        {
            SettingsforMenu.PublicTracker = false;
        }
        public static class Hide
        {
            public static bool SigmaValueShit = false;
            public static float SigmaShitDelay = 0.5f;
            public static bool NameChange = false;
            public static bool ColorChange = false;
            public static string NameChange2 = "";
            public static Color ColorChnge2 = Color.blue;

            public static void UpdateName(string PlayerName)
            {
                try
                {
                    if (PhotonNetwork.InRoom || PhotonNetwork.InLobby)
                    {
                        if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                        {
                            ApplyNameChange(PlayerName);
                        }
                        else
                        {
                            ScheduleNameChange(PlayerName);
                        }
                    }
                    else
                    {
                        ApplyNameChange(PlayerName);
                    }
                }
                catch (Exception ex)
                {
                    UnityEngine.Debug.LogError($"Failed to update name: {ex.Message}");
                }
            }

            private static void ApplyNameChange(string PlayerName)
            {
                GorillaComputer.instance.currentName = PlayerName;
                PhotonNetwork.LocalPlayer.NickName = PlayerName;
                GorillaComputer.instance.offlineVRRigNametagText.text = PlayerName;
                GorillaComputer.instance.savedName = PlayerName;
                PlayerPrefs.SetString("playerName", PlayerName);
                PlayerPrefs.Save();
                UpdateColor(GorillaTagger.Instance.offlineVRRig.playerColor);
            }

            private static void ScheduleNameChange(string PlayerName)
            {
                SigmaValueShit = true;
                SigmaShitDelay = Time.time + 0.5f;
                NameChange = true;
                NameChange2 = PlayerName;
            }

            public static void UpdateColor(Color color)
            {
                try
                {
                    if (PhotonNetwork.InRoom || PhotonNetwork.InLobby)
                    {
                        if (GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId))
                        {
                            ApplyColorChange(color);
                        }
                        else
                        {
                            ScheduleColorChange(color);
                        }
                    }
                    else
                    {
                        ApplyColorChange(color);
                    }
                }
                catch (Exception ex)
                {
                    UnityEngine.Debug.LogError($"Failed to update color: {ex.Message}");
                }
            }

            private static void ApplyColorChange(Color color)
            {
                PlayerPrefs.SetFloat("redValue", Mathf.Clamp(color.r, 0.0f, 1f));
                PlayerPrefs.SetFloat("greenValue", Mathf.Clamp(color.g, 0.0f, 1f));
                PlayerPrefs.SetFloat("blueValue", Mathf.Clamp(color.b, 0.0f, 1f));
                GorillaTagger.Instance.offlineVRRig.mainSkin.material.color = color;
                GorillaTagger.Instance.UpdateColor(color.r, color.g, color.b);
                PlayerPrefs.Save();
                GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", RpcTarget.AllBuffered, new object[]
                {
        color.r, color.g, color.b, false
                });
            }

            private static void ScheduleColorChange(Color color)
            {
                SigmaValueShit = true;
                SigmaShitDelay = Time.time + 0.5f;
                ColorChange = true;
                ColorChnge2 = color;
            }

            public static void HideSelf()
            {
                string PlayerNameChange = "GORILLA";
                for (int index = 0; index < 4; ++index)
                {
                    PlayerNameChange += UnityEngine.Random.Range(0, 10).ToString();
                }
                UpdateName(PlayerNameChange);
                Color32 ColorChangerRandomized = new Color32(
                    (byte)UnityEngine.Random.Range(0, byte.MaxValue + 1),
                    (byte)UnityEngine.Random.Range(0, byte.MaxValue + 1),
                    (byte)UnityEngine.Random.Range(0, byte.MaxValue + 1),
                    byte.MaxValue
                );
                UpdateColor(ColorChangerRandomized);
            }

            public static void Update()
            {
                if (SigmaValueShit && Time.time > SigmaShitDelay)
                {
                    SigmaValueShit = false;

                    if (NameChange)
                    {
                        ApplyNameChange(NameChange2);
                        NameChange = false;
                    }

                    if (ColorChange)
                    {
                        ApplyColorChange(ColorChnge2);
                        ColorChange = false;
                    }
                }
            }           

        }

        public static void SavePreferences()
        {
            string ButtonONText = "";
            foreach (ButtonInfo[] EnabledButtons in Buttons.buttons)
            {
                foreach (ButtonInfo v in EnabledButtons)
                {
                    if (v.enabled && v.buttonText != "save mods" && v.buttonText != "disconnect button" && v.buttonText != "load mods" && v.buttonText != "room joiner notification" && v.buttonText != "enable notifications" && v.buttonText != "menu ui")
                    {
                        if (ButtonONText == "")
                        {
                            ButtonONText += v.buttonText;
                        }
                        else
                        {
                            ButtonONText += "\n" + v.buttonText;
                        }
                    }
                }
            }
            if (!Directory.Exists("TGSGhostt"))
            {
                Directory.CreateDirectory("TGSGhostt");
            }
            File.WriteAllText("TGSGhostt/SavedMods.txt", ButtonONText);
        }

        public static void LoadPreferences()
        {
            if (Directory.Exists("TGSGhostt"))
            {
                try
                {
                    string TextShit = File.ReadAllText("TGSGhostt/SavedMods.txt");
                    string[] ReadButtonsON = TextShit.Split("\n");
                    for (int index = 0; index < ReadButtonsON.Length; index++)
                    {
                        Toggle(ReadButtonsON[index]);
                    }
                }
                catch { }
            }
        }

        public static void OffUI()
        {
            GhostsUI.GhostGUI.showGUI = false;
        }

        public static void OnUI()
        {
            GhostsUI.GhostGUI.showGUI = true;
        }
    }
}
