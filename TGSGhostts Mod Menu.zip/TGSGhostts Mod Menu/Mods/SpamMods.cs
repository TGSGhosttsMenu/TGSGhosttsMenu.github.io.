﻿using GorillaLocomotion;
using System;
using TGSGhostt.Mods;
using UnityEngine;
using Object = UnityEngine.Object;

#nullable disable
namespace TGSGhostts_Menu.Mods
{
  internal class SpamMods
  {
        // most from ryzer so if its skidded then tell me and ill remake 

        public static int projectileSpeedCycle = 0;
    public static float projectileSpeed = 0.0f;
    public static int projColorCycle = 0;
    public static float projDelay = 0.0f;
    public static float projShootDelay = 0.15f;
    public static int projShootDelayCycle = 0;
    public static Color32 projColor = Color.white;
    public static int projCycle = 0;
    public static string[] fullProjectileNames = new string[6]
    {
      "Snowball",
      "WaterBalloon",
      "LavaRock",
      "ThrowableGift",
      "ScienceCandy",
      "FishFood"
    };
    public static int ProjectileType = 1;

        public static void Projectile(string projectileName, Vector3 position,  Vector3 velocity,  Color color, bool noDelay = false)
        {
            ControllerInputPoller.instance.leftControllerGripFloat = 1f;
            GameObject primitive = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            Object.Destroy(primitive, 0.1f);
            primitive.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            primitive.transform.position = GorillaTagger.Instance.leftHandTransform.position;
            primitive.transform.rotation = GorillaTagger.Instance.leftHandTransform.rotation;

            int[] overrideIndices = new int[] { 32, 204, 231, 240, 249, 252 };
            int projectileIndex = Array.IndexOf(SpamMods.fullProjectileNames, projectileName);
            if (projectileIndex == -1) return;

            primitive.AddComponent<GorillaSurfaceOverride>().overrideIndex = overrideIndices[projectileIndex];
            primitive.GetComponent<Renderer>().enabled = false;

            if (Time.time <= SpamMods.projDelay)
                return;

            try
            {
                Vector3 originalVelocity = GorillaTagger.Instance.GetComponent<Rigidbody>().velocity;
                string[] anchorNames = new string[] { "LMACE.", "LMAEX.", "LMAGD.", "LMAHQ.", "LMAIE.", "LMAIO." };
                SnowballThrowable component = GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.L/upper_arm.L/forearm.L/hand.L/palm.01.L/TransferrableItemLeftHand/" + SpamMods.fullProjectileNames[projectileIndex] + "LeftAnchor").transform.Find(anchorNames[projectileIndex]).GetComponent<SnowballThrowable>();

                Vector3 originalPosition = component.transform.position;
                component.randomizeColor = true;
                component.transform.position = position;
                GorillaTagger.Instance.GetComponent<Rigidbody>().velocity = velocity;
                GorillaTagger.Instance.offlineVRRig.LeftThrowableProjectileColor = color;
                GorillaTagger.Instance.offlineVRRig.RightThrowableProjectileColor = color;
                GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer/EquipmentInteractor").GetComponent<EquipmentInteractor>().ReleaseLeftHand();
                GorillaTagger.Instance.GetComponent<Rigidbody>().velocity = originalVelocity;
                component.transform.position = originalPosition;
                component.randomizeColor = false;
                SafetySettings.FlushRPCs();
            }
            catch
            {
            }

            if (SpamMods.projShootDelay > 0.0f && !noDelay)
                SpamMods.projDelay = Time.time + SpamMods.projShootDelay;
        }

        public static void SnowballSpammer()
        {
            if (!ControllerInputPoller.instance.rightGrab)
                return;
            Color color = SpamMods.projColor;
            SpamMods.Projectile(SpamMods.fullProjectileNames[0], Player.Instance.rightControllerTransform.position, Vector3.down, color);
        }

        public static void WaterSpammer()
        {
            if (!ControllerInputPoller.instance.rightGrab)
                return;
            Color color = SpamMods.projColor;
            SpamMods.Projectile(SpamMods.fullProjectileNames[1], Player.Instance.rightControllerTransform.position, Vector3.down, color);
        }

        public static void LavaSpammer()
        {
            if (!ControllerInputPoller.instance.rightGrab)
                return;
            Color color = SpamMods.projColor;
            SpamMods.Projectile(SpamMods.fullProjectileNames[2], Player.Instance.rightControllerTransform.position, Vector3.down, color);
        }

        public static void GiftSpammer()
        {
            if (!ControllerInputPoller.instance.rightGrab)
                return;
            Color color = SpamMods.projColor;
            SpamMods.Projectile(SpamMods.fullProjectileNames[3], Player.Instance.rightControllerTransform.position, Vector3.down, color);
        }

        public static void CandySpammer()
        {
            if (!ControllerInputPoller.instance.rightGrab)
                return;
            Color color = SpamMods.projColor;
            SpamMods.Projectile(SpamMods.fullProjectileNames[4], Player.Instance.rightControllerTransform.position, Vector3.down, color);
        }

        public static void FishSpammer()
        {
            if (!ControllerInputPoller.instance.rightGrab)
                return;
            Color color = SpamMods.projColor;
            SpamMods.Projectile(SpamMods.fullProjectileNames[5], Player.Instance.rightControllerTransform.position, Vector3.down, color);
        }

        public static void SnowBallGun()
        {
            if (!ControllerInputPoller.instance.rightGrab)
                return;
            Color color = SpamMods.projColor;
            SpamMods.Projectile(SpamMods.fullProjectileNames[0],Player.Instance.rightControllerTransform.position, -Player.Instance.rightControllerTransform.up * 10.5f, projColor, false);
        }

        public static void WaterGun()
        {
            if (!ControllerInputPoller.instance.rightGrab)
                return;
            Color color = SpamMods.projColor;
            SpamMods.Projectile(SpamMods.fullProjectileNames[1], Player.Instance.rightControllerTransform.position, -Player.Instance.rightControllerTransform.up * 10.5f, projColor, false);
        }

        public static void LavaGun()
        {
            if (!ControllerInputPoller.instance.rightGrab)
                return;
            Color color = SpamMods.projColor;
            SpamMods.Projectile(SpamMods.fullProjectileNames[2], Player.Instance.rightControllerTransform.position, -Player.Instance.rightControllerTransform.up * 10.5f, projColor, false);
        }

        public static void GiftGun()
        {
            if (!ControllerInputPoller.instance.rightGrab)
                return;
            Color color = SpamMods.projColor;
            SpamMods.Projectile(SpamMods.fullProjectileNames[3], Player.Instance.rightControllerTransform.position, -Player.Instance.rightControllerTransform.up * 10.5f, projColor, false);
        }

        public static void CandyGun()
        {
            if (!ControllerInputPoller.instance.rightGrab)
                return;
            Color color = SpamMods.projColor;
            SpamMods.Projectile(SpamMods.fullProjectileNames[4], Player.Instance.rightControllerTransform.position, -Player.Instance.rightControllerTransform.up * 10.5f, projColor, false);
        }

        public static void FishGun()
        {
            if (!ControllerInputPoller.instance.rightGrab)
                return;
            Color color = SpamMods.projColor;
            SpamMods.Projectile(SpamMods.fullProjectileNames[5], Player.Instance.rightControllerTransform.position, -Player.Instance.rightControllerTransform.up * 10.5f, projColor, false);
        }

    }
}
