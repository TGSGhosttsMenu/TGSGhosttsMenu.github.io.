﻿using GorillaExtensions;
using GorillaLocomotion;
using Photon.Pun;
using Photon.Realtime;
using System.Collections.Generic;
using TGSGhosttSettings;
using UnityEngine;
using UnityEngine.Animations.Rigging;
using UnityEngine.XR.Interaction.Toolkit;
using Viveport;

#nullable disable
namespace TGSGhostts_Menu.Mods
{
  internal class VisualMods
  {
    private static bool BoneShit;

        public static void ESP()
        {
            foreach (VRRig VRRigNotHorny in GorillaParent.instance.vrrigs)
            {
                if (VRRigNotHorny != GorillaTagger.Instance.offlineVRRig)
                {
                    VisualMods.Esp = VRRigNotHorny.mainSkin.material.color;
                    if (VRRigNotHorny.mainSkin.material.name.Contains("fected"))
                        VRRigNotHorny.mainSkin.material.color = VRRigNotHorny.playerColor;
                    else
                        VRRigNotHorny.mainSkin.material.color = VRRigNotHorny.playerColor;
                    VRRigNotHorny.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
                }
            }
        }


        public static void UndoESP()
        {
            foreach (VRRig VRRigNotHorny in GorillaParent.instance.vrrigs)
            {
                if (VRRigNotHorny != GorillaTagger.Instance.offlineVRRig)
                {
                    VRRigNotHorny.mainSkin.material.shader = Shader.Find("GorillaTag/UberShader");
                    VRRigNotHorny.mainSkin.material.color = VRRigNotHorny.playerColor;
                }
            }
        }



        public static void BoxESP()
        {
            VRRig[] VrRigShit = GameObject.FindObjectsOfType<VRRig>();
            foreach (VRRig rig in VrRigShit)
            {
                if (rig != null && !rig.isOfflineVRRig && !rig.isMyPlayer)
                {
                    GameObject gameObject = new GameObject("box");
                    gameObject.transform.position = rig.transform.position;

                    GameObject primitive1 = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    GameObject primitive2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    GameObject primitive3 = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    GameObject primitive4 = GameObject.CreatePrimitive(PrimitiveType.Cube);

                    Object.Destroy(primitive1.GetComponent<BoxCollider>());
                    Object.Destroy(primitive2.GetComponent<BoxCollider>());
                    Object.Destroy(primitive3.GetComponent<BoxCollider>());
                    Object.Destroy(primitive4.GetComponent<BoxCollider>());

                    primitive1.transform.SetParent(gameObject.transform);
                    primitive1.transform.localPosition = new Vector3(0.0f, 0.49f, 0.0f);
                    primitive1.transform.localScale = new Vector3(1f, 0.02f, 0.02f);

                    primitive4.transform.SetParent(gameObject.transform);
                    primitive4.transform.localPosition = new Vector3(0.0f, -0.49f, 0.0f);
                    primitive4.transform.localScale = new Vector3(1f, 0.02f, 0.02f);

                    primitive3.transform.SetParent(gameObject.transform);
                    primitive3.transform.localPosition = new Vector3(-0.49f, 0.0f, 0.0f);
                    primitive3.transform.localScale = new Vector3(0.02f, 1f, 0.02f);

                    primitive2.transform.SetParent(gameObject.transform);
                    primitive2.transform.localPosition = new Vector3(0.49f, 0.0f, 0.0f);
                    primitive2.transform.localScale = new Vector3(0.02f, 1f, 0.02f);

                    primitive1.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                    primitive4.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                    primitive3.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                    primitive2.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");

                    primitive1.GetComponent<Renderer>().material.color = rig.playerColor;
                    primitive4.GetComponent<Renderer>().material.color = rig.playerColor;
                    primitive3.GetComponent<Renderer>().material.color = rig.playerColor;
                    primitive2.GetComponent<Renderer>().material.color = rig.playerColor;

                    gameObject.transform.LookAt(gameObject.transform.position + Camera.main.transform.forward, Camera.main.transform.up);  

                   Object.Destroy(gameObject, Time.deltaTime);
                }
            }
        }


        public static Color Esp { get; private set; }

        public static void BoneESP()
        {
            foreach (VRRig VRRigNotHorny in GorillaParent.instance.vrrigs)
            {
                if (VRRigNotHorny != null && !VRRigNotHorny.isOfflineVRRig)
                    GTExt.GetOrAddComponent<VisualMods.SkeletonESPClass>(VRRigNotHorny.gameObject);
            }
            VisualMods.BoneShit = true;
        }

        public static void EndSkeleEsp()
        {
            if (VisualMods.BoneShit)
            {
                foreach (VRRig VRRigNotHorny in GorillaParent.instance.vrrigs)
                {
                    if (VRRigNotHorny != null && !VRRigNotHorny.isOfflineVRRig)
                        Object.Destroy(VRRigNotHorny.gameObject.GetComponent<VisualMods.SkeletonESPClass>());
                }
            }
            VisualMods.BoneShit = false;
        }


        public static void Beacons()
        {
            VRRig[] VrRigShit = GameObject.FindObjectsOfType<VRRig>();
            foreach (VRRig rig in VrRigShit)
            {
                if (rig != GorillaTagger.Instance.offlineVRRig)
                {
                    GameObject beacon = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                    beacon.transform.localScale = new Vector3(0.05f, 350f, 0.05f);
                    beacon.transform.position = rig.transform.position;
                    GameObject.Destroy(beacon.GetComponent<Collider>());
                    beacon.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                    beacon.GetComponent<Renderer>().material.color = rig.playerColor;
                    GameObject.Destroy(beacon, Time.deltaTime);
                }
            }
        }
        
        public static Transform TracerPos = GorillaLocomotion.Player.Instance.rightControllerTransform;

        public static void Tracers()
        {
            VRRig[] VrRigShit = GameObject.FindObjectsOfType<VRRig>();
            foreach (VRRig rig in VrRigShit)
            {
                    if (rig != GorillaTagger.Instance.offlineVRRig)
                    {
                        GameObject LineObject = new GameObject("Line");
                        LineRenderer lineRenderer = LineObject.AddComponent<LineRenderer>();
                        Color lineColor = rig.playerColor;
                        lineColor.a = 0.5f;

                        lineRenderer.startColor = lineColor;
                        lineRenderer.endColor = lineColor;
                        lineRenderer.startWidth = 0.04f;
                        lineRenderer.endWidth = 0.04f;
                        lineRenderer.positionCount = 2;
                        lineRenderer.SetPositions(new Vector3[]
                        {
                           TracerPos.position,
                           rig.transform.position
                        });
                        Shader shader = Shader.Find("GorillaTag/UberShader");
                        Material material = new Material(shader);
                        material.color = lineColor;
                        lineRenderer.material = material;
                        Object.Destroy(LineObject, Time.deltaTime);
                    }
                }
            
        }


        public static void DayTime() => BetterDayNightManager.instance.SetTimeOfDay(3);

    public static void NightTime() => BetterDayNightManager.instance.SetTimeOfDay(0);

        public static void Rain()
        {
            for (int i = 1; i < BetterDayNightManager.instance.weatherCycle.Length; i++)
            {
                BetterDayNightManager.instance.weatherCycle[i] = BetterDayNightManager.WeatherType.Raining;
            }
        }

        public static void NoRain()
        {
            for (int i = 1; i < BetterDayNightManager.instance.weatherCycle.Length; i++)
            {
                BetterDayNightManager.instance.weatherCycle[i] = BetterDayNightManager.WeatherType.None;
            }
        }

        public class SkeletonESPClass : MonoBehaviour
    {
      public Color lineColor = Color.cyan;
      public float lineWidth = 0.02f;
      private LineRenderer lineRenderer;
      private List<GameObject> lineObjects = new List<GameObject>();
            public static bool RGBSkeletonESP = false;

      private void Start()
      {
        this.lineRenderer = ((Component) this).gameObject.AddComponent<LineRenderer>();
        ((Renderer) this.lineRenderer).material = new Material(Shader.Find("GUI/Text Shader"));
        this.lineRenderer.startWidth = this.lineWidth;
        this.lineRenderer.endWidth = this.lineWidth;
      }

      private void Update() => this.DrawSkeleton();

      private void OnDestroy() => this.ClearLineObjects();

            public void DrawSkeleton()
            {
                this.ClearLineObjects();
                VRRig VRRigNotHorny = GetComponent<VRRig>();
                if (VRRigNotHorny == null)
                {
                    Debug.LogWarning("VRRig component is null.");
                    return;
                }

                Color color = VRRigNotHorny.mainSkin.material.color;
                if (VisualMods.SkeletonESPClass.RGBSkeletonESP)
                    color = GetAnimatedColor();

                DrawLine(VRRigNotHorny.headMesh.transform.position - new Vector3(0.0f, 0.35f, 0.0f), VRRigNotHorny.headMesh.transform.position, color);
                DrawLine(VRRigNotHorny.headMesh.transform.position - new Vector3(0.0f, 0.05f, 0.0f), VRRigNotHorny.headMesh.transform.position + VRRigNotHorny.headMesh.transform.up * 0.2f, color);
                DrawLine(VRRigNotHorny.headMesh.transform.position - new Vector3(0.0f, 0.05f, 0.0f), VRRigNotHorny.headMesh.transform.position - ((Component)VRRigNotHorny).transform.right * 0.15f, color);
                DrawLine(VRRigNotHorny.headMesh.transform.position - new Vector3(0.0f, 0.05f, 0.0f), VRRigNotHorny.headMesh.transform.position + ((Component)VRRigNotHorny).transform.right * 0.15f, color);
                DrawLine(VRRigNotHorny.headMesh.transform.position + ((Component)VRRigNotHorny).transform.right * -0.15f, VRRigNotHorny.myBodyDockPositions.leftArmTransform.position, color);
                DrawLine(VRRigNotHorny.headMesh.transform.position + ((Component)VRRigNotHorny).transform.right * 0.15f, VRRigNotHorny.myBodyDockPositions.rightArmTransform.position, color);
                DrawLine(VRRigNotHorny.myBodyDockPositions.leftArmTransform.position, VRRigNotHorny.leftHandTransform.position, color);
                DrawLine(VRRigNotHorny.myBodyDockPositions.rightArmTransform.position, VRRigNotHorny.rightHandTransform.position, color);
                DrawLine(VRRigNotHorny.rightHandTransform.position, VRRigNotHorny.rightThumb.fingerBone1.position, color);
                DrawLine(VRRigNotHorny.rightThumb.fingerBone1.position, VRRigNotHorny.rightThumb.fingerBone2.position, color);
                DrawLine(VRRigNotHorny.rightHandTransform.position, VRRigNotHorny.rightIndex.fingerBone1.position, color);
                DrawLine(VRRigNotHorny.rightIndex.fingerBone1.position, VRRigNotHorny.rightIndex.fingerBone2.position, color);
                DrawLine(VRRigNotHorny.rightIndex.fingerBone2.position, VRRigNotHorny.rightIndex.fingerBone3.position, color);
                DrawLine(VRRigNotHorny.rightHandTransform.position, VRRigNotHorny.rightMiddle.fingerBone1.position, color);
                DrawLine(VRRigNotHorny.rightMiddle.fingerBone1.position, VRRigNotHorny.rightMiddle.fingerBone2.position, color);
                DrawLine(VRRigNotHorny.rightMiddle.fingerBone2.position, VRRigNotHorny.rightMiddle.fingerBone3.position, color);
                DrawLine(VRRigNotHorny.leftHandTransform.position, VRRigNotHorny.leftThumb.fingerBone1.position, color);
                DrawLine(VRRigNotHorny.leftThumb.fingerBone1.position, VRRigNotHorny.leftThumb.fingerBone2.position, color);
                DrawLine(VRRigNotHorny.leftHandTransform.position, VRRigNotHorny.leftIndex.fingerBone1.position, color);
                DrawLine(VRRigNotHorny.leftIndex.fingerBone1.position, VRRigNotHorny.leftIndex.fingerBone2.position, color);
                DrawLine(VRRigNotHorny.leftIndex.fingerBone2.position, VRRigNotHorny.leftIndex.fingerBone3.position, color);
                DrawLine(VRRigNotHorny.leftHandTransform.position, VRRigNotHorny.leftMiddle.fingerBone1.position, color);
                DrawLine(VRRigNotHorny.leftMiddle.fingerBone1.position, VRRigNotHorny.leftMiddle.fingerBone2.position, color);
                DrawLine(VRRigNotHorny.leftMiddle.fingerBone2.position, VRRigNotHorny.leftMiddle.fingerBone3.position, color);
            }


            private Color GetAnimatedColor()
      {
        float time = Time.time;
        return new Color((float) ((double) Mathf.Sin(time * 2f) * 0.5 + 0.5), (float) ((double) Mathf.Sin(time * 1.5f) * 0.5 + 0.5), (float) ((double) Mathf.Sin(time * 2.5f) * 0.5 + 0.5));
      }

      private void ClearLineObjects()
      {
        foreach (Object lineObject in this.lineObjects)
          Object.Destroy(lineObject);
        this.lineObjects.Clear();
      }

      private GameObject CreateLineObject()
      {
        GameObject lineObject = new GameObject("LineObject");
        lineObject.transform.SetParent(((Component) this).transform);
        this.lineObjects.Add(lineObject);
        return lineObject;
      }

      private void DrawLine(Vector3 startPos, Vector3 endPos, Color color)
      {
        LineRenderer lineRenderer = this.CreateLineObject().AddComponent<LineRenderer>();
        ((Renderer) lineRenderer).material = new Material(Shader.Find("GUI/Text Shader"));
        lineRenderer.startColor = color;
        lineRenderer.endColor = color;
        lineRenderer.startWidth = this.lineWidth;
        lineRenderer.endWidth = this.lineWidth;
        lineRenderer.positionCount = 2;
        lineRenderer.SetPositions(new Vector3[2]
        {
          startPos,
          endPos
        });
      }
    }
  }
}
