﻿using TGSGhostt.Classes;
using TGSGhostt.Menu;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using TGSGhostts_Menu.Mods;
using TGSGhosttSettings;
using PlayFab.ClientModels;
using UnityEngine.UI;

namespace TGSGhostt.Mods
{
    internal class Configuration
    {
        public static int FlyChanger;
        public static int ArmChanger;
        public static int TagAuraChanger;
        public static int HeadSpeed;
        public static int MenuChanger;
        public static int MenuColorChanger;
        public static int OffButtonColorChanger;
        public static int OnButtonColorChanger;
        public static int BorderColorChanger;
        public static int OffTextColorChanger;
        public static int OnTextColorChanger;
        public static int WallWalkChanger;
        public static int HandTapChanger;
        public static int DisPos;
        public static int TracerPos;


        public static void ChangeFlySpeed()
        {
            ++Configuration.FlyChanger;
            switch (Configuration.FlyChanger)
            {
                case 0:
                    TGSGhostt.Mods.RigMods.FlySpeed = 8.5f;
                    Main.GetIndex("change fly speed").overlapText = "change fly speed: slow";
                    break;
                case 1:
                    TGSGhostt.Mods.RigMods.FlySpeed = 10f;
                    Main.GetIndex("change fly speed").overlapText = "change fly speed: fast";
                    break;
                case 2:
                    TGSGhostt.Mods.RigMods.FlySpeed = 15f;
                    Main.GetIndex("change fly speed").overlapText = "change fly speed: faster";
                    break;
                case 3:
                    TGSGhostt.Mods.RigMods.FlySpeed = 20f;
                    Main.GetIndex("change fly speed").overlapText = "change fly speed: super";
                    Configuration.FlyChanger = -1;
                    break;
            }
            Main.RecreateMenu();
        }

        public static void ChangeArmSize()
        {
            ++Configuration.ArmChanger;
            switch (Configuration.ArmChanger)
            {
                case 0:
                    TGSGhostt.Mods.RigMods.LongArmSize = 1.2f;
                    Main.GetIndex("change longarm size").overlapText = "change longarm size: normal";
                    break;
                case 1:
                    TGSGhostt.Mods.RigMods.LongArmSize = 1.5f;
                    Main.GetIndex("change longarm sIze").overlapText = "change longarm size: steam";
                    break;
                case 2:
                    TGSGhostt.Mods.RigMods.LongArmSize = 2f;
                    Main.GetIndex("change longarm size").overlapText = "change longarm size: long";
                    break;
                case 3:
                    TGSGhostt.Mods.RigMods.LongArmSize = 2.3f;
                    Main.GetIndex("change longarm size").overlapText = "change longarm size: really long";
                    Configuration.ArmChanger = -1;
                    break;
            }
            Main.RecreateMenu();
        }

        public static void ChangeTagAuraDistance()
        {
            ++Configuration.TagAuraChanger;
            switch (Configuration.TagAuraChanger)
            {
                case 0:
                    FunMods.TagChanger = 7f;
                    Main.GetIndex("change tag distance").overlapText = "change tag distance: normal";
                    break;
                case 1:
                    FunMods.TagChanger = 8.5f;
                    Main.GetIndex("change tag distance").overlapText = "change tag distance: close";
                    break;
                case 2:
                    FunMods.TagChanger = 9f;
                    Main.GetIndex("change tag distance").overlapText = "change tag distance: far";
                    break;
                case 3:
                    FunMods.TagChanger = 10.5f;
                    Main.GetIndex("change tag distance").overlapText = "change tag distance: really far";
                    Configuration.TagAuraChanger = -1;
                    break;
            }
            Main.RecreateMenu();
        }

        public static void ChangeHeadSpinSpeed()
        {
            ++Configuration.HeadSpeed;
            switch (Configuration.HeadSpeed)
            {
                case 0:
                    TGSGhostt.Mods.RigMods.HeadSpeed = 7f;
                    Main.GetIndex("change headspin speed").overlapText = "change headpin speed: slow";
                    break;
                case 1:
                    TGSGhostt.Mods.RigMods.HeadSpeed = 10f;
                    Main.GetIndex("change headspin speed").overlapText = "change headpin speed: normal";
                    break;
                case 2:
                    TGSGhostt.Mods.RigMods.HeadSpeed = 25f;
                    Main.GetIndex("change headspin speed").overlapText = "change headpin speed: fast";
                    break;
                case 3:
                    TGSGhostt.Mods.RigMods.HeadSpeed = 30f;
                    Main.GetIndex("change headspin speed").overlapText = "change headpin speed: super";
                    Configuration.HeadSpeed = -1;
                    break;
            }
            Main.RecreateMenu();
        }

        public static void ChangeMenuTheme()
        {
            ++Configuration.MenuChanger;
            if (Configuration.MenuChanger > 7)
            {
                Configuration.MenuChanger = 0;
            }

            switch (Configuration.MenuChanger)
            {
                case 0:
                    TGSGhosttSettings.SettingsforMenu.MenuColor = Color.gray;
                    TGSGhosttSettings.SettingsforMenu.buttonColorsOff = Color.black;
                    TGSGhosttSettings.SettingsforMenu.BorderColor = Color.black;
                    Main.GetIndex("change menu theme").overlapText = "change menu theme: 1";
                    break;
                case 1:
                    TGSGhosttSettings.SettingsforMenu.MenuColor = Color.black;
                    TGSGhosttSettings.SettingsforMenu.buttonColorsOff = Color.gray;
                    TGSGhosttSettings.SettingsforMenu.BorderColor = Color.gray;
                    Main.GetIndex("change menu theme").overlapText = "change menu theme: 2";
                    break;
                case 2:
                    TGSGhosttSettings.SettingsforMenu.MenuColor = Color.blue;
                    TGSGhosttSettings.SettingsforMenu.buttonColorsOff = Color.cyan;
                    TGSGhosttSettings.SettingsforMenu.BorderColor = Color.cyan;
                    Main.GetIndex("change menu theme").overlapText = "change menu theme: 3";
                    break;
                case 3:
                    TGSGhosttSettings.SettingsforMenu.MenuColor = Color.red;
                    TGSGhosttSettings.SettingsforMenu.buttonColorsOff = Color.gray;
                    TGSGhosttSettings.SettingsforMenu.BorderColor = Color.gray;
                    Main.GetIndex("change menu theme").overlapText = "change menu theme: 4";
                    break;
                case 4:
                    TGSGhosttSettings.SettingsforMenu.MenuColor = Color.magenta;
                    TGSGhosttSettings.SettingsforMenu.buttonColorsOff = Color.black;
                    TGSGhosttSettings.SettingsforMenu.BorderColor = Color.black;
                    Main.GetIndex("change menu theme").overlapText = "change menu theme: 5";
                    break;
                case 5:
                    TGSGhosttSettings.SettingsforMenu.MenuColor = Color.yellow;
                    TGSGhosttSettings.SettingsforMenu.buttonColorsOff = Color.blue;
                    TGSGhosttSettings.SettingsforMenu.BorderColor = Color.blue;
                    Main.GetIndex("change menu theme").overlapText = "change menu theme: 6";
                    break;
                case 6:
                    TGSGhosttSettings.SettingsforMenu.MenuColor = new Color32(100, 60, 210, 255);
                    TGSGhosttSettings.SettingsforMenu.buttonColorsOff = new Color32(100, 60, 210, 255);
                    TGSGhosttSettings.SettingsforMenu.BorderColor = new Color32(100, 60, 210, 255);
                    Main.GetIndex("change menu theme").overlapText = "change menu theme: 7";
                    break;
                case 7:
                    TGSGhosttSettings.SettingsforMenu.MenuColor = Color.green;
                    TGSGhosttSettings.SettingsforMenu.buttonColorsOff = Color.red;
                    TGSGhosttSettings.SettingsforMenu.BorderColor = Color.red;
                    Main.GetIndex("change menu theme").overlapText = "change menu theme: 8";
                    Configuration.MenuChanger = -1;
                    break;
            }
            Main.RecreateMenu();
        }


        public static void ChangeMenuColor()
        {
            ++Configuration.MenuColorChanger;
            switch (Configuration.MenuColorChanger)
            {
                case 0:
                    TGSGhosttSettings.SettingsforMenu.MenuColor = Color.gray;
                    Main.GetIndex("change menu color").overlapText = "change menu color: gray";
                    break;
                case 1:
                    TGSGhosttSettings.SettingsforMenu.MenuColor = Color.black;
                    Main.GetIndex("change menu color").overlapText = "change menu color: black";
                    break;
                case 2:
                    TGSGhosttSettings.SettingsforMenu.MenuColor = Color.blue;
                    Main.GetIndex("change menu color").overlapText = "change menu color: blue";
                    break;
                case 3:
                    TGSGhosttSettings.SettingsforMenu.MenuColor = Color.red;
                    Main.GetIndex("change menu color").overlapText = "change menu color: red";
                    break;
                case 4:
                    TGSGhosttSettings.SettingsforMenu.MenuColor = Color.magenta;
                    Main.GetIndex("change menu color").overlapText = "change menu color: magenta";
                    break;
                case 5:
                    TGSGhosttSettings.SettingsforMenu.MenuColor = Color.yellow;
                    Main.GetIndex("change menu color").overlapText = "change menu color: yellow";
                    break;
                case 6:
                    TGSGhosttSettings.SettingsforMenu.MenuColor = Color.green;
                    Main.GetIndex("change menu color").overlapText = "change menu color: purple";
                    break;
                case 7:
                    TGSGhosttSettings.SettingsforMenu.MenuColor = Color.cyan;
                    Main.GetIndex("change menu color").overlapText = "change menu color: cyan";
                    break;
                case 8:
                    TGSGhosttSettings.SettingsforMenu.MenuColor = new Color32(100, 60, 210, 255);
                    Main.GetIndex("change menu color").overlapText = "change menu color: purple";
                    Configuration.MenuColorChanger = -1;
                    break;
            }
            Main.RecreateMenu();
        }

        public static void ChangeOffButtonColor()
        {
            ++Configuration.OffButtonColorChanger;
            switch (Configuration.OffButtonColorChanger)
            {
                case 0:
                    TGSGhosttSettings.SettingsforMenu.buttonColorsOff = Color.gray;
                    Main.GetIndex("change off button color").overlapText = "change off button color: gray";
                    break;
                case 1:
                    TGSGhosttSettings.SettingsforMenu.buttonColorsOff = Color.black;
                    TGSGhosttSettings.SettingsforMenu.TextColorOff = Color.white;
                    Main.GetIndex("change off button color").overlapText = "change off button color: black";
                    break;
                case 2:
                    TGSGhosttSettings.SettingsforMenu.buttonColorsOff = Color.blue;
                    Main.GetIndex("change off button color").overlapText = "change off button color: blue";
                    break;
                case 3:
                    TGSGhosttSettings.SettingsforMenu.buttonColorsOff = Color.red;
                    Main.GetIndex("change off button color").overlapText = "change off button color: red";
                    break;
                case 4:
                    TGSGhosttSettings.SettingsforMenu.buttonColorsOff = Color.magenta;
                    Main.GetIndex("change off button color").overlapText = "change off button color: magenta";
                    break;
                case 5:
                    TGSGhosttSettings.SettingsforMenu.buttonColorsOff = Color.yellow;
                    Main.GetIndex("change off button color").overlapText = "change off button color: yellow";
                    break;
                case 6:
                    TGSGhosttSettings.SettingsforMenu.buttonColorsOff = Color.green;
                    Main.GetIndex("change off button color").overlapText = "change off button color: green";
                    break;
                case 7:
                    TGSGhosttSettings.SettingsforMenu.buttonColorsOff = Color.cyan;
                    Main.GetIndex("change off button color").overlapText = "change off button color: cyan";
                    break;
                case 8:
                    TGSGhosttSettings.SettingsforMenu.buttonColorsOff = Color.white;
                    Main.GetIndex("change off button color").overlapText = "change off button color: white";
                    TGSGhosttSettings.SettingsforMenu.TextColorOff = Color.black;
                    Configuration.OffButtonColorChanger = -1;
                    break;
            }
            Main.RecreateMenu();
        }

        public static void ChangeOnButtonColor()
        {
            ++Configuration.OnButtonColorChanger;
            switch (Configuration.OnButtonColorChanger)
            {
                case 0:
                    TGSGhosttSettings.SettingsforMenu.buttonColorsOn = Color.gray;
                    Main.GetIndex("change on button color").overlapText = "change on button color: ray";
                    break;
                case 1:
                    TGSGhosttSettings.SettingsforMenu.buttonColorsOn = Color.black;
                    TGSGhosttSettings.SettingsforMenu.TextColorOff = Color.white;
                    Main.GetIndex("change on button color").overlapText = "change on button color: black";
                    break;
                case 2:
                    TGSGhosttSettings.SettingsforMenu.buttonColorsOn = Color.blue;
                    Main.GetIndex("change on button color").overlapText = "change on button color: blue";
                    break;
                case 3:
                    TGSGhosttSettings.SettingsforMenu.buttonColorsOn = Color.red;
                    Main.GetIndex("change on button color").overlapText = "change on button color: red";
                    break;
                case 4:
                    TGSGhosttSettings.SettingsforMenu.buttonColorsOn = Color.magenta;
                    Main.GetIndex("change on button color").overlapText = "change on button color: magenta";
                    break;
                case 5:
                    TGSGhosttSettings.SettingsforMenu.buttonColorsOn = Color.yellow;
                    Main.GetIndex("change on button color").overlapText = "change on button color: yellow";
                    break;
                case 6:
                    TGSGhosttSettings.SettingsforMenu.buttonColorsOn = Color.green;
                    Main.GetIndex("change on button color").overlapText = "change on button color: green";
                    break;
                case 7:
                    TGSGhosttSettings.SettingsforMenu.buttonColorsOn = Color.cyan;
                    Main.GetIndex("change on button color").overlapText = "change on button color: cyan";
                    break;
                case 8:
                    TGSGhosttSettings.SettingsforMenu.buttonColorsOn = Color.white;
                    TGSGhosttSettings.SettingsforMenu.TextColorOff = Color.black;
                    Main.GetIndex("change on button color").overlapText = "change on button color: white";
                    Configuration.OnButtonColorChanger = -1;
                    break;
            }
            Main.RecreateMenu();
        }

        public static void ChangeBorderColor()
        {
            ++Configuration.BorderColorChanger;
            switch (Configuration.BorderColorChanger)
            {
                case 0:
                    TGSGhosttSettings.SettingsforMenu.BorderColor = Color.gray;
                    Main.GetIndex("change border color").overlapText = "change border color: gray";
                    break;
                case 1:
                    TGSGhosttSettings.SettingsforMenu.BorderColor = Color.black;
                    Main.GetIndex("change border color").overlapText = "change border color: black";
                    break;
                case 2:
                    TGSGhosttSettings.SettingsforMenu.BorderColor = Color.blue;
                    Main.GetIndex("change border color").overlapText = "change border color: blue";
                    break;
                case 3:
                    TGSGhosttSettings.SettingsforMenu.BorderColor = Color.red;
                    Main.GetIndex("change border color").overlapText = "change border color: red";
                    break;
                case 4:
                    TGSGhosttSettings.SettingsforMenu.BorderColor = Color.magenta;
                    Main.GetIndex("change border color").overlapText = "change border color: magenta";
                    break;
                case 5:
                    TGSGhosttSettings.SettingsforMenu.BorderColor = Color.yellow;
                    Main.GetIndex("change border color").overlapText = "change border color: yellow";
                    break;
                case 6:
                    TGSGhosttSettings.SettingsforMenu.BorderColor = Color.green;
                    Main.GetIndex("change border color").overlapText = "change border color: green";
                    break;
                case 7:
                    TGSGhosttSettings.SettingsforMenu.BorderColor = Color.cyan;
                    Main.GetIndex("change border color").overlapText = "change border color: cyan";
                    break;
                case 8:
                    TGSGhosttSettings.SettingsforMenu.BorderColor = new Color32(100, 60, 210, 255);
                    Main.GetIndex("change border color").overlapText = "change border color: purple";
                    Configuration.BorderColorChanger = -1;
                    break;
            }
            Main.RecreateMenu();
        }


        public static void ChangeOffTextColor()
        {
            ++Configuration.OffTextColorChanger;
            switch (Configuration.OffTextColorChanger)
            {
                case 0:
                    TGSGhosttSettings.SettingsforMenu.TextColorOff = Color.gray;
                    Main.GetIndex("change off text color").overlapText = "change off text color: gray";
                    break;
                case 1:
                    TGSGhosttSettings.SettingsforMenu.TextColorOff = Color.black;
                    Main.GetIndex("change off text color").overlapText = "change off text color: black";
                    break;
                case 2:
                    TGSGhosttSettings.SettingsforMenu.TextColorOff = Color.blue;
                    Main.GetIndex("change off text color").overlapText = "change off text color: blue";
                    break;
                case 3:
                    TGSGhosttSettings.SettingsforMenu.TextColorOff = Color.red;
                    Main.GetIndex("change off text color").overlapText = "change off text color: red";
                    break;
                case 4:
                    TGSGhosttSettings.SettingsforMenu.TextColorOff = Color.magenta;
                    Main.GetIndex("change off text color").overlapText = "change off text color: magenta";
                    break;
                case 5:
                    TGSGhosttSettings.SettingsforMenu.TextColorOff = Color.yellow;
                    Main.GetIndex("change off text color").overlapText = "change off text color: yellow";
                    break;
                case 6:
                    TGSGhosttSettings.SettingsforMenu.TextColorOff = Color.green;
                    Main.GetIndex("change off text color").overlapText = "change off text color: green";
                    break;
                case 7:
                    TGSGhosttSettings.SettingsforMenu.TextColorOff = Color.cyan;
                    Main.GetIndex("change off text color").overlapText = "change off text color: cyan";
                    break;
                case 8:
                    TGSGhosttSettings.SettingsforMenu.TextColorOff = new Color32(100, 60, 210, 255);
                    Main.GetIndex("change off text color").overlapText = "change off text color: purple";
                    Configuration.OffTextColorChanger = -1;
                    break;
            }
            Main.RecreateMenu();
        }

        public static void ChangeOnTextColor()
        {
            ++Configuration.OnTextColorChanger;
            switch (Configuration.OnTextColorChanger)
            {
                case 0:
                    TGSGhosttSettings.SettingsforMenu.TextColorOn = Color.gray;
                    Main.GetIndex("change on text color").overlapText = "change on text color: gray";
                    break;
                case 1:
                    TGSGhosttSettings.SettingsforMenu.TextColorOn = Color.black;
                    Main.GetIndex("change on text color").overlapText = "change on text color: black";

                    break;
                case 2:
                    TGSGhosttSettings.SettingsforMenu.TextColorOn = Color.blue;
                    Main.GetIndex("change on text color").overlapText = "change on text color: blue";

                    break;
                case 3:
                    TGSGhosttSettings.SettingsforMenu.TextColorOn = Color.red;
                    Main.GetIndex("change on text color").overlapText = "change on text color: red";

                    break;
                case 4:
                    TGSGhosttSettings.SettingsforMenu.TextColorOn = Color.magenta;
                    Main.GetIndex("change on text color").overlapText = "change on text color: magenta";

                    break;
                case 5:
                    TGSGhosttSettings.SettingsforMenu.TextColorOn = Color.yellow;
                    Main.GetIndex("change on text color").overlapText = "change on text color: yellow";

                    break;
                case 6:
                    TGSGhosttSettings.SettingsforMenu.TextColorOn = Color.green;
                    Main.GetIndex("change on text color").overlapText = "change on text color: green";

                    break;
                case 7:
                    TGSGhosttSettings.SettingsforMenu.TextColorOn = Color.cyan;
                    Main.GetIndex("change on text color").overlapText = "change on text color: cyan";

                    break;
                case 8:
                    TGSGhosttSettings.SettingsforMenu.TextColorOn = new Color32(100, 60, 210, 255);
                    Main.GetIndex("change on text color").overlapText = "change on text color: purple";

                    Configuration.OnTextColorChanger = -1;
                    break;
            }
            Main.RecreateMenu();
        }

        public static void ChangeWallWalk()
        {
            ++Configuration.WallWalkChanger;
            switch (Configuration.WallWalkChanger)
            {
                case 0:
                    TGSGhostt.Mods.RigMods.WallWalkForce = -10f;
                    Main.GetIndex("change wall walk").overlapText = "change wall walk: normal";
                    break;
                case 1:
                    TGSGhostt.Mods.RigMods.WallWalkForce = -15f;
                    Main.GetIndex("change wall walk").overlapText = "change wall walk: weak";
                    break;
                case 2:
                    TGSGhostt.Mods.RigMods.WallWalkForce = -20f;
                    Main.GetIndex("change wall walk").overlapText = "change wall walk: fine";
                    break;
                case 3:
                    TGSGhostt.Mods.RigMods.WallWalkForce = -25f;
                    Main.GetIndex("change wall walk").overlapText = "change wall walk: finer";
                    break;
                case 4:
                    TGSGhostt.Mods.RigMods.WallWalkForce = -30f;
                    Main.GetIndex("change wall walk").overlapText = "change wall walk: strong";
                    break;
                case 5:
                    TGSGhostt.Mods.RigMods.WallWalkForce = -35f;
                    Main.GetIndex("change wall walk").overlapText = "change wall walk: stronger";
                    Configuration.WallWalkChanger = -1;
                    break;
            }
            Main.RecreateMenu();
        }

        public static void ChangeHandTap()
        {
            ++Configuration.HandTapChanger;
            switch (Configuration.HandTapChanger)
            {
                case 0:
                    TGSGhostt.Mods.RigMods.HandTapVolume = 0.0f;
                    Main.GetIndex("change handtaps").overlapText = "change handtaps: none";
                    break;
                case 1:
                    TGSGhostt.Mods.RigMods.HandTapVolume = 0.1f;
                    Main.GetIndex("change handtaps").overlapText = "change handtaps: normal";
                    break;
                case 2:
                    TGSGhostt.Mods.RigMods.HandTapVolume = 0.5f;
                    Main.GetIndex("change handtaps").overlapText = "change handtaps: lil loud";
                    break;
                case 3:
                    TGSGhostt.Mods.RigMods.WallWalkForce = 1f;
                    Main.GetIndex("change handtaps").overlapText = "change handtaps: louder";
                    Configuration.HandTapChanger = -1;
                    break;
            }
            Main.RecreateMenu();
        }

        public static void ChangeDisconnectPosition()
        {
            ++Configuration.DisPos;
            switch (Configuration.DisPos)
            {
                case 0:
                    SettingsforMenu.disconnectbuttonTop = true;
                    SettingsforMenu.disconnectbuttonRight = false;
                    SettingsforMenu.disconnectbuttonLeft = false;
                    SettingsforMenu.disconnectbuttonBottom = false;
                    Main.GetIndex("change disconnect pos").overlapText = "change disconnect pos: top";
                    break;
                case 1:
                    SettingsforMenu.disconnectbuttonTop = false;
                    SettingsforMenu.disconnectbuttonRight = false;
                    SettingsforMenu.disconnectbuttonLeft = false;
                    SettingsforMenu.disconnectbuttonBottom = true;
                    Main.GetIndex("change disconnect pos").overlapText = "change disconnect pos: bottom";
                    break;
                case 2:
                    SettingsforMenu.disconnectbuttonTop = false;
                    SettingsforMenu.disconnectbuttonRight = false;
                    SettingsforMenu.disconnectbuttonLeft = true;
                    SettingsforMenu.disconnectbuttonBottom = false;
                    Main.GetIndex("change disconnect pos").overlapText = "change disconnect pos: right";
                    break;
                case 3:
                    SettingsforMenu.disconnectbuttonTop = false;
                    SettingsforMenu.disconnectbuttonRight = true;
                    SettingsforMenu.disconnectbuttonLeft = false;
                    SettingsforMenu.disconnectbuttonBottom = false;
                    Main.GetIndex("change disconnect pos").overlapText = "change disconnect pos: left";
                    Configuration.DisPos = -1;
                    break;
            }
            Main.RecreateMenu();
        }

        public static void ChangeTrcaerPos()
        {
            ++Configuration.TracerPos;
            switch (Configuration.TracerPos)
            {
                case 0:
                    Main.GetIndex("change tracer pos").overlapText = "change tracer pos: right hand";
                    VisualMods.TracerPos = GorillaLocomotion.Player.Instance.rightControllerTransform;
                    break;
                case 1:
                    Main.GetIndex("change tracer pos").overlapText = "change tracer pos: left hand";
                    VisualMods.TracerPos = GorillaLocomotion.Player.Instance.leftControllerTransform;
                    break;
                case 2:
                    Main.GetIndex("change tracer pos").overlapText = "change tracer pos: head";
                    VisualMods.TracerPos = GorillaLocomotion.Player.Instance.headCollider.transform;
                    break;
                case 3:
                    Main.GetIndex("change tracer pos").overlapText = "change tracer pos: stomach";
                    VisualMods.TracerPos = GorillaLocomotion.Player.Instance.bodyCollider.transform;
                    Configuration.TracerPos = -1;
                    break;
            }
            Main.RecreateMenu();
        }
    }
}
