﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace TGSGhostts_Menu.Mods
{
    internal class YoutubeChannels
    {
        public static void YoutubeChannel(int q)
        {
            if (q > 2)
            {
                q = 0;
            }
            else
            Process.Start(YoutubeChannelsList[q]);
        }
    
        public static string[] YoutubeChannelsList = new string[] 
        {
            "https://www.youtube.com/@wqsusapphire",//Sapphire 0
            "https://www.youtube.com/@ACE.ghost445",//Ace.Ghost 1
            "https://www.youtube.com/@504brandon",//504Brandon 2
        };
        //new ButtonInfo { buttonText = "ChannelNameHere", method =() => YoutubeChannel(0), IsToggable = false},
    }
}
