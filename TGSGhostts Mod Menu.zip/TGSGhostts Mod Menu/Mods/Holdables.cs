﻿using GorillaLocomotion;
using System;
using System.Collections;
using UnityEngine;
using UnityEngine.XR;
using static TGSGhostts_Menu.Classes.GunLib;
using Object = UnityEngine.Object;

#nullable disable
namespace TGSGhostts_Menu.Mods
{
    internal class Holdables
    {
        private static IEnumerator DestroyAfterDelay()
        {
            yield return new WaitForSeconds(0.5f);
            if (GunLibShit.GunMain != null)
                Object.Destroy(GunLibShit.GunMain);
            if (GunLibShit.LineMain != null)
                Object.Destroy(GunLibShit.LineMain.gameObject);
        }

        public static void BugGun()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab ||
                !Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up,
                                 -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit))
            {
                return;
            }

            if (GunLibShit.GunMain != null)
                GunLibShit.DestroyObject(GunLibShit.GunMain);

            if (GunLibShit.LineMain != null)
                GunLibShit.DestroyObject(GunLibShit.LineMain.gameObject);

            GunLibShit.GunMain = GunLibShit.CreateGun(raycastHit.point, Color.blue, 0.1f);

            GunLibShit.LineMain = GunLibShit.CreateLine(
                GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R").transform.position,
                raycastHit.point,
                Color.blue,
                0.025f
            );

            if (ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.0f)
            {
                GameObject BugShit = GameObject.Find("Floating Bug Holdable");
                if (BugShit != null)
                {
                    BugShit.transform.position = GunLibShit.GunMain.transform.position;
                }
            }

            GorillaLocomotion.Player.Instance.StartCoroutine(GunLibShit.DestroyAfterDelay(GunLibShit.GunMain, 5f));
        }

        public static void BatGun()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab ||
                !Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up,
                                 -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit))
            {
                return;
            }

            if (GunLibShit.GunMain != null)
                GunLibShit.DestroyObject(GunLibShit.GunMain);

            if (GunLibShit.LineMain != null)
                GunLibShit.DestroyObject(GunLibShit.LineMain.gameObject);

            GunLibShit.GunMain = GunLibShit.CreateGun(raycastHit.point, Color.blue, 0.1f);

            GunLibShit.LineMain = GunLibShit.CreateLine(
                GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R").transform.position,
                raycastHit.point,
                Color.blue,
                0.025f
            );

            if (ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.0f)
            {
                GameObject BatShit = GameObject.Find("Cave Bat Holdable");
                if (BatShit != null)
                {
                    BatShit.transform.position = GunLibShit.GunMain.transform.position;
                }
            }

            GorillaLocomotion.Player.Instance.StartCoroutine(GunLibShit.DestroyAfterDelay(GunLibShit.GunMain, 5f));
        }

        public static void BeachBallGun()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab || !Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up,
                                 -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit))
            {
                return;
            }

            if (GunLibShit.GunMain != null)
                Object.Destroy(GunLibShit.GunMain);
            if (GunLibShit.LineMain != null)
                Object.Destroy(GunLibShit.LineMain.gameObject);
            GunLibShit.GunMain = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            GunLibShit.GunMain.GetComponent<Renderer>().material.color = Color.blue;
            GunLibShit.GunMain.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
            GunLibShit.GunMain.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            GunLibShit.GunMain.transform.position = raycastHit.point;
            Object.Destroy(GunLibShit.GunMain.GetComponent<BoxCollider>());
            Object.Destroy(GunLibShit.GunMain.GetComponent<Rigidbody>());
            Object.Destroy(GunLibShit.GunMain.GetComponent<Collider>());
            GunLibShit.LineMain = new GameObject("Line").AddComponent<LineRenderer>();
            GunLibShit.LineMain.startColor = Color.blue;
            GunLibShit.LineMain.endColor = Color.blue;
            GunLibShit.LineMain.startWidth = 0.025f;
            GunLibShit.LineMain.endWidth = 0.025f;
            GunLibShit.LineMain.positionCount = 2;
            GunLibShit.LineMain.useWorldSpace = true;
            GunLibShit.LineMain.SetPosition(0, GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R").transform.position);
            GunLibShit.LineMain.SetPosition(1, raycastHit.point);
            GunLibShit.LineMain.material.shader = Shader.Find("GUI/Text Shader");

            if (ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.0f)
            {
                if (GameObject.Find("Beachball") != null)
                {
                    GameObject.Find("Beachball").transform.position = GunLibShit.GunMain.transform.position;
                }
            }
            GorillaLocomotion.Player.Instance.StartCoroutine(DestroyAfterDelay());
        }



        public static void GrabBug()
        {
            if (!ControllerInputPoller.instance.rightGrab)
                return;
            GameObject.Find("Floating Bug Holdable").transform.position = GorillaTagger.Instance.rightHandTransform.position;
        }

        public static void GrabBat()
        {
            if (!ControllerInputPoller.instance.rightGrab)
                return;
            GameObject.Find("Cave Bat Holdable").transform.position = GorillaTagger.Instance.rightHandTransform.position;
        }
        
        public static void GrabBeachBall()
        {
            if (!ControllerInputPoller.instance.rightGrab)
                return;
            GameObject.Find("BeachBall").transform.position = GorillaTagger.Instance.rightHandTransform.position;
        }


        public static void GrabMonsters()
        {
            if (ControllerInputPoller.instance.rightGrab)
                foreach (MonkeyeAI Monsters in UnityEngine.Object.FindObjectsOfType<MonkeyeAI>())
                {
                    Monsters.transform.position = GorillaTagger.Instance.rightHandTransform.position;
                }
               if (ControllerInputPoller.instance.leftGrab)
                foreach (MonkeyeAI Monsters in UnityEngine.Object.FindObjectsOfType<MonkeyeAI>())
                {
                    Monsters.transform.position = GorillaTagger.Instance.leftHandTransform.position;
                }
        }


        public static void OrbitBug()
        {
            float OrbitSpeed = 0.1f;
            float OrbitRadius = 0.9f;
            (GameObject.Find("Floating Bug Holdable").GetComponent<ThrowableBug>()).WorldShareableRequestOwnership();
            Vector3 HeadPos = GorillaTagger.Instance.headCollider.transform.position;
            float Shit = Time.frameCount * OrbitSpeed;
            float x = Mathf.Cos(Shit) * OrbitRadius;
            float z = Mathf.Sin(Shit) * OrbitRadius;
            GameObject.Find("Floating Bug Holdable").transform.position = HeadPos + new Vector3(x, 0, z);
        }

        public static void OrbitBat()
        {
            float OrbitSpeed = 0.1f;
            float OrbitRadius = 0.9f;
            (GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>()).WorldShareableRequestOwnership();
            Vector3 HeadPos = GorillaTagger.Instance.headCollider.transform.position;
            float Shit = Time.frameCount * OrbitSpeed;
            float x = Mathf.Cos(Shit) * OrbitRadius;
            float z = Mathf.Sin(Shit) * OrbitRadius;
            GameObject.Find("Cave Bat Holdable").transform.position = HeadPos + new Vector3(x, 0, z);
        }


        public static void OrbitMonster()
        {
            float OrbitSpeed = 0.1f;
            float OrbitRadius = 0.9f;
            Vector3 HeadPos = GorillaTagger.Instance.headCollider.transform.position;
            foreach (MonkeyeAI Monsters in Object.FindObjectsOfType<MonkeyeAI>())
            {
                float Shit = Time.frameCount * OrbitSpeed;
                float x = Mathf.Cos(Shit) * OrbitRadius;
                float z = Mathf.Sin(Shit) * OrbitRadius;
                Monsters.transform.position = HeadPos + new Vector3(x, 0, z);
            }
        }


    }
}
