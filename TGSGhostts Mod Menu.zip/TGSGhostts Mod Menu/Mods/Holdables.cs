﻿using GorillaLocomotion;
using System;
using System.Collections;
using UnityEngine;
using UnityEngine.XR;
using Object = UnityEngine.Object;

#nullable disable
namespace TGSGhostts_Menu.Mods
{
    internal class Holdables
    {
        public static VRRig PlayerGun;
        private static GameObject GunMain;
        private static LineRenderer LineMain;
        public static Color GunPointerColor1 = Color.magenta;
        public static GameObject pointer = null;


        private static IEnumerator DestroyAfterDelay()
        {
            yield return new WaitForSeconds(0.5f);
            if (FunMods.GunMain != null)
                Object.Destroy(FunMods.GunMain);
            if (FunMods.LineMain != null)
                Object.Destroy(FunMods.LineMain.gameObject);
        }

        public static void BugGun()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab || !Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up,
                                 -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit))
            {
                return;
            }

            if (FunMods.GunMain != null)
                Object.Destroy(FunMods.GunMain);
            if (FunMods.LineMain != null)
                Object.Destroy(FunMods.LineMain.gameObject);
            FunMods.GunMain = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            FunMods.GunMain.GetComponent<Renderer>().material.color = Color.blue;
            FunMods.GunMain.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
            FunMods.GunMain.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            FunMods.GunMain.transform.position = raycastHit.point;
            Object.Destroy(FunMods.GunMain.GetComponent<BoxCollider>());
            Object.Destroy(FunMods.GunMain.GetComponent<Rigidbody>());
            Object.Destroy(FunMods.GunMain.GetComponent<Collider>());
            FunMods.LineMain = new GameObject("Line").AddComponent<LineRenderer>();
            FunMods.LineMain.startColor = Color.blue;
            FunMods.LineMain.endColor = Color.blue;
            FunMods.LineMain.startWidth = 0.025f;
            FunMods.LineMain.endWidth = 0.025f;
            FunMods.LineMain.positionCount = 2;
            FunMods.LineMain.useWorldSpace = true;
            FunMods.LineMain.SetPosition(0, GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R").transform.position);
            FunMods.LineMain.SetPosition(1, raycastHit.point);
            FunMods.LineMain.material.shader = Shader.Find("GUI/Text Shader");

            if (ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.0f)
            {
                if (GameObject.Find("Floating Bug Holdable") != null)
                {
                    GameObject.Find("Floating Bug Holdable").transform.position = FunMods.GunMain.transform.position;
                }
            }
            GorillaLocomotion.Player.Instance.StartCoroutine(DestroyAfterDelay());
        }


        public static void BatGun()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab || !Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up,
                                 -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit))
            {
                return;
            }

            if (FunMods.GunMain != null)
                Object.Destroy(FunMods.GunMain);
            if (FunMods.LineMain != null)
                Object.Destroy(FunMods.LineMain.gameObject);
            FunMods.GunMain = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            FunMods.GunMain.GetComponent<Renderer>().material.color = Color.blue;
            FunMods.GunMain.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
            FunMods.GunMain.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            FunMods.GunMain.transform.position = raycastHit.point;
            Object.Destroy(FunMods.GunMain.GetComponent<BoxCollider>());
            Object.Destroy(FunMods.GunMain.GetComponent<Rigidbody>());
            Object.Destroy(FunMods.GunMain.GetComponent<Collider>());
            FunMods.LineMain = new GameObject("Line").AddComponent<LineRenderer>();
            FunMods.LineMain.startColor = Color.blue;
            FunMods.LineMain.endColor = Color.blue;
            FunMods.LineMain.startWidth = 0.025f;
            FunMods.LineMain.endWidth = 0.025f;
            FunMods.LineMain.positionCount = 2;
            FunMods.LineMain.useWorldSpace = true;
            FunMods.LineMain.SetPosition(0, GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R").transform.position);
            FunMods.LineMain.SetPosition(1, raycastHit.point);
            FunMods.LineMain.material.shader = Shader.Find("GUI/Text Shader");

            if (ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.0f)
            {
                if (GameObject.Find("Cave Bat Holdable") != null)
                {
                    GameObject.Find("Cave Bat Holdable").transform.position = FunMods.GunMain.transform.position;
                }
            }
            GorillaLocomotion.Player.Instance.StartCoroutine(DestroyAfterDelay());
        }

        public static void BeachBallGun()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab || !Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up,
                                 -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit))
            {
                return;
            }

            if (FunMods.GunMain != null)
                Object.Destroy(FunMods.GunMain);
            if (FunMods.LineMain != null)
                Object.Destroy(FunMods.LineMain.gameObject);
            FunMods.GunMain = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            FunMods.GunMain.GetComponent<Renderer>().material.color = Color.blue;
            FunMods.GunMain.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
            FunMods.GunMain.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            FunMods.GunMain.transform.position = raycastHit.point;
            Object.Destroy(FunMods.GunMain.GetComponent<BoxCollider>());
            Object.Destroy(FunMods.GunMain.GetComponent<Rigidbody>());
            Object.Destroy(FunMods.GunMain.GetComponent<Collider>());
            FunMods.LineMain = new GameObject("Line").AddComponent<LineRenderer>();
            FunMods.LineMain.startColor = Color.blue;
            FunMods.LineMain.endColor = Color.blue;
            FunMods.LineMain.startWidth = 0.025f;
            FunMods.LineMain.endWidth = 0.025f;
            FunMods.LineMain.positionCount = 2;
            FunMods.LineMain.useWorldSpace = true;
            FunMods.LineMain.SetPosition(0, GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R").transform.position);
            FunMods.LineMain.SetPosition(1, raycastHit.point);
            FunMods.LineMain.material.shader = Shader.Find("GUI/Text Shader");

            if (ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.0f)
            {
                if (GameObject.Find("Beachball") != null)
                {
                    GameObject.Find("Beachball").transform.position = FunMods.GunMain.transform.position;
                }
            }
            GorillaLocomotion.Player.Instance.StartCoroutine(DestroyAfterDelay());
        }


        public static void GrabBug()
        {
            if (!ControllerInputPoller.instance.rightGrab)
                return;
            GameObject.Find("Floating Bug Holdable").transform.position = GorillaTagger.Instance.rightHandTransform.position;
        }

        public static void GrabBat()
        {
            if (!ControllerInputPoller.instance.rightGrab)
                return;
            GameObject.Find("Cave Bat Holdable").transform.position = GorillaTagger.Instance.rightHandTransform.position;
        }
        
        public static void GrabBeachBall()
        {
            if (!ControllerInputPoller.instance.rightGrab)
                return;
            GameObject.Find("BeachBall").transform.position = GorillaTagger.Instance.rightHandTransform.position;
        }


        public static void GrabMonsters()
        {
            if (ControllerInputPoller.instance.rightGrab)
                foreach (MonkeyeAI Monsters in UnityEngine.Object.FindObjectsOfType<MonkeyeAI>())
                {
                    Monsters.transform.position = GorillaTagger.Instance.rightHandTransform.position;
                }
               if (ControllerInputPoller.instance.leftGrab)
                foreach (MonkeyeAI Monsters in UnityEngine.Object.FindObjectsOfType<MonkeyeAI>())
                {
                    Monsters.transform.position = GorillaTagger.Instance.leftHandTransform.position;
                }
        }

        public static void OrbitBug()
        {
            float OrbitSpeed = 0.1f;
            float OrbitRadius = 0.9f;
            (GameObject.Find("Floating Bug Holdable").GetComponent<ThrowableBug>()).WorldShareableRequestOwnership();
            Vector3 HeadPos = GorillaTagger.Instance.headCollider.transform.position;
            float Shit = Time.frameCount * OrbitSpeed;
            float x = Mathf.Cos(Shit) * OrbitRadius;
            float z = Mathf.Sin(Shit) * OrbitRadius;
            GameObject.Find("Floating Bug Holdable").transform.position = HeadPos + new Vector3(x, 0, z);
        }

        public static void OrbitBat()
        {
            float OrbitSpeed = 0.1f;
            float OrbitRadius = 0.9f;
            (GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>()).WorldShareableRequestOwnership();
            Vector3 HeadPos = GorillaTagger.Instance.headCollider.transform.position;
            float Shit = Time.frameCount * OrbitSpeed;
            float x = Mathf.Cos(Shit) * OrbitRadius;
            float z = Mathf.Sin(Shit) * OrbitRadius;
            GameObject.Find("Cave Bat Holdable").transform.position = HeadPos + new Vector3(x, 0, z);
        }


        public static void OrbitMonster()
        {
            float OrbitSpeed = 0.1f;
            float OrbitRadius = 0.9f;
            Vector3 HeadPos = GorillaTagger.Instance.headCollider.transform.position;
            foreach (MonkeyeAI Monsters in Object.FindObjectsOfType<MonkeyeAI>())
            {
                float Shit = Time.frameCount * OrbitSpeed;
                float x = Mathf.Cos(Shit) * OrbitRadius;
                float z = Mathf.Sin(Shit) * OrbitRadius;
                Monsters.transform.position = HeadPos + new Vector3(x, 0, z);
            }
        }

    }
}
