﻿using GorillaLocomotion;
using GorillaNetworking;
using Oculus.Platform.Models;
using Photon.Pun;
using PlayFab.ClientModels;
using System.Collections;
using TGSGhostt.Menu;
using TGSGhostt.Mods;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.XR;
using TGSGhostt.Notifications;
using static TGSGhostts_Menu.Classes.GunLib;
#nullable disable
namespace TGSGhostts_Menu.Mods
{
    internal class CheatMods
    {
        public static VRRig GunShit = null;
        private static GameObject GunPointer1;
        private static LineRenderer liner6;
        public static Color GunPointerColor1 = Color.magenta;
        public static VRRig GunLockRig;
        public static void JoinLastRoom()
        {
            if (!PhotonNetwork.InRoom)
            {
                PhotonNetworkController.Instance.AttemptToJoinSpecificRoom(Main.CurrentRoom, JoinType.Solo);
                NotifiLib.SendNotification("<color=purple>JOINING ROOM: </color>" + Main.CurrentRoom);
            }
            else if (Main.CurrentRoom == "")
            {
                NotifiLib.SendNotification("<color=purple>ERROR! HAS NOT BEEN IN A ROOM.</color>");
            }
            else if (PhotonNetwork.InRoom)
            {
                NotifiLib.SendNotification("<color=purple>ERROR! IN A ROOM</color>");
            }
        }
        public static void GiveWater()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab ||
                !Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position,
                                 -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit))
            {
                return;
            }
            if (GunLibShit.GunMain != null)
                Object.Destroy(GunLibShit.GunMain);
            if (GunLibShit.LineMain != null)
                Object.Destroy(GunLibShit.LineMain.gameObject);
            GunLibShit.GunMain = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            GunLibShit.GunMain.GetComponent<Renderer>().material.color = Color.blue;
            GunLibShit.GunMain.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            GunLibShit.GunMain.transform.position = raycastHit.point;
            Object.Destroy(GunLibShit.GunMain.GetComponent<Collider>());
            Object.Destroy(GunLibShit.GunMain.GetComponent<Rigidbody>());
            GunLibShit.LineMain = new GameObject("Line").AddComponent<LineRenderer>();
            GunLibShit.LineMain.startColor = Color.blue;
            GunLibShit.LineMain.endColor = Color.blue;
            GunLibShit.LineMain.startWidth = 0.025f;
            GunLibShit.LineMain.endWidth = 0.025f;
            GunLibShit.LineMain.positionCount = 2;
            GunLibShit.LineMain.useWorldSpace = true;
            Transform handTransform = GorillaLocomotion.Player.Instance.rightControllerTransform;
            GunLibShit.LineMain.SetPosition(0, handTransform.position);
            GunLibShit.LineMain.SetPosition(1, raycastHit.point);
            Material lineMaterial = new Material(Shader.Find("GUI/Text Shader"));
            lineMaterial.color = Color.blue;
            GunLibShit.LineMain.material = lineMaterial;
            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.15f)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        if (Vector3.Distance(CheatMods.GunPointer1.transform.position, vrrig.transform.position) < 1.5f)
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.headMesh.transform.position - new Vector3(0.0f, 2f, 0.0f);
                            var position1 = vrrig.rightHandTransform.position;
                            var position2 = vrrig.leftHandTransform.position;
                            GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlaySplashEffect", NetworkSystem.Instance.LocalPlayer, new object[] { position1, vrrig.rightHandTransform.rotation, 2f, 100f, true, false });
                            GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlaySplashEffect", NetworkSystem.Instance.LocalPlayer, new object[] { position1, vrrig.leftHandTransform.rotation, 2f, 100f, true, false });
                            SafetySettings.FlushRPCs();
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }

            Player.Instance.StartCoroutine(CheatMods.DestroyAfterDelay());
        }

        public static void Disconnect()
        {
            if (!PhotonNetwork.InRoom && !PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
            }
        }
        public static void GiveBug()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab ||
                !Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position,
                                 -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit))
            {
                return;
            }
            if (GunLibShit.GunMain != null)
                Object.Destroy(GunLibShit.GunMain);
            if (GunLibShit.LineMain != null)
                Object.Destroy(GunLibShit.LineMain.gameObject);
            GunLibShit.GunMain = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            GunLibShit.GunMain.GetComponent<Renderer>().material.color = Color.blue;
            GunLibShit.GunMain.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            GunLibShit.GunMain.transform.position = raycastHit.point;
            Object.Destroy(GunLibShit.GunMain.GetComponent<Collider>());
            Object.Destroy(GunLibShit.GunMain.GetComponent<Rigidbody>());
            GunLibShit.LineMain = new GameObject("Line").AddComponent<LineRenderer>();
            GunLibShit.LineMain.startColor = Color.blue;
            GunLibShit.LineMain.endColor = Color.blue;
            GunLibShit.LineMain.startWidth = 0.025f;
            GunLibShit.LineMain.endWidth = 0.025f;
            GunLibShit.LineMain.positionCount = 2;
            GunLibShit.LineMain.useWorldSpace = true;
            Transform handTransform = GorillaLocomotion.Player.Instance.rightControllerTransform;
            GunLibShit.LineMain.SetPosition(0, handTransform.position);
            GunLibShit.LineMain.SetPosition(1, raycastHit.point);
            Material lineMaterial = new Material(Shader.Find("GUI/Text Shader"));
            lineMaterial.color = Color.blue;
            GunLibShit.LineMain.material = lineMaterial;
            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.15f)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig != GorillaTagger.Instance.offlineVRRig && Vector3.Distance(CheatMods.GunPointer1.transform.position, vrrig.transform.position) < 1.5f)
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.headMesh.transform.position - new Vector3(0.0f, 2f, 0.0f);
                        Vector3 position1 = vrrig.rightHandTransform.position;
                        Vector3 position2 = vrrig.leftHandTransform.position;
                        GameObject bug = GameObject.Find("Floating Bug Holdable");
                        if (bug != null)
                        {
                            bug.transform.parent = vrrig.rightHandTransform;
                            bug.transform.localPosition = Vector3.zero;
                            bug.transform.localRotation = Quaternion.identity;
                        }
                        SafetySettings.FlushRPCs();
                    }
                    else
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }

            Player.Instance.StartCoroutine(CheatMods.DestroyAfterDelay());
        }


        private static IEnumerator DestroyAfterDelay()
        {
            yield return new WaitForSeconds(0.5f);
            if (CheatMods.GunPointer1 != null)
                Object.Destroy(CheatMods.GunPointer1);
            if (CheatMods.liner6 != null)
                Object.Destroy(CheatMods.liner6.gameObject);
        }

        public static void GiveBat()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab ||
                !Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position,
                                 -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit))
            {
                return;
            }
            if (GunLibShit.GunMain != null)
                Object.Destroy(GunLibShit.GunMain);
            if (GunLibShit.LineMain != null)
                Object.Destroy(GunLibShit.LineMain.gameObject);
            GunLibShit.GunMain = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            GunLibShit.GunMain.GetComponent<Renderer>().material.color = Color.blue;
            GunLibShit.GunMain.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            GunLibShit.GunMain.transform.position = raycastHit.point;
            Object.Destroy(GunLibShit.GunMain.GetComponent<Collider>());
            Object.Destroy(GunLibShit.GunMain.GetComponent<Rigidbody>());
            GunLibShit.LineMain = new GameObject("Line").AddComponent<LineRenderer>();
            GunLibShit.LineMain.startColor = Color.blue;
            GunLibShit.LineMain.endColor = Color.blue;
            GunLibShit.LineMain.startWidth = 0.025f;
            GunLibShit.LineMain.endWidth = 0.025f;
            GunLibShit.LineMain.positionCount = 2;
            GunLibShit.LineMain.useWorldSpace = true;
            Transform handTransform = GorillaLocomotion.Player.Instance.rightControllerTransform;
            GunLibShit.LineMain.SetPosition(0, handTransform.position);
            GunLibShit.LineMain.SetPosition(1, raycastHit.point);
            Material lineMaterial = new Material(Shader.Find("GUI/Text Shader"));
            lineMaterial.color = Color.blue;
            GunLibShit.LineMain.material = lineMaterial;
            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.15f)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        if (Vector3.Distance(CheatMods.GunPointer1.transform.position, vrrig.transform.position) < 1.5f)
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.headMesh.transform.position - new Vector3(0f, 2f, 0f);
                            Vector3 position1 = vrrig.rightHandTransform.position;
                            Vector3 position2 = vrrig.leftHandTransform.position;
                            GameObject gameObject = GameObject.Find("Cave Bat Holdable");
                            if (gameObject != null)
                            {
                                gameObject.transform.parent = vrrig.rightHandTransform;
                                gameObject.transform.localPosition = Vector3.zero;
                                gameObject.transform.localRotation = Quaternion.identity;
                            }
                            SafetySettings.FlushRPCs();
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }

            Player.Instance.StartCoroutine(CheatMods.DestroyAfterDelay());
        }

        public static void GiveBall()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab ||
                !Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position,
                                 -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit))
            {
                return;
            }
            if (GunLibShit.GunMain != null)
                Object.Destroy(GunLibShit.GunMain);
            if (GunLibShit.LineMain != null)
                Object.Destroy(GunLibShit.LineMain.gameObject);
            GunLibShit.GunMain = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            GunLibShit.GunMain.GetComponent<Renderer>().material.color = Color.blue;
            GunLibShit.GunMain.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            GunLibShit.GunMain.transform.position = raycastHit.point;
            Object.Destroy(GunLibShit.GunMain.GetComponent<Collider>());
            Object.Destroy(GunLibShit.GunMain.GetComponent<Rigidbody>());
            GunLibShit.LineMain = new GameObject("Line").AddComponent<LineRenderer>();
            GunLibShit.LineMain.startColor = Color.blue;
            GunLibShit.LineMain.endColor = Color.blue;
            GunLibShit.LineMain.startWidth = 0.025f;
            GunLibShit.LineMain.endWidth = 0.025f;
            GunLibShit.LineMain.positionCount = 2;
            GunLibShit.LineMain.useWorldSpace = true;
            Transform handTransform = GorillaLocomotion.Player.Instance.rightControllerTransform;
            GunLibShit.LineMain.SetPosition(0, handTransform.position);
            GunLibShit.LineMain.SetPosition(1, raycastHit.point);
            Material lineMaterial = new Material(Shader.Find("GUI/Text Shader"));
            lineMaterial.color = Color.blue;
            GunLibShit.LineMain.material = lineMaterial;
            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.15f)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        if (Vector3.Distance(CheatMods.GunPointer1.transform.position, vrrig.transform.position) < 1.5f)
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.headMesh.transform.position - new Vector3(0f, 2f, 0f);
                            Vector3 position1 = vrrig.rightHandTransform.position;
                            Vector3 position2 = vrrig.leftHandTransform.position;
                            GameObject gameObject = GameObject.Find("BeachBall");
                            if (gameObject != null)
                            {
                                gameObject.transform.parent = vrrig.rightHandTransform;
                                gameObject.transform.localPosition = Vector3.zero;
                                gameObject.transform.localRotation = Quaternion.identity;
                            }
                            SafetySettings.FlushRPCs();
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }

            Player.Instance.StartCoroutine(CheatMods.DestroyAfterDelay());
        }

        public static void GiveMonsters()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab ||
                !Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position,
                                 -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit))
            {
                return;
            }
            if (GunLibShit.GunMain != null)
                Object.Destroy(GunLibShit.GunMain);
            if (GunLibShit.LineMain != null)
                Object.Destroy(GunLibShit.LineMain.gameObject);
            GunLibShit.GunMain = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            GunLibShit.GunMain.GetComponent<Renderer>().material.color = Color.blue;
            GunLibShit.GunMain.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            GunLibShit.GunMain.transform.position = raycastHit.point;
            Object.Destroy(GunLibShit.GunMain.GetComponent<Collider>());
            Object.Destroy(GunLibShit.GunMain.GetComponent<Rigidbody>());
            GunLibShit.LineMain = new GameObject("Line").AddComponent<LineRenderer>();
            GunLibShit.LineMain.startColor = Color.blue;
            GunLibShit.LineMain.endColor = Color.blue;
            GunLibShit.LineMain.startWidth = 0.025f;
            GunLibShit.LineMain.endWidth = 0.025f;
            GunLibShit.LineMain.positionCount = 2;
            GunLibShit.LineMain.useWorldSpace = true;
            Transform handTransform = GorillaLocomotion.Player.Instance.rightControllerTransform;
            GunLibShit.LineMain.SetPosition(0, handTransform.position);
            GunLibShit.LineMain.SetPosition(1, raycastHit.point);
            Material lineMaterial = new Material(Shader.Find("GUI/Text Shader"));
            lineMaterial.color = Color.blue;
            GunLibShit.LineMain.material = lineMaterial;
            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.15f)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        if (Vector3.Distance(CheatMods.GunPointer1.transform.position, vrrig.transform.position) < 1.5f)
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.headMesh.transform.position - new Vector3(0f, 2f, 0f);
                            Vector3 position1 = vrrig.rightHandTransform.position;
                            Vector3 position2 = vrrig.leftHandTransform.position;
                            foreach (MonkeyeAI monkeyeAI in UnityEngine.Object.FindObjectsOfType<MonkeyeAI>())
                            {
                                monkeyeAI.transform.position = GorillaTagger.Instance.rightHandTransform.position;

                                if (monkeyeAI != null)
                                {
                                    monkeyeAI.transform.parent = vrrig.rightHandTransform;
                                    monkeyeAI.transform.localPosition = Vector3.zero;
                                    monkeyeAI.transform.localRotation = Quaternion.identity;
                                }
                            }
                            SafetySettings.FlushRPCs();
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }

            Player.Instance.StartCoroutine(CheatMods.DestroyAfterDelay());
        }
  

        public static void GiveSnowballSpam()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab ||
                !Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position,
                                 -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit))
            {
                return;
            }
            if (GunLibShit.GunMain != null)
                Object.Destroy(GunLibShit.GunMain);
            if (GunLibShit.LineMain != null)
                Object.Destroy(GunLibShit.LineMain.gameObject);
            GunLibShit.GunMain = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            GunLibShit.GunMain.GetComponent<Renderer>().material.color = Color.blue;
            GunLibShit.GunMain.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            GunLibShit.GunMain.transform.position = raycastHit.point;
            Object.Destroy(GunLibShit.GunMain.GetComponent<Collider>());
            Object.Destroy(GunLibShit.GunMain.GetComponent<Rigidbody>());
            GunLibShit.LineMain = new GameObject("Line").AddComponent<LineRenderer>();
            GunLibShit.LineMain.startColor = Color.blue;
            GunLibShit.LineMain.endColor = Color.blue;
            GunLibShit.LineMain.startWidth = 0.025f;
            GunLibShit.LineMain.endWidth = 0.025f;
            GunLibShit.LineMain.positionCount = 2;
            GunLibShit.LineMain.useWorldSpace = true;
            Transform handTransform = GorillaLocomotion.Player.Instance.rightControllerTransform;
            GunLibShit.LineMain.SetPosition(0, handTransform.position);
            GunLibShit.LineMain.SetPosition(1, raycastHit.point);
            Material lineMaterial = new Material(Shader.Find("GUI/Text Shader"));
            lineMaterial.color = Color.blue;
            GunLibShit.LineMain.material = lineMaterial;
            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.15f)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        if (Vector3.Distance(CheatMods.GunPointer1.transform.position, vrrig.transform.position) < 1.5f)
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.headMesh.transform.position - new Vector3(0.0f, 2f, 0.0f);
                            Vector3 position1 = vrrig.rightHandTransform.position;
                            Vector3 position2 = vrrig.leftHandTransform.position;
                            SpamMods.Projectile(SpamMods.fullProjectileNames[0], position1, Vector3.down, SpamMods.projColor);
                            SpamMods.Projectile(SpamMods.fullProjectileNames[0], position2, Vector3.down, SpamMods.projColor);
                            SafetySettings.FlushRPCs();
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
            Player.Instance.StartCoroutine(CheatMods.DestroyAfterDelay());
        }

        public static void GiveWaterSpam()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab ||
                !Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position,
                                 -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit))
            {
                return;
            }
            if (GunLibShit.GunMain != null)
                Object.Destroy(GunLibShit.GunMain);
            if (GunLibShit.LineMain != null)
                Object.Destroy(GunLibShit.LineMain.gameObject);
            GunLibShit.GunMain = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            GunLibShit.GunMain.GetComponent<Renderer>().material.color = Color.blue;
            GunLibShit.GunMain.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            GunLibShit.GunMain.transform.position = raycastHit.point;
            Object.Destroy(GunLibShit.GunMain.GetComponent<Collider>());
            Object.Destroy(GunLibShit.GunMain.GetComponent<Rigidbody>());
            GunLibShit.LineMain = new GameObject("Line").AddComponent<LineRenderer>();
            GunLibShit.LineMain.startColor = Color.blue;
            GunLibShit.LineMain.endColor = Color.blue;
            GunLibShit.LineMain.startWidth = 0.025f;
            GunLibShit.LineMain.endWidth = 0.025f;
            GunLibShit.LineMain.positionCount = 2;
            GunLibShit.LineMain.useWorldSpace = true;
            Transform handTransform = GorillaLocomotion.Player.Instance.rightControllerTransform;
            GunLibShit.LineMain.SetPosition(0, handTransform.position);
            GunLibShit.LineMain.SetPosition(1, raycastHit.point);
            Material lineMaterial = new Material(Shader.Find("GUI/Text Shader"));
            lineMaterial.color = Color.blue;
            GunLibShit.LineMain.material = lineMaterial;
            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.15f)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        if (Vector3.Distance(CheatMods.GunPointer1.transform.position, vrrig.transform.position) < 1.5f)
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.headMesh.transform.position - new Vector3(0.0f, 2f, 0.0f);
                            Vector3 position1 = vrrig.rightHandTransform.position;
                            Vector3 position2 = vrrig.leftHandTransform.position;
                            SpamMods.Projectile(SpamMods.fullProjectileNames[1], position1, Vector3.down, SpamMods.projColor);
                            SpamMods.Projectile(SpamMods.fullProjectileNames[1], position2, Vector3.down, SpamMods.projColor);
                            SafetySettings.FlushRPCs();
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
            Player.Instance.StartCoroutine(CheatMods.DestroyAfterDelay());
        }

        public static void GiveLavaSpam()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab ||
                !Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position,
                                 -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit))
            {
                return;
            }
            if (GunLibShit.GunMain != null)
                Object.Destroy(GunLibShit.GunMain);
            if (GunLibShit.LineMain != null)
                Object.Destroy(GunLibShit.LineMain.gameObject);
            GunLibShit.GunMain = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            GunLibShit.GunMain.GetComponent<Renderer>().material.color = Color.blue;
            GunLibShit.GunMain.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            GunLibShit.GunMain.transform.position = raycastHit.point;
            Object.Destroy(GunLibShit.GunMain.GetComponent<Collider>());
            Object.Destroy(GunLibShit.GunMain.GetComponent<Rigidbody>());
            GunLibShit.LineMain = new GameObject("Line").AddComponent<LineRenderer>();
            GunLibShit.LineMain.startColor = Color.blue;
            GunLibShit.LineMain.endColor = Color.blue;
            GunLibShit.LineMain.startWidth = 0.025f;
            GunLibShit.LineMain.endWidth = 0.025f;
            GunLibShit.LineMain.positionCount = 2;
            GunLibShit.LineMain.useWorldSpace = true;
            Transform handTransform = GorillaLocomotion.Player.Instance.rightControllerTransform;
            GunLibShit.LineMain.SetPosition(0, handTransform.position);
            GunLibShit.LineMain.SetPosition(1, raycastHit.point);
            Material lineMaterial = new Material(Shader.Find("GUI/Text Shader"));
            lineMaterial.color = Color.blue;
            GunLibShit.LineMain.material = lineMaterial;
            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.15f)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        if (Vector3.Distance(CheatMods.GunPointer1.transform.position, vrrig.transform.position) < 1.5f)
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.headMesh.transform.position - new Vector3(0.0f, 2f, 0.0f);
                            Vector3 position1 = vrrig.rightHandTransform.position;
                            Vector3 position2 = vrrig.leftHandTransform.position;
                            SpamMods.Projectile(SpamMods.fullProjectileNames[2], position1, Vector3.down, SpamMods.projColor);
                            SpamMods.Projectile(SpamMods.fullProjectileNames[2], position2, Vector3.down, SpamMods.projColor);
                            SafetySettings.FlushRPCs();
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
            Player.Instance.StartCoroutine(CheatMods.DestroyAfterDelay());
        }

        public static void GiveGiftSpam()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab ||
                !Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position,
                                 -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit))
            {
                return;
            }
            if (GunLibShit.GunMain != null)
                Object.Destroy(GunLibShit.GunMain);
            if (GunLibShit.LineMain != null)
                Object.Destroy(GunLibShit.LineMain.gameObject);
            GunLibShit.GunMain = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            GunLibShit.GunMain.GetComponent<Renderer>().material.color = Color.blue;
            GunLibShit.GunMain.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            GunLibShit.GunMain.transform.position = raycastHit.point;
            Object.Destroy(GunLibShit.GunMain.GetComponent<Collider>());
            Object.Destroy(GunLibShit.GunMain.GetComponent<Rigidbody>());
            GunLibShit.LineMain = new GameObject("Line").AddComponent<LineRenderer>();
            GunLibShit.LineMain.startColor = Color.blue;
            GunLibShit.LineMain.endColor = Color.blue;
            GunLibShit.LineMain.startWidth = 0.025f;
            GunLibShit.LineMain.endWidth = 0.025f;
            GunLibShit.LineMain.positionCount = 2;
            GunLibShit.LineMain.useWorldSpace = true;
            Transform handTransform = GorillaLocomotion.Player.Instance.rightControllerTransform;
            GunLibShit.LineMain.SetPosition(0, handTransform.position);
            GunLibShit.LineMain.SetPosition(1, raycastHit.point);
            Material lineMaterial = new Material(Shader.Find("GUI/Text Shader"));
            lineMaterial.color = Color.blue;
            GunLibShit.LineMain.material = lineMaterial;
            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.15f)
            {
                foreach (var rig in GorillaParent.instance.vrrigs)
                {
                    if (rig != GorillaTagger.Instance.offlineVRRig && Vector3.Distance(CheatMods.GunPointer1.transform.position, rig.transform.position) < 1.5f)
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        GorillaTagger.Instance.offlineVRRig.transform.position = rig.headMesh.transform.position - new Vector3(0f, 2f, 0f);
                        SpamMods.Projectile(SpamMods.fullProjectileNames[3], rig.rightHandTransform.position, Vector3.down, SpamMods.projColor);
                        SpamMods.Projectile(SpamMods.fullProjectileNames[3], rig.leftHandTransform.position, Vector3.down, SpamMods.projColor);
                        SafetySettings.FlushRPCs();
                    }
                    else
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }

            Player.Instance.StartCoroutine(CheatMods.DestroyAfterDelay());
        }

        public static void GiveCandySpam()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab ||
                !Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position,
                                 -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit))
            {
                return;
            }
            if (GunLibShit.GunMain != null)
                Object.Destroy(GunLibShit.GunMain);
            if (GunLibShit.LineMain != null)
                Object.Destroy(GunLibShit.LineMain.gameObject);
            GunLibShit.GunMain = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            GunLibShit.GunMain.GetComponent<Renderer>().material.color = Color.blue;
            GunLibShit.GunMain.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            GunLibShit.GunMain.transform.position = raycastHit.point;
            Object.Destroy(GunLibShit.GunMain.GetComponent<Collider>());
            Object.Destroy(GunLibShit.GunMain.GetComponent<Rigidbody>());
            GunLibShit.LineMain = new GameObject("Line").AddComponent<LineRenderer>();
            GunLibShit.LineMain.startColor = Color.blue;
            GunLibShit.LineMain.endColor = Color.blue;
            GunLibShit.LineMain.startWidth = 0.025f;
            GunLibShit.LineMain.endWidth = 0.025f;
            GunLibShit.LineMain.positionCount = 2;
            GunLibShit.LineMain.useWorldSpace = true;
            Transform handTransform = GorillaLocomotion.Player.Instance.rightControllerTransform;
            GunLibShit.LineMain.SetPosition(0, handTransform.position);
            GunLibShit.LineMain.SetPosition(1, raycastHit.point);
            Material lineMaterial = new Material(Shader.Find("GUI/Text Shader"));
            lineMaterial.color = Color.blue;
            GunLibShit.LineMain.material = lineMaterial;
            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.15f)
            {
                foreach (var rig in GorillaParent.instance.vrrigs)
                {
                    if (rig != GorillaTagger.Instance.offlineVRRig && Vector3.Distance(CheatMods.GunPointer1.transform.position, rig.transform.position) < 1.5f)
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        GorillaTagger.Instance.offlineVRRig.transform.position = rig.headMesh.transform.position - new Vector3(0f, 2f, 0f);
                        SpamMods.Projectile(SpamMods.fullProjectileNames[4], rig.rightHandTransform.position, Vector3.down, SpamMods.projColor);
                        SpamMods.Projectile(SpamMods.fullProjectileNames[4], rig.leftHandTransform.position, Vector3.down, SpamMods.projColor);
                        SafetySettings.FlushRPCs();
                    }
                    else
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }

            Player.Instance.StartCoroutine(CheatMods.DestroyAfterDelay());
        }

        public static void GiveFishSpam()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab ||
                !Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position,
                                 -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit))
            {
                return;
            }
            if (GunLibShit.GunMain != null)
                Object.Destroy(GunLibShit.GunMain);
            if (GunLibShit.LineMain != null)
                Object.Destroy(GunLibShit.LineMain.gameObject);
            GunLibShit.GunMain = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            GunLibShit.GunMain.GetComponent<Renderer>().material.color = Color.blue;
            GunLibShit.GunMain.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            GunLibShit.GunMain.transform.position = raycastHit.point;
            Object.Destroy(GunLibShit.GunMain.GetComponent<Collider>());
            Object.Destroy(GunLibShit.GunMain.GetComponent<Rigidbody>());
            GunLibShit.LineMain = new GameObject("Line").AddComponent<LineRenderer>();
            GunLibShit.LineMain.startColor = Color.blue;
            GunLibShit.LineMain.endColor = Color.blue;
            GunLibShit.LineMain.startWidth = 0.025f;
            GunLibShit.LineMain.endWidth = 0.025f;
            GunLibShit.LineMain.positionCount = 2;
            GunLibShit.LineMain.useWorldSpace = true;
            Transform handTransform = GorillaLocomotion.Player.Instance.rightControllerTransform;
            GunLibShit.LineMain.SetPosition(0, handTransform.position);
            GunLibShit.LineMain.SetPosition(1, raycastHit.point);
            Material lineMaterial = new Material(Shader.Find("GUI/Text Shader"));
            lineMaterial.color = Color.blue;
            GunLibShit.LineMain.material = lineMaterial;
            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.15f)
            {
                foreach (var rig in GorillaParent.instance.vrrigs)
                {
                    if (rig != GorillaTagger.Instance.offlineVRRig && Vector3.Distance(CheatMods.GunPointer1.transform.position, rig.transform.position) < 1.5f)
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        GorillaTagger.Instance.offlineVRRig.transform.position = rig.headMesh.transform.position - new Vector3(0f, 2f, 0f);
                        SpamMods.Projectile(SpamMods.fullProjectileNames[5], rig.rightHandTransform.position, Vector3.down, SpamMods.projColor);
                        SpamMods.Projectile(SpamMods.fullProjectileNames[5], rig.leftHandTransform.position, Vector3.down, SpamMods.projColor);
                        SafetySettings.FlushRPCs();
                    }
                    else
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }

            Player.Instance.StartCoroutine(CheatMods.DestroyAfterDelay());
        }


        public static GameObject GunPointer { get; private set; }

        public static Color GunPointerColor { get; private set; }
    }
}
