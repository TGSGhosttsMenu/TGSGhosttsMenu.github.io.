﻿using GorillaLocomotion;
using GorillaNetworking;
using Oculus.Platform.Models;
using Photon.Pun;
using PlayFab.ClientModels;
using System.Collections;
using TGSGhostt.Menu;
using TGSGhostt.Mods;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.XR;
using TGSGhostt.Notifications;
#nullable disable
namespace TGSGhostts_Menu.Mods
{
    internal class CheatMods
    {
        public static VRRig GunShit = null;
        private static GameObject GunPointer1;
        private static LineRenderer liner6;
        public static Color GunPointerColor1 = Color.magenta;
        public static VRRig GunLockRig;
        public static void JoinLastRoom()
        {
            if (!PhotonNetwork.InRoom)
            {
                PhotonNetworkController.Instance.AttemptToJoinSpecificRoom(Main.CurrentRoom, JoinType.Solo);
                NotifiLib.SendNotification("<color=purple>JOINING ROOM: </color>" + Main.CurrentRoom);
            }
            else if (Main.CurrentRoom == "")
            {
                NotifiLib.SendNotification("<color=purple>ERROR! HAS NOT BEEN IN A ROOM.</color>");
            }
            else if (PhotonNetwork.InRoom)
            {
                NotifiLib.SendNotification("<color=purple>ERROR! IN A ROOM</color>");
            }
        }
        public static void GiveWater()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab || !Physics.Raycast(Player.Instance.rightControllerTransform.position - Player.Instance.rightControllerTransform.up, -Player.Instance.rightControllerTransform.up, out raycastHit))
                return;

            if (CheatMods.GunPointer1 != null)
                Object.Destroy(CheatMods.GunPointer1);
            if (CheatMods.liner6 != null)
                Object.Destroy(CheatMods.liner6.gameObject);

            var colliderParent = raycastHit.collider.GetComponentInParent<VRRig>();
            if (colliderParent != null)
            {
                CheatMods.GunLockRig = colliderParent;
                GorillaTagger.Instance.offlineVRRig.transform.position = CheatMods.GunLockRig.transform.position;
            }

            CheatMods.GunPointer1 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            CheatMods.GunPointer1.GetComponent<Renderer>().material.color = CheatMods.GunPointerColor1;
            CheatMods.GunPointer1.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
            CheatMods.GunPointer1.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            CheatMods.GunPointer1.transform.position = raycastHit.point;
            Object.Destroy(CheatMods.GunPointer1.GetComponent<SphereCollider>());
            Object.Destroy(CheatMods.GunPointer1.GetComponent<Rigidbody>());
            Object.Destroy(CheatMods.GunPointer1.GetComponent<Collider>());

            CheatMods.liner6 = new GameObject("Line").AddComponent<LineRenderer>();
            CheatMods.liner6.startColor = ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.5f ? new Color32(0, 0, 255, 255) : new Color32(255, 0, 0, 255);
            CheatMods.liner6.endColor = CheatMods.liner6.startColor;
            CheatMods.liner6.startWidth = 0.025f;
            CheatMods.liner6.endWidth = 0.025f;
            CheatMods.liner6.positionCount = 2;
            CheatMods.liner6.useWorldSpace = true;
            CheatMods.liner6.SetPosition(0, GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R").transform.position);
            CheatMods.liner6.SetPosition(1, raycastHit.point);
            CheatMods.liner6.material.shader = Shader.Find("GUI/Text Shader");

            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.15f)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        if (Vector3.Distance(CheatMods.GunPointer1.transform.position, vrrig.transform.position) < 1.5f)
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.headMesh.transform.position - new Vector3(0.0f, 2f, 0.0f);
                            var position1 = vrrig.rightHandTransform.position;
                            var position2 = vrrig.leftHandTransform.position;
                            GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlaySplashEffect", NetworkSystem.Instance.LocalPlayer, new object[] { position1, vrrig.rightHandTransform.rotation, 2f, 100f, true, false });
                            GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlaySplashEffect", NetworkSystem.Instance.LocalPlayer, new object[] { position1, vrrig.leftHandTransform.rotation, 2f, 100f, true, false });
                            SafetySettings.FlushRPCs();
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }

            Player.Instance.StartCoroutine(CheatMods.DestroyAfterDelay());
        }

        public static void Disconnect()
        {
            if (!PhotonNetwork.InRoom && !PhotonNetwork.LocalPlayer.IsMasterClient)
            {
                PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
            }
        }
        public static void GiveBug()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab || !Physics.Raycast(Player.Instance.rightControllerTransform.position - Player.Instance.rightControllerTransform.up, -Player.Instance.rightControllerTransform.up, out raycastHit))
                return;

            if (CheatMods.GunPointer1 != null)
                Object.Destroy(CheatMods.GunPointer1);
            if (CheatMods.liner6 != null)
                Object.Destroy(CheatMods.liner6.gameObject);

            VRRig targetVRRig = ((Component)raycastHit.collider.GetComponentInParent<VRRig>()).GetComponentInParent<VRRig>();
            if (targetVRRig != null)
            {
                CheatMods.GunLockRig = targetVRRig;
                GorillaTagger.Instance.offlineVRRig.transform.position = CheatMods.GunLockRig.transform.position;
            }

            CheatMods.GunPointer1 = GameObject.CreatePrimitive(PrimitiveType.Cube);
            CheatMods.GunPointer1.GetComponent<Renderer>().material.color = CheatMods.GunPointerColor1;
            CheatMods.GunPointer1.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
            CheatMods.GunPointer1.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            CheatMods.GunPointer1.transform.position = raycastHit.point;
            Object.Destroy(CheatMods.GunPointer1.GetComponent<BoxCollider>());
            Object.Destroy(CheatMods.GunPointer1.GetComponent<Rigidbody>());
            Object.Destroy(CheatMods.GunPointer1.GetComponent<Collider>());

            CheatMods.liner6 = new GameObject("Line").AddComponent<LineRenderer>();
            CheatMods.liner6.startColor = (ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.5) ? new Color(0, 0, 255) : new Color(255, 0, 0);
            CheatMods.liner6.endColor = CheatMods.liner6.startColor;
            CheatMods.liner6.startWidth = 0.025f;
            CheatMods.liner6.endWidth = 0.025f;
            CheatMods.liner6.positionCount = 2;
            CheatMods.liner6.useWorldSpace = true;
            CheatMods.liner6.SetPosition(0, GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R").transform.position);
            CheatMods.liner6.SetPosition(1, raycastHit.point);
            CheatMods.liner6.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");

            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.15f)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig != GorillaTagger.Instance.offlineVRRig && Vector3.Distance(CheatMods.GunPointer1.transform.position, vrrig.transform.position) < 1.5f)
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.headMesh.transform.position - new Vector3(0.0f, 2f, 0.0f);
                        Vector3 position1 = vrrig.rightHandTransform.position;
                        Vector3 position2 = vrrig.leftHandTransform.position;
                        GameObject bug = GameObject.Find("Floating Bug Holdable");
                        if (bug != null)
                        {
                            bug.transform.parent = vrrig.rightHandTransform;
                            bug.transform.localPosition = Vector3.zero;
                            bug.transform.localRotation = Quaternion.identity;
                        }
                        SafetySettings.FlushRPCs();
                    }
                    else
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }

            Player.Instance.StartCoroutine(CheatMods.DestroyAfterDelay());
        }


        private static IEnumerator DestroyAfterDelay()
        {
            yield return new WaitForSeconds(0.5f);
            if (CheatMods.GunPointer1 != null)
                Object.Destroy(CheatMods.GunPointer1);
            if (CheatMods.liner6 != null)
                Object.Destroy(CheatMods.liner6.gameObject);
        }

        public static void GiveBat()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab || !Physics.Raycast(Player.Instance.rightControllerTransform.position - Player.Instance.rightControllerTransform.up, -Player.Instance.rightControllerTransform.up, out raycastHit))
                return;

            if (CheatMods.GunPointer1 != null)
                Object.Destroy(CheatMods.GunPointer1);
            if (CheatMods.liner6 != null)
                Object.Destroy(CheatMods.liner6.gameObject);

            VRRig targetRig = raycastHit.collider.GetComponentInParent<VRRig>();
            if (targetRig != null)
            {
                CheatMods.GunLockRig = targetRig;
                GorillaTagger.Instance.offlineVRRig.transform.position = targetRig.transform.position;
            }

            CheatMods.GunPointer1 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            Renderer pointerRenderer = CheatMods.GunPointer1.GetComponent<Renderer>();
            pointerRenderer.material.color = CheatMods.GunPointerColor1;
            pointerRenderer.material.shader = Shader.Find("GUI/Text Shader");
            CheatMods.GunPointer1.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            CheatMods.GunPointer1.transform.position = raycastHit.point;
            Object.Destroy(CheatMods.GunPointer1.GetComponent<BoxCollider>());
            Object.Destroy(CheatMods.GunPointer1.GetComponent<Rigidbody>());
            Object.Destroy(CheatMods.GunPointer1.GetComponent<Collider>());

            CheatMods.liner6 = new GameObject("Line").AddComponent<LineRenderer>();
            Color lineColor = ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.5 ? Color.blue : Color.red;
            CheatMods.liner6.startColor = lineColor;
            CheatMods.liner6.endColor = lineColor;
            CheatMods.liner6.startWidth = 0.025f;
            CheatMods.liner6.endWidth = 0.025f;
            CheatMods.liner6.positionCount = 2;
            CheatMods.liner6.useWorldSpace = true;
            CheatMods.liner6.SetPosition(0, GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R").transform.position);
            CheatMods.liner6.SetPosition(1, raycastHit.point);
            CheatMods.liner6.material.shader = Shader.Find("GUI/Text Shader");

            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.15f)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        if (Vector3.Distance(CheatMods.GunPointer1.transform.position, vrrig.transform.position) < 1.5f)
                        {
                            pointerRenderer.material.color = Color.cyan;
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.headMesh.transform.position - new Vector3(0f, 2f, 0f);
                            Vector3 position1 = vrrig.rightHandTransform.position;
                            Vector3 position2 = vrrig.leftHandTransform.position;
                            GameObject gameObject = GameObject.Find("Cave Bat Holdable");
                            if (gameObject != null)
                            {
                                gameObject.transform.parent = vrrig.rightHandTransform;
                                gameObject.transform.localPosition = Vector3.zero;
                                gameObject.transform.localRotation = Quaternion.identity;
                            }
                            SafetySettings.FlushRPCs();
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }

            Player.Instance.StartCoroutine(CheatMods.DestroyAfterDelay());
        }

        public static void GiveBall()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab || !Physics.Raycast(Player.Instance.rightControllerTransform.position - Player.Instance.rightControllerTransform.up, -Player.Instance.rightControllerTransform.up, out raycastHit))
                return;

            if (CheatMods.GunPointer1 != null)
                Object.Destroy(CheatMods.GunPointer1);
            if (CheatMods.liner6 != null)
                Object.Destroy(CheatMods.liner6.gameObject);

            VRRig targetRig = raycastHit.collider.GetComponentInParent<VRRig>();
            if (targetRig != null)
            {
                CheatMods.GunLockRig = targetRig;
                GorillaTagger.Instance.offlineVRRig.transform.position = targetRig.transform.position;
            }

            CheatMods.GunPointer1 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            Renderer pointerRenderer = CheatMods.GunPointer1.GetComponent<Renderer>();
            pointerRenderer.material.color = CheatMods.GunPointerColor1;
            pointerRenderer.material.shader = Shader.Find("GUI/Text Shader");
            CheatMods.GunPointer1.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            CheatMods.GunPointer1.transform.position = raycastHit.point;
            Object.Destroy(CheatMods.GunPointer1.GetComponent<BoxCollider>());
            Object.Destroy(CheatMods.GunPointer1.GetComponent<Rigidbody>());
            Object.Destroy(CheatMods.GunPointer1.GetComponent<Collider>());

            CheatMods.liner6 = new GameObject("Line").AddComponent<LineRenderer>();
            Color lineColor = ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.5 ? Color.blue : Color.red;
            CheatMods.liner6.startColor = lineColor;
            CheatMods.liner6.endColor = lineColor;
            CheatMods.liner6.startWidth = 0.025f;
            CheatMods.liner6.endWidth = 0.025f;
            CheatMods.liner6.positionCount = 2;
            CheatMods.liner6.useWorldSpace = true;
            CheatMods.liner6.SetPosition(0, GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R").transform.position);
            CheatMods.liner6.SetPosition(1, raycastHit.point);
            CheatMods.liner6.material.shader = Shader.Find("GUI/Text Shader");

            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.15f)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        if (Vector3.Distance(CheatMods.GunPointer1.transform.position, vrrig.transform.position) < 1.5f)
                        {
                            pointerRenderer.material.color = Color.cyan;
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.headMesh.transform.position - new Vector3(0f, 2f, 0f);
                            Vector3 position1 = vrrig.rightHandTransform.position;
                            Vector3 position2 = vrrig.leftHandTransform.position;
                            GameObject gameObject = GameObject.Find("BeachBall");
                            if (gameObject != null)
                            {
                                gameObject.transform.parent = vrrig.rightHandTransform;
                                gameObject.transform.localPosition = Vector3.zero;
                                gameObject.transform.localRotation = Quaternion.identity;
                            }
                            SafetySettings.FlushRPCs();
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }

            Player.Instance.StartCoroutine(CheatMods.DestroyAfterDelay());
        }

        public static void GiveMonsters()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab || !Physics.Raycast(Player.Instance.rightControllerTransform.position - Player.Instance.rightControllerTransform.up, -Player.Instance.rightControllerTransform.up, out raycastHit))
                return;

            if (CheatMods.GunPointer1 != null)
                Object.Destroy(CheatMods.GunPointer1);
            if (CheatMods.liner6 != null)
                Object.Destroy(CheatMods.liner6.gameObject);

            VRRig targetRig = raycastHit.collider.GetComponentInParent<VRRig>();
            if (targetRig != null)
            {
                CheatMods.GunLockRig = targetRig;
                GorillaTagger.Instance.offlineVRRig.transform.position = targetRig.transform.position;
            }

            CheatMods.GunPointer1 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            Renderer pointerRenderer = CheatMods.GunPointer1.GetComponent<Renderer>();
            pointerRenderer.material.color = CheatMods.GunPointerColor1;
            pointerRenderer.material.shader = Shader.Find("GUI/Text Shader");
            CheatMods.GunPointer1.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            CheatMods.GunPointer1.transform.position = raycastHit.point;
            Object.Destroy(CheatMods.GunPointer1.GetComponent<BoxCollider>());
            Object.Destroy(CheatMods.GunPointer1.GetComponent<Rigidbody>());
            Object.Destroy(CheatMods.GunPointer1.GetComponent<Collider>());

            CheatMods.liner6 = new GameObject("Line").AddComponent<LineRenderer>();
            Color lineColor = ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.5 ? Color.blue : Color.red;
            CheatMods.liner6.startColor = lineColor;
            CheatMods.liner6.endColor = lineColor;
            CheatMods.liner6.startWidth = 0.025f;
            CheatMods.liner6.endWidth = 0.025f;
            CheatMods.liner6.positionCount = 2;
            CheatMods.liner6.useWorldSpace = true;
            CheatMods.liner6.SetPosition(0, GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R").transform.position);
            CheatMods.liner6.SetPosition(1, raycastHit.point);
            CheatMods.liner6.material.shader = Shader.Find("GUI/Text Shader");

            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.15f)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        if (Vector3.Distance(CheatMods.GunPointer1.transform.position, vrrig.transform.position) < 1.5f)
                        {
                            pointerRenderer.material.color = Color.cyan;
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.headMesh.transform.position - new Vector3(0f, 2f, 0f);
                            Vector3 position1 = vrrig.rightHandTransform.position;
                            Vector3 position2 = vrrig.leftHandTransform.position;
                            foreach (MonkeyeAI monkeyeAI in UnityEngine.Object.FindObjectsOfType<MonkeyeAI>())
                            {
                                monkeyeAI.transform.position = GorillaTagger.Instance.rightHandTransform.position;

                                if (monkeyeAI != null)
                                {
                                    monkeyeAI.transform.parent = vrrig.rightHandTransform;
                                    monkeyeAI.transform.localPosition = Vector3.zero;
                                    monkeyeAI.transform.localRotation = Quaternion.identity;
                                }
                            }
                            SafetySettings.FlushRPCs();
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }

            Player.Instance.StartCoroutine(CheatMods.DestroyAfterDelay());
        }
  

        public static void GiveSnowballSpam()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab || !Physics.Raycast(Player.Instance.rightControllerTransform.position - Player.Instance.rightControllerTransform.up, -Player.Instance.rightControllerTransform.up, out raycastHit))
                return;
            if (CheatMods.GunPointer1 != null)
                Object.Destroy(CheatMods.GunPointer1);
            if (CheatMods.liner6 != null)
                Object.Destroy(CheatMods.liner6.gameObject);
            VRRig rig = raycastHit.collider.GetComponentInParent<VRRig>();
            if (rig != null)
            {
                CheatMods.GunLockRig = rig;
                GorillaTagger.Instance.offlineVRRig.transform.position = CheatMods.GunLockRig.transform.position;
            }
            CheatMods.GunPointer1 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            CheatMods.GunPointer1.GetComponent<Renderer>().material.color = CheatMods.GunPointerColor1;
            CheatMods.GunPointer1.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
            CheatMods.GunPointer1.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            CheatMods.GunPointer1.transform.position = raycastHit.point;
            Object.Destroy(CheatMods.GunPointer1.GetComponent<BoxCollider>());
            Object.Destroy(CheatMods.GunPointer1.GetComponent<Rigidbody>());
            Object.Destroy(CheatMods.GunPointer1.GetComponent<Collider>());
            CheatMods.liner6 = new GameObject("Line").AddComponent<LineRenderer>();
            CheatMods.liner6.startColor = ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.5f ? new Color32(0, 0, 255, 255) : new Color32(255, 0, 0, 255);
            CheatMods.liner6.endColor = ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.5f ? new Color32(0, 0, 255, 255) : new Color32(255, 0, 0, 255);
            CheatMods.liner6.startWidth = 0.025f;
            CheatMods.liner6.endWidth = 0.025f;
            CheatMods.liner6.positionCount = 2;
            CheatMods.liner6.useWorldSpace = true;
            CheatMods.liner6.SetPosition(0, GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R").transform.position);
            CheatMods.liner6.SetPosition(1, raycastHit.point);
            CheatMods.liner6.material.shader = Shader.Find("GUI/Text Shader");
            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.15f)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        if (Vector3.Distance(CheatMods.GunPointer1.transform.position, vrrig.transform.position) < 1.5f)
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.headMesh.transform.position - new Vector3(0.0f, 2f, 0.0f);
                            Vector3 position1 = vrrig.rightHandTransform.position;
                            Vector3 position2 = vrrig.leftHandTransform.position;
                            SpamMods.Projectile(SpamMods.fullProjectileNames[0], position1, Vector3.down, SpamMods.projColor);
                            SpamMods.Projectile(SpamMods.fullProjectileNames[0], position2, Vector3.down, SpamMods.projColor);
                            SafetySettings.FlushRPCs();
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
            Player.Instance.StartCoroutine(CheatMods.DestroyAfterDelay());
        }

        public static void GiveWaterSpam()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab || !Physics.Raycast(Player.Instance.rightControllerTransform.position - Player.Instance.rightControllerTransform.up, -Player.Instance.rightControllerTransform.up, out raycastHit))
                return;
            if (CheatMods.GunPointer1 != null)
                Object.Destroy(CheatMods.GunPointer1);
            if (CheatMods.liner6 != null)
                Object.Destroy(CheatMods.liner6.gameObject);
            VRRig rig = raycastHit.collider.GetComponentInParent<VRRig>();
            if (rig != null)
            {
                CheatMods.GunLockRig = rig;
                GorillaTagger.Instance.offlineVRRig.transform.position = CheatMods.GunLockRig.transform.position;
            }
            CheatMods.GunPointer1 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            CheatMods.GunPointer1.GetComponent<Renderer>().material.color = CheatMods.GunPointerColor1;
            CheatMods.GunPointer1.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
            CheatMods.GunPointer1.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            CheatMods.GunPointer1.transform.position = raycastHit.point;
            Object.Destroy(CheatMods.GunPointer1.GetComponent<BoxCollider>());
            Object.Destroy(CheatMods.GunPointer1.GetComponent<Rigidbody>());
            Object.Destroy(CheatMods.GunPointer1.GetComponent<Collider>());
            CheatMods.liner6 = new GameObject("Line").AddComponent<LineRenderer>();
            CheatMods.liner6.startColor = ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.5f ? new Color32(0, 0, 255, 255) : new Color32(255, 0, 0, 255);
            CheatMods.liner6.endColor = ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.5f ? new Color32(0, 0, 255, 255) : new Color32(255, 0, 0, 255);
            CheatMods.liner6.startWidth = 0.025f;
            CheatMods.liner6.endWidth = 0.025f;
            CheatMods.liner6.positionCount = 2;
            CheatMods.liner6.useWorldSpace = true;
            CheatMods.liner6.SetPosition(0, GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R").transform.position);
            CheatMods.liner6.SetPosition(1, raycastHit.point);
            CheatMods.liner6.material.shader = Shader.Find("GUI/Text Shader");
            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.15f)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        if (Vector3.Distance(CheatMods.GunPointer1.transform.position, vrrig.transform.position) < 1.5f)
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.headMesh.transform.position - new Vector3(0.0f, 2f, 0.0f);
                            Vector3 position1 = vrrig.rightHandTransform.position;
                            Vector3 position2 = vrrig.leftHandTransform.position;
                            SpamMods.Projectile(SpamMods.fullProjectileNames[1], position1, Vector3.down, SpamMods.projColor);
                            SpamMods.Projectile(SpamMods.fullProjectileNames[1], position2, Vector3.down, SpamMods.projColor);
                            SafetySettings.FlushRPCs();
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
            Player.Instance.StartCoroutine(CheatMods.DestroyAfterDelay());
        }

        public static void GiveLavaSpam()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab || !Physics.Raycast(Player.Instance.rightControllerTransform.position - Player.Instance.rightControllerTransform.up, -Player.Instance.rightControllerTransform.up, out raycastHit))
                return;
            if (CheatMods.GunPointer1 != null)
                Object.Destroy(CheatMods.GunPointer1);
            if (CheatMods.liner6 != null)
                Object.Destroy(CheatMods.liner6.gameObject);
            VRRig rig = raycastHit.collider.GetComponentInParent<VRRig>();
            if (rig != null)
            {
                CheatMods.GunLockRig = rig;
                GorillaTagger.Instance.offlineVRRig.transform.position = CheatMods.GunLockRig.transform.position;
            }
            CheatMods.GunPointer1 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            CheatMods.GunPointer1.GetComponent<Renderer>().material.color = CheatMods.GunPointerColor1;
            CheatMods.GunPointer1.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
            CheatMods.GunPointer1.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            CheatMods.GunPointer1.transform.position = raycastHit.point;
            Object.Destroy(CheatMods.GunPointer1.GetComponent<BoxCollider>());
            Object.Destroy(CheatMods.GunPointer1.GetComponent<Rigidbody>());
            Object.Destroy(CheatMods.GunPointer1.GetComponent<Collider>());
            CheatMods.liner6 = new GameObject("Line").AddComponent<LineRenderer>();
            CheatMods.liner6.startColor = ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.5f ? new Color32(0, 0, 255, 255) : new Color32(255, 0, 0, 255);
            CheatMods.liner6.endColor = ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.5f ? new Color32(0, 0, 255, 255) : new Color32(255, 0, 0, 255);
            CheatMods.liner6.startWidth = 0.025f;
            CheatMods.liner6.endWidth = 0.025f;
            CheatMods.liner6.positionCount = 2;
            CheatMods.liner6.useWorldSpace = true;
            CheatMods.liner6.SetPosition(0, GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R").transform.position);
            CheatMods.liner6.SetPosition(1, raycastHit.point);
            CheatMods.liner6.material.shader = Shader.Find("GUI/Text Shader");
            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.15f)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        if (Vector3.Distance(CheatMods.GunPointer1.transform.position, vrrig.transform.position) < 1.5f)
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.headMesh.transform.position - new Vector3(0.0f, 2f, 0.0f);
                            Vector3 position1 = vrrig.rightHandTransform.position;
                            Vector3 position2 = vrrig.leftHandTransform.position;
                            SpamMods.Projectile(SpamMods.fullProjectileNames[2], position1, Vector3.down, SpamMods.projColor);
                            SpamMods.Projectile(SpamMods.fullProjectileNames[2], position2, Vector3.down, SpamMods.projColor);
                            SafetySettings.FlushRPCs();
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
            Player.Instance.StartCoroutine(CheatMods.DestroyAfterDelay());
        }

        public static void GiveGiftSpam()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab || !Physics.Raycast(Player.Instance.rightControllerTransform.position - Player.Instance.rightControllerTransform.up, -Player.Instance.rightControllerTransform.up, out raycastHit))
                return;

            if (CheatMods.GunPointer1 != null)
                Object.Destroy(CheatMods.GunPointer1);
            if (CheatMods.liner6 != null)
                Object.Destroy(CheatMods.liner6.gameObject);

            var vrrig = raycastHit.collider.GetComponentInParent<VRRig>();
            if (vrrig != null)
            {
                CheatMods.GunLockRig = vrrig;
                GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.transform.position;
            }

            CheatMods.GunPointer1 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            var renderer = CheatMods.GunPointer1.GetComponent<Renderer>();
            renderer.material.color = CheatMods.GunPointerColor1;
            renderer.material.shader = Shader.Find("GUI/Text Shader");
            CheatMods.GunPointer1.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            CheatMods.GunPointer1.transform.position = raycastHit.point;
            Object.Destroy(CheatMods.GunPointer1.GetComponent<Collider>());

            CheatMods.liner6 = new GameObject("Line").AddComponent<LineRenderer>();
            var color = ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.5 ? new Color32(0, 0, 255, 255) : new Color32(255, 0, 0, 255);
            CheatMods.liner6.startColor = color;
            CheatMods.liner6.endColor = color;
            CheatMods.liner6.startWidth = 0.025f;
            CheatMods.liner6.endWidth = 0.025f;
            CheatMods.liner6.positionCount = 2;
            CheatMods.liner6.useWorldSpace = true;
            CheatMods.liner6.SetPosition(0, GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R").transform.position);
            CheatMods.liner6.SetPosition(1, raycastHit.point);
            CheatMods.liner6.material.shader = Shader.Find("GUI/Text Shader");

            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.15f)
            {
                foreach (var rig in GorillaParent.instance.vrrigs)
                {
                    if (rig != GorillaTagger.Instance.offlineVRRig && Vector3.Distance(CheatMods.GunPointer1.transform.position, rig.transform.position) < 1.5f)
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        GorillaTagger.Instance.offlineVRRig.transform.position = rig.headMesh.transform.position - new Vector3(0f, 2f, 0f);
                        SpamMods.Projectile(SpamMods.fullProjectileNames[3], rig.rightHandTransform.position, Vector3.down, SpamMods.projColor);
                        SpamMods.Projectile(SpamMods.fullProjectileNames[3], rig.leftHandTransform.position, Vector3.down, SpamMods.projColor);
                        SafetySettings.FlushRPCs();
                    }
                    else
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }

            Player.Instance.StartCoroutine(CheatMods.DestroyAfterDelay());
        }

        public static void GiveCandySpam()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab || !Physics.Raycast(Player.Instance.rightControllerTransform.position - Player.Instance.rightControllerTransform.up, -Player.Instance.rightControllerTransform.up, out raycastHit))
                return;

            if (CheatMods.GunPointer1 != null)
                Object.Destroy(CheatMods.GunPointer1);
            if (CheatMods.liner6 != null)
                Object.Destroy(CheatMods.liner6.gameObject);

            var vrrig = raycastHit.collider.GetComponentInParent<VRRig>();
            if (vrrig != null)
            {
                CheatMods.GunLockRig = vrrig;
                GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.transform.position;
            }

            CheatMods.GunPointer1 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            var renderer = CheatMods.GunPointer1.GetComponent<Renderer>();
            renderer.material.color = CheatMods.GunPointerColor1;
            renderer.material.shader = Shader.Find("GUI/Text Shader");
            CheatMods.GunPointer1.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            CheatMods.GunPointer1.transform.position = raycastHit.point;
            Object.Destroy(CheatMods.GunPointer1.GetComponent<Collider>());

            CheatMods.liner6 = new GameObject("Line").AddComponent<LineRenderer>();
            var color = ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.5 ? new Color32(0, 0, 255, 255) : new Color32(255, 0, 0, 255);
            CheatMods.liner6.startColor = color;
            CheatMods.liner6.endColor = color;
            CheatMods.liner6.startWidth = 0.025f;
            CheatMods.liner6.endWidth = 0.025f;
            CheatMods.liner6.positionCount = 2;
            CheatMods.liner6.useWorldSpace = true;
            CheatMods.liner6.SetPosition(0, GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R").transform.position);
            CheatMods.liner6.SetPosition(1, raycastHit.point);
            CheatMods.liner6.material.shader = Shader.Find("GUI/Text Shader");

            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.15f)
            {
                foreach (var rig in GorillaParent.instance.vrrigs)
                {
                    if (rig != GorillaTagger.Instance.offlineVRRig && Vector3.Distance(CheatMods.GunPointer1.transform.position, rig.transform.position) < 1.5f)
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        GorillaTagger.Instance.offlineVRRig.transform.position = rig.headMesh.transform.position - new Vector3(0f, 2f, 0f);
                        SpamMods.Projectile(SpamMods.fullProjectileNames[4], rig.rightHandTransform.position, Vector3.down, SpamMods.projColor);
                        SpamMods.Projectile(SpamMods.fullProjectileNames[4], rig.leftHandTransform.position, Vector3.down, SpamMods.projColor);
                        SafetySettings.FlushRPCs();
                    }
                    else
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }

            Player.Instance.StartCoroutine(CheatMods.DestroyAfterDelay());
        }

        public static void GiveFishSpam()
        {
            RaycastHit raycastHit;
            if (!ControllerInputPoller.instance.rightGrab || !Physics.Raycast(Player.Instance.rightControllerTransform.position - Player.Instance.rightControllerTransform.up, -Player.Instance.rightControllerTransform.up, out raycastHit))
                return;

            if (CheatMods.GunPointer1 != null)
                Object.Destroy(CheatMods.GunPointer1);
            if (CheatMods.liner6 != null)
                Object.Destroy(CheatMods.liner6.gameObject);

            var vrrig = raycastHit.collider.GetComponentInParent<VRRig>();
            if (vrrig != null)
            {
                CheatMods.GunLockRig = vrrig;
                GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.transform.position;
            }

            CheatMods.GunPointer1 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            var renderer = CheatMods.GunPointer1.GetComponent<Renderer>();
            renderer.material.color = CheatMods.GunPointerColor1;
            renderer.material.shader = Shader.Find("GUI/Text Shader");
            CheatMods.GunPointer1.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            CheatMods.GunPointer1.transform.position = raycastHit.point;
            Object.Destroy(CheatMods.GunPointer1.GetComponent<Collider>());

            CheatMods.liner6 = new GameObject("Line").AddComponent<LineRenderer>();
            var color = ControllerInputPoller.TriggerFloat(XRNode.RightHand) > 0.5 ? new Color32(0, 0, 255, 255) : new Color32(255, 0, 0, 255);
            CheatMods.liner6.startColor = color;
            CheatMods.liner6.endColor = color;
            CheatMods.liner6.startWidth = 0.025f;
            CheatMods.liner6.endWidth = 0.025f;
            CheatMods.liner6.positionCount = 2;
            CheatMods.liner6.useWorldSpace = true;
            CheatMods.liner6.SetPosition(0, GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R").transform.position);
            CheatMods.liner6.SetPosition(1, raycastHit.point);
            CheatMods.liner6.material.shader = Shader.Find("GUI/Text Shader");

            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.15f)
            {
                foreach (var rig in GorillaParent.instance.vrrigs)
                {
                    if (rig != GorillaTagger.Instance.offlineVRRig && Vector3.Distance(CheatMods.GunPointer1.transform.position, rig.transform.position) < 1.5f)
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        GorillaTagger.Instance.offlineVRRig.transform.position = rig.headMesh.transform.position - new Vector3(0f, 2f, 0f);
                        SpamMods.Projectile(SpamMods.fullProjectileNames[5], rig.rightHandTransform.position, Vector3.down, SpamMods.projColor);
                        SpamMods.Projectile(SpamMods.fullProjectileNames[5], rig.leftHandTransform.position, Vector3.down, SpamMods.projColor);
                        SafetySettings.FlushRPCs();
                    }
                    else
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }

            Player.Instance.StartCoroutine(CheatMods.DestroyAfterDelay());
        }


        public static GameObject GunPointer { get; private set; }

        public static Color GunPointerColor { get; private set; }
    }
}
