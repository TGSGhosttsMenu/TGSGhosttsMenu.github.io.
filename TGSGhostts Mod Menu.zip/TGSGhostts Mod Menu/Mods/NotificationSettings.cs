﻿using Photon.Pun;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using TGSGhostt.Classes;
using TGSGhostt.Menu;
using TGSGhosttSettings;
using UnityEngine;
using UnityEngine.InputSystem;
using TGSGhostt.Notifications;
using static TGSGhosttSettings.SettingsforMenu;

namespace TGSGhostts_Menu.Mods
{
    internal class NotificationSettings
    {
        public static bool RoomJoiner;
        public static void GetPing()
        {
          NotifiLib.SendNotification("PING: " + PhotonNetwork.GetPing().ToString());
        }
        public static void WhoIsMaster()
        {
            foreach (Photon.Realtime.Player master in PhotonNetwork.PlayerListOthers) ;
           NotifiLib.SendNotification("<color=blue>CURRENT MASTER IS </color>" + PhotonNetwork.MasterClient?.NickName);
        }
        public static bool onlyonce = false;
        public static void RoomJoinerNotification()
        {
            RoomJoiner = true;
            roomjoinernoti = true;
        }
        public static void RoomJoinerNotificationOff()
        {
            RoomJoiner = false;
            roomjoinernoti = false;
        }
        public static void EnableNotifications()
        {
            SettingsforMenu.disableNotifications = false;
        }
        public static bool idk;
        public static void DisableNotifications()
        {
            SettingsforMenu.disableNotifications = true;
        }
        public static void PlayerCount()
        {
            if (PhotonNetwork.InRoom && idk)
            {
                idk = false;
              NotifiLib.SendNotification("PLAYER ROOM COUNT: " + PhotonNetwork.PlayerList.Length.ToString());
            }
            else if (!PhotonNetwork.InRoom && !idk)
            {
                idk = true;
            }
        }
        public static bool LiveCount = false;
        public static void LivePlayerCount()
        {
            if (PhotonNetwork.InRoom && idk1 && LiveCount)
            {
                LiveCount = false;
                NotifiLib.SendNotification("PLAYER ROOM COUNT: " + PhotonNetwork.PlayerList.Length.ToString());
            }
            else if (idk1 == false)
            {
                idk1 = true;
            }
        }
        static bool idk1 = false;
    }
}